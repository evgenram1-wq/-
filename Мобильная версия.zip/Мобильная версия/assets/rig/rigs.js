// Сгенерировано tools/rig.py – не править руками (правь assets/rig/<Имя>/rig.json)
window.RIGS = {
 "Денис": {
  "name": "Денис",
  "size": [
   150,
   520
  ],
  "joints": {
   "neck": [
    76,
    74
   ],
   "shoulder": [
    62,
    105
   ],
   "elbow": [
    62,
    198
   ],
   "wrist": [
    92,
    260
   ],
   "hand": [
    104,
    312
   ],
   "hip": [
    72,
    262
   ],
   "knee": [
    70,
    376
   ],
   "ankle": [
    80,
    490
   ],
   "toe": [
    118,
    506
   ]
  },
  "overlap": 8,
  "far_arm_offset": [
   6,
   0
  ],
  "far_leg_offset": [
   0,
   0
  ],
  "parts": {
   "head": {
    "img": "assets/rig/Денис/parts/head.png",
    "ox": 36,
    "oy": 1,
    "w": 76,
    "h": 81,
    "pivot": [
     76,
     74
    ]
   },
   "torso": {
    "img": "assets/rig/Денис/parts/torso.png",
    "ox": 20,
    "oy": 66,
    "w": 110,
    "h": 174,
    "pivot": [
     72,
     262
    ]
   },
   "pelvis": {
    "img": "assets/rig/Денис/parts/pelvis.png",
    "ox": 24,
    "oy": 232,
    "w": 104,
    "h": 50,
    "pivot": [
     72,
     262
    ]
   },
   "thigh": {
    "img": "assets/rig/Денис/parts/thigh.png",
    "ox": 29,
    "oy": 266,
    "w": 89,
    "h": 118,
    "pivot": [
     72,
     262
    ]
   },
   "shin": {
    "img": "assets/rig/Денис/parts/shin.png",
    "ox": 32,
    "oy": 343,
    "w": 95,
    "h": 176,
    "pivot": [
     70,
     376
    ]
   },
   "uarm": {
    "img": "assets/rig/Денис/parts/uarm.png",
    "ox": 40,
    "oy": 83,
    "w": 47,
    "h": 140,
    "pivot": [
     62,
     105
    ]
   },
   "farm": {
    "img": "assets/rig/Денис/parts/farm.png",
    "ox": 49,
    "oy": 185,
    "w": 69,
    "h": 128,
    "pivot": [
     62,
     198
    ]
   },
   "uarm_f": {
    "img": "assets/rig/Денис/parts/uarm_f.png",
    "ox": 40,
    "oy": 83,
    "w": 47,
    "h": 140,
    "pivot": [
     62,
     105
    ]
   },
   "farm_f": {
    "img": "assets/rig/Денис/parts/farm_f.png",
    "ox": 49,
    "oy": 185,
    "w": 69,
    "h": 128,
    "pivot": [
     62,
     198
    ]
   },
   "thigh_f": {
    "img": "assets/rig/Денис/parts/thigh_f.png",
    "ox": 29,
    "oy": 266,
    "w": 89,
    "h": 118,
    "pivot": [
     72,
     262
    ]
   },
   "shin_f": {
    "img": "assets/rig/Денис/parts/shin_f.png",
    "ox": 32,
    "oy": 343,
    "w": 95,
    "h": 176,
    "pivot": [
     70,
     376
    ]
   }
  },
  "profile": "assets/characters/Денис/profile.png",
  "front": "assets/characters/Денис/front.png",
  "back": "assets/characters/Денис/back.png",
  "portrait": "assets/characters/Денис/portrait.png"
 },
 "Женя": {
  "name": "Женя",
  "size": [
   143,
   520
  ],
  "joints": {
   "neck": [
    80,
    74
   ],
   "shoulder": [
    64,
    108
   ],
   "elbow": [
    66,
    212
   ],
   "wrist": [
    85,
    258
   ],
   "hand": [
    93,
    312
   ],
   "hip": [
    70,
    262
   ],
   "knee": [
    70,
    376
   ],
   "ankle": [
    84,
    490
   ],
   "toe": [
    118,
    505
   ]
  },
  "overlap": 8,
  "far_arm_offset": [
   6,
   0
  ],
  "far_leg_offset": [
   0,
   0
  ],
  "parts": {
   "head": {
    "img": "assets/rig/Женя/parts/head.png",
    "ox": 32,
    "oy": 1,
    "w": 70,
    "h": 81,
    "pivot": [
     80,
     74
    ]
   },
   "torso": {
    "img": "assets/rig/Женя/parts/torso.png",
    "ox": 20,
    "oy": 66,
    "w": 88,
    "h": 174,
    "pivot": [
     70,
     262
    ]
   },
   "pelvis": {
    "img": "assets/rig/Женя/parts/pelvis.png",
    "ox": 30,
    "oy": 232,
    "w": 77,
    "h": 50,
    "pivot": [
     70,
     262
    ]
   },
   "thigh": {
    "img": "assets/rig/Женя/parts/thigh.png",
    "ox": 32,
    "oy": 266,
    "w": 71,
    "h": 118,
    "pivot": [
     70,
     262
    ]
   },
   "shin": {
    "img": "assets/rig/Женя/parts/shin.png",
    "ox": 34,
    "oy": 352,
    "w": 89,
    "h": 167,
    "pivot": [
     70,
     376
    ]
   },
   "uarm": {
    "img": "assets/rig/Женя/parts/uarm.png",
    "ox": 43,
    "oy": 87,
    "w": 42,
    "h": 147,
    "pivot": [
     64,
     108
    ]
   },
   "farm": {
    "img": "assets/rig/Женя/parts/farm.png",
    "ox": 55,
    "oy": 201,
    "w": 50,
    "h": 113,
    "pivot": [
     66,
     212
    ]
   },
   "uarm_f": {
    "img": "assets/rig/Женя/parts/uarm_f.png",
    "ox": 43,
    "oy": 87,
    "w": 42,
    "h": 147,
    "pivot": [
     64,
     108
    ]
   },
   "farm_f": {
    "img": "assets/rig/Женя/parts/farm_f.png",
    "ox": 55,
    "oy": 201,
    "w": 50,
    "h": 113,
    "pivot": [
     66,
     212
    ]
   },
   "thigh_f": {
    "img": "assets/rig/Женя/parts/thigh_f.png",
    "ox": 32,
    "oy": 266,
    "w": 71,
    "h": 118,
    "pivot": [
     70,
     262
    ]
   },
   "shin_f": {
    "img": "assets/rig/Женя/parts/shin_f.png",
    "ox": 34,
    "oy": 352,
    "w": 89,
    "h": 167,
    "pivot": [
     70,
     376
    ]
   }
  },
  "profile": "assets/characters/Женя/profile.png",
  "front": "assets/characters/Женя/front.png",
  "back": "assets/characters/Женя/back.png",
  "portrait": "assets/characters/Женя/portrait.png"
 },
 "Леша": {
  "name": "Леша",
  "size": [
   140,
   520
  ],
  "joints": {
   "neck": [
    80,
    74
   ],
   "shoulder": [
    62,
    108
   ],
   "elbow": [
    72,
    230
   ],
   "wrist": [
    92,
    284
   ],
   "hand": [
    98,
    306
   ],
   "hip": [
    72,
    262
   ],
   "knee": [
    72,
    376
   ],
   "ankle": [
    86,
    490
   ],
   "toe": [
    120,
    505
   ]
  },
  "overlap": 8,
  "far_arm_offset": [
   6,
   0
  ],
  "far_leg_offset": [
   0,
   0
  ],
  "parts": {
   "head": {
    "img": "assets/rig/Леша/parts/head.png",
    "ox": 32,
    "oy": 1,
    "w": 73,
    "h": 81,
    "pivot": [
     80,
     74
    ]
   },
   "torso": {
    "img": "assets/rig/Леша/parts/torso.png",
    "ox": 20,
    "oy": 66,
    "w": 97,
    "h": 174,
    "pivot": [
     72,
     262
    ]
   },
   "pelvis": {
    "img": "assets/rig/Леша/parts/pelvis.png",
    "ox": 21,
    "oy": 232,
    "w": 85,
    "h": 50,
    "pivot": [
     72,
     262
    ]
   },
   "thigh": {
    "img": "assets/rig/Леша/parts/thigh.png",
    "ox": 23,
    "oy": 266,
    "w": 78,
    "h": 118,
    "pivot": [
     72,
     262
    ]
   },
   "shin": {
    "img": "assets/rig/Леша/parts/shin.png",
    "ox": 26,
    "oy": 346,
    "w": 94,
    "h": 173,
    "pivot": [
     72,
     376
    ]
   },
   "uarm": {
    "img": "assets/rig/Леша/parts/uarm.png",
    "ox": 41,
    "oy": 87,
    "w": 58,
    "h": 165,
    "pivot": [
     62,
     108
    ]
   },
   "farm": {
    "img": "assets/rig/Леша/parts/farm.png",
    "ox": 60,
    "oy": 218,
    "w": 53,
    "h": 91,
    "pivot": [
     72,
     230
    ]
   },
   "uarm_f": {
    "img": "assets/rig/Леша/parts/uarm_f.png",
    "ox": 41,
    "oy": 87,
    "w": 58,
    "h": 165,
    "pivot": [
     62,
     108
    ]
   },
   "farm_f": {
    "img": "assets/rig/Леша/parts/farm_f.png",
    "ox": 60,
    "oy": 218,
    "w": 53,
    "h": 91,
    "pivot": [
     72,
     230
    ]
   },
   "thigh_f": {
    "img": "assets/rig/Леша/parts/thigh_f.png",
    "ox": 23,
    "oy": 266,
    "w": 78,
    "h": 118,
    "pivot": [
     72,
     262
    ]
   },
   "shin_f": {
    "img": "assets/rig/Леша/parts/shin_f.png",
    "ox": 26,
    "oy": 346,
    "w": 94,
    "h": 173,
    "pivot": [
     72,
     376
    ]
   }
  },
  "profile": "assets/characters/Леша/profile.png",
  "front": "assets/characters/Леша/front.png",
  "back": "assets/characters/Леша/back.png",
  "portrait": "assets/characters/Леша/portrait.png"
 },
 "Никита": {
  "name": "Никита",
  "size": [
   136,
   520
  ],
  "joints": {
   "neck": [
    84,
    76
   ],
   "shoulder": [
    72,
    112
   ],
   "elbow": [
    70,
    236
   ],
   "wrist": [
    86,
    264
   ],
   "hand": [
    100,
    316
   ],
   "hip": [
    72,
    282
   ],
   "knee": [
    72,
    386
   ],
   "ankle": [
    88,
    490
   ],
   "toe": [
    116,
    505
   ]
  },
  "overlap": 8,
  "far_arm_offset": [
   6,
   0
  ],
  "far_leg_offset": [
   0,
   0
  ],
  "parts": {
   "head": {
    "img": "assets/rig/Никита/parts/head.png",
    "ox": 27,
    "oy": 1,
    "w": 75,
    "h": 83,
    "pivot": [
     84,
     76
    ]
   },
   "torso": {
    "img": "assets/rig/Никита/parts/torso.png",
    "ox": 20,
    "oy": 68,
    "w": 95,
    "h": 192,
    "pivot": [
     72,
     282
    ]
   },
   "pelvis": {
    "img": "assets/rig/Никита/parts/pelvis.png",
    "ox": 22,
    "oy": 252,
    "w": 94,
    "h": 48,
    "pivot": [
     72,
     282
    ]
   },
   "thigh": {
    "img": "assets/rig/Никита/parts/thigh.png",
    "ox": 23,
    "oy": 284,
    "w": 87,
    "h": 110,
    "pivot": [
     72,
     282
    ]
   },
   "shin": {
    "img": "assets/rig/Никита/parts/shin.png",
    "ox": 21,
    "oy": 347,
    "w": 90,
    "h": 172,
    "pivot": [
     72,
     386
    ]
   },
   "uarm": {
    "img": "assets/rig/Никита/parts/uarm.png",
    "ox": 47,
    "oy": 88,
    "w": 49,
    "h": 177,
    "pivot": [
     72,
     112
    ]
   },
   "farm": {
    "img": "assets/rig/Никита/parts/farm.png",
    "ox": 55,
    "oy": 221,
    "w": 56,
    "h": 99,
    "pivot": [
     70,
     236
    ]
   },
   "uarm_f": {
    "img": "assets/rig/Никита/parts/uarm_f.png",
    "ox": 47,
    "oy": 88,
    "w": 49,
    "h": 177,
    "pivot": [
     72,
     112
    ]
   },
   "farm_f": {
    "img": "assets/rig/Никита/parts/farm_f.png",
    "ox": 55,
    "oy": 221,
    "w": 56,
    "h": 99,
    "pivot": [
     70,
     236
    ]
   },
   "thigh_f": {
    "img": "assets/rig/Никита/parts/thigh_f.png",
    "ox": 23,
    "oy": 284,
    "w": 87,
    "h": 110,
    "pivot": [
     72,
     282
    ]
   },
   "shin_f": {
    "img": "assets/rig/Никита/parts/shin_f.png",
    "ox": 21,
    "oy": 347,
    "w": 90,
    "h": 172,
    "pivot": [
     72,
     386
    ]
   }
  },
  "profile": "assets/characters/Никита/profile.png",
  "front": "assets/characters/Никита/front.png",
  "back": "assets/characters/Никита/back.png",
  "portrait": "assets/characters/Никита/portrait.png"
 }
};

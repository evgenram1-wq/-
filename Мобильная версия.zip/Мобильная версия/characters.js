// Сгенерировано tools/scan_characters.py. Нужен, т.к. при запуске двойным кликом (file://)
// браузер не разрешает fetch('characters.json'). Игра читает window.GAME_DATA.
window.GAME_DATA = {
 "characters": [
  {
   "name": "Денис",
   "source": "Персонажи/Денис/7a4334e1-6c19-4463-b67d-f124ae37997b.jpg",
   "rig": true,
   "images": {
    "front": "assets/characters/Денис/front.png",
    "profile": "assets/characters/Денис/profile.png",
    "back": "assets/characters/Денис/back.png",
    "portrait": "assets/characters/Денис/portrait.png"
   },
   "voices": {
    "select": [],
    "fight": [],
    "hit": [],
    "win": [],
    "ko": [],
    "special": [],
    "generic": [
     "Персонажи/Денис/Денис Раскажи че ты куришь.mp3",
     "Персонажи/Денис/Денис попрошу вас.mp3",
     "Персонажи/Денис/Денис_как заебали.mp3"
    ]
   },
   "frames": {}
  },
  {
   "name": "Женя",
   "source": "Персонажи/Женя/Женя.jpg",
   "rig": true,
   "images": {
    "front": "assets/characters/Женя/front.png",
    "profile": "assets/characters/Женя/profile.png",
    "back": "assets/characters/Женя/back.png",
    "portrait": "assets/characters/Женя/portrait.png"
   },
   "voices": {
    "select": [],
    "fight": [],
    "hit": [],
    "win": [],
    "ko": [],
    "special": [],
    "generic": [
     "Персонажи/Женя/Женя пиздец полный.mp3",
     "Персонажи/Женя/Женя прикинь.mp3",
     "Персонажи/Женя/Женя такая соба хуйнячка.mp3",
     "Персонажи/Женя/женя четотделал.mp3"
    ]
   },
   "frames": {}
  },
  {
   "name": "Леша",
   "source": "Персонажи/Леша/Леша.jpg",
   "rig": true,
   "images": {
    "front": "assets/characters/Леша/front.png",
    "profile": "assets/characters/Леша/profile.png",
    "back": "assets/characters/Леша/back.png",
    "portrait": "assets/characters/Леша/portrait.png"
   },
   "voices": {
    "select": [],
    "fight": [],
    "hit": [],
    "win": [],
    "ko": [],
    "special": [],
    "generic": [
     "Персонажи/Леша/леха заебали.mp3"
    ]
   },
   "frames": {}
  },
  {
   "name": "Никита",
   "source": "Персонажи/Никита/Никита.jpg",
   "rig": true,
   "images": {
    "front": "assets/characters/Никита/front.png",
    "profile": "assets/characters/Никита/profile.png",
    "back": "assets/characters/Никита/back.png",
    "portrait": "assets/characters/Никита/portrait.png"
   },
   "voices": {
    "select": [],
    "fight": [],
    "hit": [],
    "win": [],
    "ko": [],
    "special": [],
    "generic": [
     "Персонажи/Никита/Никита Цуприк- тупизм.mp3"
    ]
   },
   "frames": {}
  }
 ],
 "arenas": [
  {
   "name": "цех",
   "file": "Локация/цех.jpg"
  }
 ],
 "events": [
  {
   "key": "булка",
   "name": "Булка",
   "image": "assets/events/булка/dog.png",
   "sounds": [
    "случайные сбытия/булка/булка.mp3"
   ]
  },
  {
   "key": "малыш",
   "name": "Малыш",
   "image": "assets/events/малыш/dog.png",
   "sounds": [
    "случайные сбытия/малыш/малыш.mp3"
   ]
  }
 ],
 "music": [
  "Музыка/mortalcombat.mp3"
 ]
};

@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo  ЖЕЛЕЗНЫЙ КУЛАК - запуск для телефона
echo  Телефон и компьютер должны быть в одной Wi-Fi сети.
echo  Откройте в Chrome на телефоне один из адресов:
echo.
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
  for /f "tokens=* delims= " %%b in ("%%a") do echo      http://%%b:8000
)
echo.
echo  (окно не закрывайте, пока играете; остановить - Ctrl+C)
echo.
python -m http.server 8000
pause

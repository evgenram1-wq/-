// ============================================================================
//  input.js — клавиатура (по e.code – не зависит от раскладки) и геймпады.
//  Для боя: Input.read(i) -> {held, pressed}; для меню: Input.menuEvents().
// ============================================================================
(function () {
  const C = window.CFG;
  const ACTIONS = ['left', 'right', 'up', 'down', 'light', 'heavy', 'kick', 'block', 'throw', 'special'];
  const keys = {};            // e.code -> true
  const menuQueue = [];       // события для меню
  const BUF = 4;              // «буфер нажатия»: кадров, в течение которых нажатие ещё считается свежим

  const state = [0, 1].map(() => ({ held: {}, prev: {}, pressedAt: {}, pressed: {} }));
  let frame = 0;
  const padPrev = {};

  const Input = { keys };

  function codeToPlayerAction(code) {
    for (let p = 0; p < 2; p++) {
      const c = C.controls[p];
      for (const a of ACTIONS) if (c[a] === code) return { p, a };
    }
    return null;
  }

  window.addEventListener('keydown', e => {
    if (e.repeat) { if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) e.preventDefault(); return; }
    keys[e.code] = true;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) e.preventDefault();
    window.GameAudio && window.GameAudio.unlock();
    // события меню
    const pa = codeToPlayerAction(e.code);
    const push = (src, a) => menuQueue.push({ src, a });
    if (pa) {
      const map = { left: 'left', right: 'right', up: 'up', down: 'down', light: 'ok', heavy: 'ok', kick: 'ok', block: 'back', special: 'ok' };
      if (map[pa.a]) push(pa.p, map[pa.a]);
    }
    if (e.code === 'Enter' || e.code === 'NumpadEnter') push(-1, 'ok');
    if (e.code === 'Space') push(-1, 'ok');
    if (e.code === 'Escape' || e.code === 'Backspace') push(-1, 'back');
    if (e.code === 'KeyP') push(-1, 'pause');
    if (e.code === 'Escape') push(-1, 'pause');
    if (e.code === 'KeyM') push(-1, 'mute');
    if (e.code === 'Tab') push(-1, 'tab');
    push(-1, 'any');
  });
  window.addEventListener('keyup', e => { keys[e.code] = false; });
  window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; });
  window.addEventListener('mousedown', () => { window.GameAudio && window.GameAudio.unlock(); });

  function pads() {
    const l = navigator.getGamepads ? navigator.getGamepads() : [];
    return Array.from(l || []).filter(g => g && g.connected);
  }

  /** Обновляет состояния игроков; вызывать один раз за кадр симуляции. */
  Input.update = function () {
    frame++;
    const gp = pads();
    for (let p = 0; p < 2; p++) {
      const st = state[p], c = C.controls[p];
      const held = {};
      for (const a of ACTIONS) held[a] = !!keys[c[a]];
      // геймпад: pad[0] -> игрок 1, pad[1] -> игрок 2
      const g = gp[p];
      if (g) {
        const dz = C.pad.deadzone, ax = g.axes[0] || 0, ay = g.axes[1] || 0;
        const b = i => g.buttons[i] && g.buttons[i].pressed;
        held.left = held.left || ax < -dz || b(14);
        held.right = held.right || ax > dz || b(15);
        held.up = held.up || ay < -dz || b(C.pad.jump);
        held.down = held.down || ay > dz || b(13);
        held.light = held.light || b(C.pad.light);
        held.heavy = held.heavy || b(C.pad.heavy);
        held.kick = held.kick || b(C.pad.kick);
        held.block = held.block || b(C.pad.block) || b(6) || b(7);
        held.throw = held.throw || b(C.pad.throw);
        held.special = held.special || b(C.pad.special);
      }
      for (const a of ACTIONS) {
        if (held[a] && !st.prev[a]) st.pressedAt[a] = frame;
        st.prev[a] = held[a];
      }
      st.held = held;
      st.pressed = {};
      for (const a of ACTIONS) st.pressed[a] = (frame - (st.pressedAt[a] || -99)) <= BUF;
    }
    // меню с геймпада
    gp.forEach((g, i) => {
      const prev = padPrev[i] || (padPrev[i] = {});
      const dz = 0.6;
      const now = {
        left: (g.axes[0] || 0) < -dz || (g.buttons[14] && g.buttons[14].pressed),
        right: (g.axes[0] || 0) > dz || (g.buttons[15] && g.buttons[15].pressed),
        up: (g.axes[1] || 0) < -dz || (g.buttons[12] && g.buttons[12].pressed),
        down: (g.axes[1] || 0) > dz || (g.buttons[13] && g.buttons[13].pressed),
        ok: (g.buttons[0] && g.buttons[0].pressed) || (g.buttons[2] && g.buttons[2].pressed),
        back: g.buttons[1] && g.buttons[1].pressed,
        pause: g.buttons[9] && g.buttons[9].pressed,
      };
      for (const k of Object.keys(now)) {
        if (now[k] && !prev[k]) { menuQueue.push({ src: i, a: k }); menuQueue.push({ src: i, a: 'any' }); window.GameAudio && window.GameAudio.unlock(); }
        prev[k] = now[k];
      }
    });
  };

  /** Нажатия, ещё не «съеденные»: расходуются при чтении. */
  Input.read = function (p) { return state[p]; };
  Input.consume = function (p, a) { state[p].pressedAt[a] = -99; state[p].pressed[a] = false; };
  Input.clear = function () { for (const s of state) { s.pressedAt = {}; s.pressed = {}; } menuQueue.length = 0; };
  Input.push = function (src, a) { menuQueue.push({ src, a }); menuQueue.push({ src, a: 'any' }); };
  Input.menuEvents = function () { const e = menuQueue.splice(0, menuQueue.length); return e; };
  Input.padCount = () => pads().length;

  // Читаемые названия клавиш для экрана управления
  Input.keyName = function (code) {
    if (!code) return '—';
    if (code.startsWith('Key')) return code.slice(3);
    if (code.startsWith('Arrow')) return { ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓' }[code];
    if (code.startsWith('Digit')) return code.slice(5);
    if (code.startsWith('Numpad')) return 'Num' + code.slice(6);
    return code;
  };
  Input.ACTIONS = ACTIONS;
  window.Input = Input;
})();

// ============================================================================
//  game.js — бой: раунды, таймер, попадания и блок, снаряды, камера, «FINISH HIM!», HUD.
// ============================================================================
(function () {
  const C = window.CFG;
  const W = C.W, H = C.H, SW = C.stageWidth, GY = C.groundY;
  const sign = v => (v > 0 ? 1 : v < 0 ? -1 : 0);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const FONT = '"Impact","Arial Black","Segoe UI Black",sans-serif';

  function outlineText(ctx, s, x, y, size, fill, stroke, align) {
    ctx.save();
    ctx.font = '900 ' + size + 'px ' + FONT; ctx.textAlign = align || 'center'; ctx.textBaseline = 'alphabetic';
    ctx.lineJoin = 'round'; ctx.lineWidth = Math.max(4, size / 7); ctx.strokeStyle = stroke || '#12040a';
    ctx.strokeText(s, x, y); ctx.fillStyle = fill; ctx.fillText(s, x, y); ctx.restore();
  }
  function goldGrad(ctx, y0, y1) {
    const g = ctx.createLinearGradient(0, y0, 0, y1);
    g.addColorStop(0, '#fff2b0'); g.addColorStop(0.45, '#e8b53c'); g.addColorStop(1, '#8a5a12');
    return g;
  }

  class Match {
    /**
     * opts: { chars:[chA, chB], modes:['human'|'ai', 'human'|'ai'], level, arena }
     */
    constructor(opts) {
      this.opts = opts;
      this.arena = opts.arena;
      Rig.setShade(this.arena.shade);
      this.fighters = [new Fighter(0, opts.chars[0]), new Fighter(1, opts.chars[1])];
      this.ctrl = opts.modes.map((m, i) => (m === 'ai' ? { kind: 'ai', ai: new AI(opts.level || 'normal') } : { kind: 'human', p: i === 0 ? 0 : 1 }));
      // в режиме против ИИ человек всегда управляется раскладкой игрока 1
      this.wins = [0, 0]; this.round = 1; this.frame = 0;
      this.projectiles = []; this.cam = { x: (SW - W) / 2, zoom: 1 };
      this.hitstop = 0; this.slow = 0; this.slowAcc = 0;
      this.paused = false; this.pauseSel = 0; this.canFight = false;
      this.phase = 'intro'; this.ph = 0; this.banner = null; this.timer = C.roundTime * 60; this.over = false;
      this.finishData = null; this.comboShow = [0, 0]; this.comboT = [0, 0]; this.hpTrail = [100, 100];
      this.matchWinner = null; this.resultSel = 0; this.finisherDone = false; this.zoomFx = 0;
      Fx.reset();
      this.startRound();
    }

    // ------------------------------------------------------------ раунды ---
    startRound() {
      const [a, b] = this.fighters;
      a.reset(SW / 2 - 190, 1); b.reset(SW / 2 + 190, -1);
      this.projectiles.length = 0; this.canFight = false;
      if (this.dog) this.dog.stop();
      this.dog = null; this.dogPlan = window.Events ? Events.plan() : null; this.fightFrames = 0;
      this.phase = 'intro'; this.ph = 0; this.timer = C.roundTime * 60;
      this.hpTrail = [C.maxHealth, C.maxHealth];
      a.setState('intro', 'intro'); b.setState('intro', 'intro');
      this.cam.x = (SW - W) / 2; this.finishData = null; this.slow = 0;
      Fx.reset();
      GameAudio.playMusic('fight');
    }

    banner_(text, sub, frames, color) { this.banner = { text, sub, t: 0, max: frames || 90, color }; }

    // -------------------------------------------------------------- ввод ---
    inputFor(i, opp) {
      const c = this.ctrl[i], f = this.fighters[i];
      if (c.kind === 'ai') return c.ai.decide(f, this.fighters[1 - i], this);
      const s = Input.read(c.p);
      return { held: s.held, pressed: s.pressed, consume: a => Input.consume(c.p, a) };
    }

    // -------------------------------------------------------------- шаг ----
    update() {
      const ev = Input.menuEvents();
      // --- меню паузы / результата ---
      if (this.phase === 'matchEnd' && this.endReady) {
        for (const e of ev) {
          if (e.a === 'up' || e.a === 'down' || e.a === 'left' || e.a === 'right') { this.resultSel = 1 - this.resultSel; GameAudio.sfx('ui_move'); }
          if (e.a === 'ok') { GameAudio.sfx('ui_ok'); return this.resultSel === 0 ? 'rematch' : 'quit'; }
          if (e.a === 'back') return 'quit';
        }
      }
      if (this.paused) {
        for (const e of ev) {
          if (e.a === 'pause' || e.a === 'back') { this.paused = false; GameAudio.sfx('ui_ok'); }
          else if (e.a === 'up' || e.a === 'down') { this.pauseSel = (this.pauseSel + 1) % 2; GameAudio.sfx('ui_move'); }
          else if (e.a === 'ok') { GameAudio.sfx('ui_ok'); if (this.pauseSel === 0) this.paused = false; else return 'quit'; }
        }
        return null;
      }
      for (const e of ev) {
        if (e.a === 'pause' && this.phase !== 'matchEnd') { this.paused = true; this.pauseSel = 0; GameAudio.sfx('ui_ok'); return null; }
        if (e.a === 'mute') GameAudio.toggleMute();
      }
      if (this.phase === 'matchEnd') { /* ввод в блоке выше */ }

      // замедление (нокаут): часть кадров пропускаем
      if (this.slow > 0) {
        this.slow--;
        this.slowAcc += C.koSlowFactor;
        if (this.slowAcc < 1) { Fx.update(); return null; }
        this.slowAcc -= 1;
      }
      if (this.hitstop > 0) { this.hitstop--; Fx.update(); this.updateHud(); return null; }

      this.frame++;
      this.ph++;
      this.updatePhase();

      const [a, b] = this.fighters;
      const ia = this.inputFor(0), ib = this.inputFor(1);
      // в «ничьей» фазе FINISH бойцы-проигравшие не управляются
      a.update(ia, b, this); b.update(ib, a, this);
      this.finishInput(ia, ib);
      this.bodyCollide();
      this.resolveAttacks();
      this.updateProjectiles();
      this.updateDog();
      this.updateCamera();
      Fx.update();
      this.updateHud();
      this.updateTimer();
      this.checkRoundEnd();
      return null;
    }

    updateHud() {
      for (let i = 0; i < 2; i++) {
        const f = this.fighters[i];
        if (this.hpTrail[i] > f.hp) this.hpTrail[i] = Math.max(f.hp, this.hpTrail[i] - 0.45);
        else this.hpTrail[i] = f.hp;
        if (this.comboT[i] > 0) this.comboT[i]--;
      }
      if (this.banner) { this.banner.t++; if (this.banner.t > this.banner.max) this.banner = null; }
    }

    // --------------------------------------------------- фазы раунда -------
    updatePhase() {
      const [a, b] = this.fighters;
      if (this.phase === 'intro') {
        if (this.ph === 10) { this.banner_('РАУНД ' + this.round, null, 80); GameAudio.sfx('gong'); GameAudio.say(this.round >= 3 ? 'round3' : 'round' + this.round); }
        if (this.ph === 14) { a.say(this, 'select'); }
        if (this.ph === 100) {
          this.banner_('FIGHT!', null, 60, '#ff3a2a'); GameAudio.say('fight'); GameAudio.sfx('flash');
          a.setState('idle', 'idle'); b.setState('idle', 'idle');
          (Math.random() < 0.5 ? a : b).say(this, 'fight');
          this.canFight = true; this.phase = 'fight';
        }
      } else if (this.phase === 'koEnd') {
        if (this.ph === 70) this.announceWinner();
        if (this.ph >= 190) { this.afterRound(); }
      } else if (this.phase === 'finish') {
        this.updateFinish();
      } else if (this.phase === 'finisher') {
        this.updateFinisher();
      } else if (this.phase === 'matchEnd') {
        if (this.ph > 110) this.endReady = true;
      }
    }

    updateTimer() {
      if (this.phase !== 'fight') return;
      this.timer--;
      if (this.timer <= 0) {
        this.timer = 0;
        const [a, b] = this.fighters;
        this.canFight = false;
        if (a.hp === b.hp) { this.endRound(null, 'ВРЕМЯ! НИЧЬЯ'); }
        else this.endRound(a.hp > b.hp ? 0 : 1, 'ВРЕМЯ!');
      }
    }

    checkRoundEnd() {
      if (this.phase !== 'fight') return;
      const [a, b] = this.fighters;
      if (a.hp <= 0 && b.hp <= 0) { this.endRound(null, 'ДВОЙНОЙ НОКАУТ'); return; }
      for (let i = 0; i < 2; i++) {
        const loser = this.fighters[i];
        if (loser.hp <= 0) {
          const win = 1 - i;
          const clinch = this.wins[win] + 1 >= C.roundsToWin;
          if (clinch) this.startFinish(win, i); else this.endRound(win, 'K.O.');
          return;
        }
      }
    }

    /** Конец раунда: победитель w (или null – ничья). */
    endRound(w, text) {
      this.phase = 'koEnd'; this.ph = 0; this.canFight = false; this.roundWinner = w;
      const [a, b] = this.fighters;
      if (text === 'K.O.' || text === 'ДВОЙНОЙ НОКАУТ') {
        this.banner_('K.O.', null, 110, '#ff3a2a'); GameAudio.sfx('ko'); GameAudio.say('ko');
        this.slow = C.koSlowFrames; this.slowAcc = 0; Fx.shake(C.shakeKO); Fx.flash(0.6, '255,60,40');
        for (const f of this.fighters) if (f.hp <= 0 && f.state !== 'ko') this.knockOut(f, 1 - f.idx);
      } else {
        this.banner_(text, null, 110, '#ffd15c'); GameAudio.sfx('gong');
        for (const f of this.fighters) f.setState('idle', 'idle');
      }
    }

    knockOut(loser, winnerIdx) {
      const w = this.fighters[winnerIdx];
      loser.setState('ko', 'ko'); loser.vx = (w ? w.facing : -loser.facing) * 3.5; loser.vy = -11; loser.h = Math.max(loser.h, 0.2); loser.kb = 0;
      loser.say(this, 'ko');
    }

    announceWinner() {
      const w = this.roundWinner;
      if (w === null || w === undefined) return;
      const f = this.fighters[w];
      if (f.state !== 'ko') { f.setState('win', 'win'); f.say(this, 'win'); }
      const flawless = f.damageTaken === 0;
      this.banner_(flawless ? 'FLAWLESS VICTORY' : f.name.toUpperCase() + ' ПОБЕЖДАЕТ', null, 100, '#ffd15c');
      if (flawless) GameAudio.say('flawless');
      else GameAudio.say('victory');
    }

    afterRound() {
      const w = this.roundWinner;
      if (w !== null && w !== undefined) this.wins[w]++;
      if (w !== null && w !== undefined && this.wins[w] >= C.roundsToWin) { this.endMatch(w); return; }
      if (w !== null && w !== undefined) this.round++;
      this.startRound();
    }

    endMatch(w) {
      this.phase = 'matchEnd'; this.ph = 0; this.matchWinner = w; this.endReady = false; this.resultSel = 0;
      const f = this.fighters[w];
      if (f.state !== 'win') { f.setState('win', 'win'); }
      f.say(this, 'win');
      GameAudio.playMusic('menu');
    }

    // ------------------------------------------------- FINISH HIM ----------
    startFinish(winIdx, loseIdx) {
      const w = this.fighters[winIdx], l = this.fighters[loseIdx];
      this.phase = 'finish'; this.ph = 0; this.canFight = false;
      this.finishData = { w: winIdx, l: loseIdx, flawless: w.damageTaken === 0 };
      l.hp = 0; l.setState('stun', 'stun'); l.kb = 0; l.vx = 0; l.vy = 0; l.h = 0; l.invuln = 0; l.crouching = false;
      w.setState('idle', 'idle'); w.vx = 0; w.kb = 0;
      this.banner_('FINISH HIM!', null, 150, '#ff3a2a');
      GameAudio.sfx('finish'); GameAudio.say('finish');
      Fx.flash(0.5, '255,40,30'); Fx.shake(10);
      this.slow = 40; this.slowAcc = 0;
    }

    finishInput(ia, ib) { /* нажатие финишера читается в updateFinish */ this._inputs = [ia, ib]; }

    updateFinish() {
      const d = this.finishData; if (!d) return;
      const w = this.fighters[d.w], l = this.fighters[d.l];
      // победитель стоит в стойке; проигравший на коленях
      const inp = this._inputs && this._inputs[d.w];
      const isAI = this.ctrl[d.w].kind === 'ai';
      const press = isAI ? (this.ph > 90 + Math.floor(Math.random() * 3)) : (inp && (inp.pressed.special || inp.pressed.heavy || inp.pressed.kick || inp.pressed.light));
      if (press && this.ph > 30) { this.startFinisher(); return; }
      if (this.ph > 330) {                  // не успел – обычный нокаут
        this.phase = 'koEnd'; this.ph = 0; this.roundWinner = d.w; this.knockOut(l, d.w);
        this.banner_('K.O.', null, 100, '#ff3a2a'); GameAudio.sfx('ko'); this.slow = C.koSlowFrames; Fx.shake(C.shakeKO);
      }
    }

    startFinisher() {
      const d = this.finishData; const w = this.fighters[d.w], l = this.fighters[d.l];
      this.phase = 'finisher'; this.ph = 0; this.banner = null;
      // подойти к проигравшему
      w.x = l.x - w.facing * 150; w.facing = sign(l.x - w.x) || w.facing; w.h = 0;
      const t = w.specialType, sp = C.specials[t];
      w.move = sp; w.moveKey = 'finisher';
      w.setState('finishing', sp.anim, 0.9);
      w.say(this, 'special');
      this.finisherFrame = Math.round(sp.startup / 0.9) + 2;
    }

    updateFinisher() {
      const d = this.finishData; const w = this.fighters[d.w], l = this.fighters[d.l];
      if (this.ph === 1) { this.zoomFx = 1; }
      if (this.ph === this.finisherFrame) {
        // эффектный нокаут-кадр: белая вспышка, ударная волна, проигравший улетает
        Fx.flash(1, '255,255,255'); Fx.shake(C.shakeKO + 6);
        const p = [l.x, GY - 150];
        Fx.burstFlash(p[0], p[1], 260, '255,230,170'); Fx.shockwave(l.x, GY - 2, 360, '255,210,100');
        Fx.sparks(p[0], p[1], w.facing, 40, null, 1.6);
        GameAudio.sfx('ko'); GameAudio.sfx('flash'); GameAudio.say('ko');
        this.hitstop = C.hitstopKO;
        l.setState('ko', 'ko'); l.vx = w.facing * 7; l.vy = -15; l.h = 0.3; l.flash = 1; l.hp = 0;
        this.slow = C.koSlowFrames + 30; this.slowAcc = 0;
        this.roundWinner = d.w;
      }
      if (this.ph > this.finisherFrame && this.ph >= this.finisherFrame + 34 && w.state === 'finishing') { w.setState('idle', 'idle'); }
      if (this.ph === this.finisherFrame + 100) {
        w.setState('win', 'win'); w.say(this, 'win');
        this.banner_(d.flawless ? 'FLAWLESS VICTORY' : 'VICTORY', null, 150, '#ffd15c');
        GameAudio.say(d.flawless ? 'flawless' : 'victory');
      }
      if (this.ph === this.finisherFrame + 240) { this.wins[d.w]++; this.zoomFx = 0; this.endMatch(d.w); }
    }

    // ---------------------------------------------- столкновения тел -------
    bodyCollide() {
      const [a, b] = this.fighters;
      const lim = (f) => { f.x = clamp(f.x, C.wallMargin, SW - C.wallMargin); };
      lim(a); lim(b);
      // не давать разойтись слишком далеко
      const dx = b.x - a.x, dist = Math.abs(dx);
      if (dist > C.maxDistance) {
        const over = (dist - C.maxDistance) / 2, s = sign(dx);
        // сдвигаем только того, кто убежал (последнего двигавшегося)
        a.x += s * over; b.x -= s * over;
      }
      if (this.phase === 'finisher') return;
      // выталкивание друг из друга на земле
      if (a.h < 90 && b.h < 90 && !['held'].includes(a.state) && !['held'].includes(b.state) && !['knockdown', 'ko'].includes(a.state) && !['knockdown', 'ko'].includes(b.state)) {
        const d = b.x - a.x, ad = Math.abs(d);
        if (ad < C.pushDist) {
          const s = sign(d) || (a.facing > 0 ? 1 : -1), push = (C.pushDist - ad) / 2;
          let pa = push, pb = push;
          const atWallA = a.x - C.wallMargin < 4, atWallB = SW - C.wallMargin - b.x < 4;
          if (atWallA && s > 0) { pa = 0; pb = push * 2; }
          if (atWallB && s > 0) { pb = 0; pa = push * 2; }
          if (atWallA && s < 0) { pa = push * 2; pb = 0; }
          a.x -= s * pa; b.x += s * pb;
          lim(a); lim(b);
        }
      }
    }

    // --------------------------------------------- попадания и блок --------
    resolveAttacks() {
      for (let i = 0; i < 2; i++) {
        const A = this.fighters[i], D = this.fighters[1 - i];
        if (A.state !== 'attack' || !A.move || A.hitDone) continue;
        const m = A.move, f = A.st;
        if (f < m.startup || f >= m.startup + m.active) continue;
        if (m.height === 'throw') continue;
        const limb = m.limb;
        if (!limb) continue;
        if (!D.vulnerable) continue;
        const pt = A.limbPoint(limb);
        if (this.hitTest(pt, m.radius || 30, D.hurtbox(), A, limb)) this.applyHit(A, D, m, pt);
      }
    }

    hitTest(pt, r, hb, A, limb) {
      // круг у кисти/стопы + вторая точка на полпути (предплечье/голень), чтобы быстрый удар не «пролетал» сквозь цель
      const tests = [pt];
      const base = A.sol && A.sol.pts[limb.startsWith('hand') ? (limb === 'handN' ? 'elbowN' : 'elbowF') : (limb === 'toeN' ? 'kneeN' : 'kneeF')];
      if (base) tests.push([(pt[0] + base[0]) / 2, (pt[1] + base[1]) / 2]);
      for (const p of tests) {
        const cx = clamp(p[0], hb.x, hb.x + hb.w), cy = clamp(p[1], hb.y, hb.y + hb.h);
        if ((p[0] - cx) ** 2 + (p[1] - cy) ** 2 <= r * r) return true;
      }
      return false;
    }

    /** Применяет удар m бойца A по D. pt – точка контакта. opts.throw – бросок (минует блок). */
    applyHit(A, D, m, pt, opts) {
      opts = opts || {};
      const facesA = sign(A.x - D.x) === D.facing || sign(A.x - D.x) === 0;
      const canBlock = !opts.throw && m.height !== 'throw' && !D.airborne && facesA &&
        (D.state === 'block' || D.state === 'cblock' || D.state === 'blockstun') && (m.height !== 'low' || D.crouching);
      const dir = A.facing === 0 ? 1 : sign(D.x - A.x) || A.facing;
      const cx = pt ? pt[0] : D.x, cy = pt ? pt[1] : GY - 150;
      A.hitDone = true;
      if (canBlock) {
        const chip = Math.max(1, Math.round(m.damage * C.chipDamage));
        D.hp = Math.max(1, D.hp - chip); D.damageTaken += chip;
        D.setState('blockstun', D.crouching ? 'cblock' : 'block'); D.stateLen = m.blockstun;
        D.kb = dir * (m.blockKnock || 2); D.flash = 0;
        A.meter = Math.min(C.meterMax, A.meter + 2); D.meter = Math.min(C.meterMax, D.meter + 3);
        Fx.hit(cx, cy, dir, 1, true); GameAudio.sfx('block');
        this.hitstop = Math.max(this.hitstop, 3);
        this.wallPush(A, D);
        return;
      }
      // --- попадание ---
      const comboActive = (D.state === 'hit' || (D.state === 'knockdown' && D.airborne)) && D.invuln <= 0;
      A.combo = comboActive ? A.combo + 1 : 1;
      if (!comboActive) A.comboDmg = 0;
      const scale = Math.pow(C.comboScaling, A.combo - 1);
      const dmg = Math.max(1, Math.round(m.damage * scale * this.damageMult(A, m)));
      D.hp = Math.max(0, D.hp - dmg); D.damageTaken += dmg; A.comboDmg += dmg;
      A.meter = Math.min(C.meterMax, A.meter + (m.meter || 0) + dmg * C.meterOnHit);
      D.meter = Math.min(C.meterMax, D.meter + dmg * C.meterOnDamaged);
      const ko = D.hp <= 0;
      const kd = m.knockdown || D.airborne || ko;
      const heavy = dmg >= 8 || kd;
      if (kd) {
        D.setState(ko && this.phase === 'fight' && this.wins[A.idx] + 1 < C.roundsToWin ? 'ko' : 'knockdown', ko && this.phase === 'fight' && this.wins[A.idx] + 1 < C.roundsToWin ? 'ko' : 'knockdown');
        D.vx = dir * ((m.knock || 5) * 0.8 + 1.5); D.vy = D.airborne ? -4 : (m.moveKeyLow ? -6 : -10); D.h = Math.max(D.h, 0.3); D.kb = 0; D.crouching = false;
      } else {
        D.setState('hit', D.crouching ? 'hit_c' : (heavy ? 'hit_h' : 'hit'));
        D.stateLen = m.hitstun; D.kb = dir * (m.knock || 3);
      }
      D.flash = 1; D.invuln = 0;
      // показываем комбо
      if (A.combo >= 2) { this.comboShow[A.idx] = A.combo; this.comboT[A.idx] = 90; }
      // эффекты
      const power = ko ? 3 : (heavy ? 2 : 1);
      Fx.hit(cx, cy, dir, power, false);
      GameAudio.sfx(m.sfx || (heavy ? 'heavy' : 'punch'));
      if (kd) GameAudio.sfx('heavy');
      Fx.shake(ko ? C.shakeKO * 0.7 : (m.shake || C.shakeLight));
      this.hitstop = Math.max(this.hitstop, ko ? C.hitstopKO : (m.hitstop || (heavy ? C.hitstopHeavy : C.hitstopLight)));
      if (heavy && Math.random() < C.voiceHitChance) D.say(this, 'hit');
      // яд (плевок Жени): добавляем «горение» на несколько секунд
      if (m.dot) D.dot = { n: m.dot.n, per: m.dot.per, every: m.dot.every, t: m.dot.every };
      if (m.kind === 'spit') for (let i = 0; i < 12; i++) Fx.sparks(cx, cy, dir, 1, '#7dff4a', 1.2);
      // сдвоенный удар (Лёша): быстро повторяем удар ещё раз
      if (A.trait && A.trait.double && !A.doubled && !ko && A.state === 'attack' && A.move === m && ['light', 'heavy', 'kick'].includes(m.anim) && Math.random() < A.trait.double) {
        A.doubled = true; A.hitDone = false;
        A.st = Math.max(1, m.startup - 2); A.animT = A.st;
        Fx.text(A.x, GY - A.h - 340, 'ДВОЙНОЙ!', '#ffd15c', 30, 36);
      }
      this.wallPush(A, D);
    }

    /** Особенности бойцов: множитель урона (медленный сильнее, быстрый слабее, руки/ноги Никиты). */
    damageMult(A, m) {
      const t = A.trait || {};
      let k = t.dmg || 1;
      if (!m.kind && m.anim) {
        if (m.anim === 'light' || m.anim === 'heavy' || m.anim === 'jpunch') k *= t.punch || 1;
        else if (m.anim === 'kick' || m.anim === 'sweep' || m.anim === 'jkick') k *= t.kick || 1;
      }
      return k;
    }

    wallPush(A, D) {
      // у стены отбрасывание переходит на атакующего
      const atWall = D.x <= C.wallMargin + 6 || D.x >= SW - C.wallMargin - 6;
      if (atWall && Math.abs(D.kb) > 0.1) { A.kb = -sign(D.kb) * Math.abs(D.kb) * 0.7; D.kb = 0; }
    }

    applyDamage(A, D, m, o) {            // для броска
      const pt = [D.x, GY - 150];
      D.state = 'knockdown'; D.setAnim('knockdown');
      D.state = 'idle'; // сбрасываем, чтобы applyHit трактовал как обычное попадание
      A.hitDone = false;
      const mm = Object.assign({}, m, { knockdown: true, knock: 6 });
      D.h = Math.max(D.h, 1);
      this.applyHit(A, D, mm, pt, { throw: true });
      D.vx = A.facing * 5.5; D.vy = -9;
    }

    // ---------------------------------------------------- снаряды ----------
    spawnProjectile(owner, x, y, m, extra) {
      const p = { owner, x: x + owner.facing * 20, y, vx: owner.facing * (m.speed || 8), vy: 0, g: 0, r: m.radius, m, age: 0, color: m.color, kind: m.kind || 'orb', rot: 0 };
      this.projectiles.push(Object.assign(p, extra || {}));
    }
    /** Один удар болгаркой: бьёт, если соперник вплотную перед бойцом. last – завершающий (сбивает с ног). */
    grinderHit(A, m, last) {
      const D = this.fighters[1 - A.idx];
      const g = A.grinderPos();
      if (g) Fx.sparks(g[0], g[1], A.facing, 6, '#ffd15c', 1.4);
      const dx = (D.x - A.x) * A.facing;
      if (!D.vulnerable || D.airborne || dx < -20 || dx > m.range) return;
      A.hitDone = false;
      const mm = Object.assign({}, m, { height: 'mid', knockdown: !!last, knock: last ? 7 : m.knock, damage: last ? m.damage + 2 : m.damage });
      this.applyHit(A, D, mm, g || [D.x, GY - 150]);
      if (g) Fx.sparks(g[0] + A.facing * 10, g[1], -A.facing, 7, '#ffb04a', 1.6);
    }
    shockwaveHit(A, m) {
      const D = this.fighters[1 - A.idx];
      Fx.shockwave(A.x + A.facing * 40, GY - 2, 300, '255,200,90');
      Fx.shockwave(A.x + A.facing * 40, GY - 2, 190, '255,90,60');
      Fx.dust(A.x + A.facing * 60, GY, 14, 80);
      Fx.shake(m.shake || 14); GameAudio.sfx('fall'); GameAudio.sfx('heavy');
      A.hitDone = false;
      const dx = Math.abs(D.x - A.x);
      if (!D.airborne && D.vulnerable && dx <= m.range && sign(D.x - A.x) === A.facing) {
        this.applyHit(A, D, Object.assign({}, m, { height: 'mid' }), [D.x, GY - 40]);
      }
    }
    updateProjectiles() {
      for (const p of this.projectiles) {
        p.x += p.vx; p.y += p.vy; p.vy += p.g; p.age++; p.rot += 0.38 * Math.sign(p.vx || 1);
        if (p.y > GY - 6 && p.kind !== 'orb') {                     // упали на землю: бутылка разбивается, остальное шлёпается
          p.dead = true;
          if (p.kind === 'bottle') { Fx.sparks(p.x, GY - 6, 0, 14, '#9fe8b0', 1.5); GameAudio.sfx('glass'); }
          else if (p.kind === 'spit') { Fx.sparks(p.x, GY - 6, 0, 8, '#7dff4a', 1.0); }
          else { Fx.dust(p.x, GY, 4, 20); GameAudio.sfx('block'); }
          continue;
        }
        const D = this.fighters[1 - p.owner.idx];
        if (!p.dead && D.vulnerable) {
          const hb = D.hurtbox();
          const cx = clamp(p.x, hb.x, hb.x + hb.w), cy = clamp(p.y, hb.y, hb.y + hb.h);
          if ((p.x - cx) ** 2 + (p.y - cy) ** 2 <= p.r * p.r) {
            p.owner.hitDone = false;
            this.applyHit(p.owner, D, Object.assign({}, p.m, { height: 'mid', limb: null }), [p.x, p.y]);
            p.dead = true;
            if (p.kind === 'bottle') { Fx.sparks(p.x, p.y, 0, 16, '#9fe8b0', 1.6); GameAudio.sfx('glass'); }
            else Fx.burstFlash(p.x, p.y, p.kind === 'spit' ? 70 : 110, p.kind === 'spit' ? '140,255,90' : '255,200,100');
          }
        }
        if (p.x < -100 || p.x > SW + 100) p.dead = true;
      }
      // снаряды разных бойцов взаимно уничтожаются
      for (const p of this.projectiles) for (const q of this.projectiles) {
        if (p !== q && !p.dead && !q.dead && p.owner !== q.owner && Math.abs(p.x - q.x) < p.r + q.r && Math.abs(p.y - q.y) < 60) {
          p.dead = q.dead = true; Fx.burstFlash((p.x + q.x) / 2, p.y, 140, '255,240,200'); GameAudio.sfx('block'); Fx.shake(5);
        }
      }
      this.projectiles = this.projectiles.filter(p => !p.dead);
    }

    // ------------------------------------------ случайные события (собаки) --
    updateDog() {
      if (this.phase === 'fight' && this.canFight) {
        this.fightFrames++;
        const pl = this.dogPlan;
        if (pl && !this.dog && this.fightFrames >= pl.at) {
          const [a, b] = this.fighters;
          const alive = this.fighters.filter(f => f.hp > 1 && f.state !== 'ko');
          if (alive.length) {
            const target = alive[Math.floor(Math.random() * alive.length)];
            this.dog = new Events.Dog(pl.def, target, this);
          }
          this.dogPlan = null;
        }
      } else if (this.dog && this.dog.state !== 'out' && this.phase !== 'finisher') {
        this.dog.state = 'out'; this.dog.st = 0; this.dog.stop();       // раунд кончился – собака убегает
      }
      if (this.dog) { this.dog.update(); if (this.dog.dead) this.dog = null; }
    }

    // ----------------------------------------------------------- камера ----
    updateCamera() {
      const [a, b] = this.fighters;
      const mid = (a.x + b.x) / 2;
      const target = clamp(mid - W / 2, 0, SW - W);
      this.cam.x += (target - this.cam.x) * 0.12;
      const dist = Math.abs(a.x - b.x);
      let tz = clamp(1.16 - (dist - 150) / 1100, 1.0, 1.14);
      if (this.phase === "finisher") tz = 1.16;
      this.cam.zoom += (tz - this.cam.zoom) * 0.08;
    }

    // ----------------------------------------------------------- рисование -
    draw(ctx) {
      ctx.save();
      const z = this.cam.zoom;
      const sx = Fx.shakeX, sy = Fx.shakeY;
      ctx.translate(W / 2 + sx, GY + sy); ctx.scale(z, z); ctx.translate(-W / 2, -GY);
      // ограничение: при zoom>1 верх кадра обрезается, поэтому рисуем арену по всему экрану
      const camX = Math.round(this.cam.x);
      this.arena.draw(ctx, camX);
      ctx.save(); ctx.translate(-camX, 0);
      // бойцы: тот, кто бьёт, рисуется поверх
      const order = this.fighters.slice().sort((p, q) => (p.state === 'attack' ? 1 : 0) - (q.state === 'attack' ? 1 : 0));
      for (const f of order) f.draw(ctx, this.arena);
      for (const f of this.fighters) f.drawTrail(ctx);
      if (this.dog) this.dog.draw(ctx);
      for (const p of this.projectiles) this.drawProjectile(ctx, p);
      Fx.draw(ctx);
      Fx.drawTexts(ctx);
      ctx.restore();
      this.arena.over(ctx, camX, this.frame);
      ctx.restore();
      // вспышка на весь экран
      if (Fx.flashA > 0) { ctx.fillStyle = 'rgba(' + Fx.flashColor + ',' + Fx.flashA.toFixed(2) + ')'; ctx.fillRect(0, 0, W, H); }
      // затемнение/виньетка
      Match.vignette(ctx, 0.45, 0.95, 0.5);
      this.drawHud(ctx);
      this.drawBanner(ctx);
      if (this.phase === 'finish') this.drawFinishPrompt(ctx);
      if (this.phase === 'matchEnd' && this.endReady) this.drawResult(ctx);
      if (this.paused) this.drawPause(ctx);
    }

    drawProjectile(ctx, p) {
      if (p.kind === 'hammer') return this.drawHammer(ctx, p);
      if (p.kind === 'spit') return this.drawSpit(ctx, p);
      if (p.kind === 'bottle') return this.drawBottle(ctx, p);
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const t = p.age, r = p.r * (1 + Math.sin(t * 0.5) * 0.08);
      for (let i = 4; i >= 1; i--) {                       // хвост
        const g = ctx.createRadialGradient(p.x - Math.sign(p.vx) * i * 18, p.y, 0, p.x - Math.sign(p.vx) * i * 18, p.y, r * (1 - i * 0.14));
        g.addColorStop(0, 'rgba(255,170,60,' + (0.35 - i * 0.06) + ')'); g.addColorStop(1, 'rgba(255,60,20,0)');
        ctx.fillStyle = g; ctx.fillRect(p.x - Math.sign(p.vx) * i * 18 - r, p.y - r, r * 2, r * 2);
      }
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r * 1.5);
      g.addColorStop(0, 'rgba(255,255,230,1)'); g.addColorStop(0.35, 'rgba(255,200,80,.95)'); g.addColorStop(0.7, 'rgba(255,70,30,.5)'); g.addColorStop(1, 'rgba(255,40,10,0)');
      ctx.fillStyle = g; ctx.fillRect(p.x - r * 1.6, p.y - r * 1.6, r * 3.2, r * 3.2);
      ctx.restore();
    }

    /** Молоток Дениса: вращается в полёте. */
    drawHammer(ctx, p) {
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(0, 0, 44, 12, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#7a4a22'; ctx.fillRect(-6, -4, 66 - 0, 8);              // рукоять
      ctx.fillStyle = '#a06a36'; ctx.fillRect(-6, -4, 66, 3);
      const g = ctx.createLinearGradient(0, -22, 0, 22); g.addColorStop(0, '#d8dbe0'); g.addColorStop(0.5, '#8d929a'); g.addColorStop(1, '#4a4e56');
      ctx.fillStyle = g; ctx.fillRect(-32, -22, 34, 44);                       // боёк
      ctx.strokeStyle = '#22252a'; ctx.lineWidth = 2; ctx.strokeRect(-32, -22, 34, 44);
      ctx.restore();
      // искры за молотком
      if (p.age % 2 === 0) Fx.sparks(p.x - Math.sign(p.vx) * 20, p.y, -Math.sign(p.vx), 1, '#ffd15c', 0.6);
    }
    /** Зелёный плевок Жени: сгусток с каплями. */
    drawSpit(ctx, p) {
      const dir = Math.sign(p.vx) || 1, r = p.r * (0.8 + Math.sin(p.age * 0.6) * 0.08);
      ctx.save();
      for (let i = 4; i >= 1; i--) {                                   // капли-хвост
        ctx.fillStyle = 'rgba(110,230,50,' + (0.55 - i * 0.09) + ')';
        ctx.beginPath(); ctx.arc(p.x - dir * i * 15, p.y + Math.sin(p.age * 0.8 + i) * 6, r * (0.55 - i * 0.08), 0, 7); ctx.fill();
      }
      const g = ctx.createRadialGradient(p.x - 5, p.y - 6, 2, p.x, p.y, r);
      g.addColorStop(0, '#e6ff9a'); g.addColorStop(0.45, '#7be02e'); g.addColorStop(1, '#2d8a12');
      ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(p.x, p.y, r * 1.1, r * 0.8, 0, 0, 7); ctx.fill();
      ctx.globalCompositeOperation = 'lighter';
      const h = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r * 1.8);
      h.addColorStop(0, 'rgba(140,255,60,.35)'); h.addColorStop(1, 'rgba(60,200,20,0)');
      ctx.fillStyle = h; ctx.fillRect(p.x - r * 2, p.y - r * 2, r * 4, r * 4);
      ctx.restore();
    }
    /** Бутылка Никиты: вертится в полёте. */
    drawBottle(ctx, p) {
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
      ctx.fillStyle = 'rgba(40,150,70,.92)';
      ctx.beginPath(); ctx.roundRect ? ctx.roundRect(-26, -10, 36, 20, 6) : ctx.rect(-26, -10, 36, 20); ctx.fill();   // корпус
      ctx.fillRect(8, -5, 22, 10);                                                                               // горлышко
      ctx.fillStyle = '#d8c28a'; ctx.fillRect(28, -6, 5, 12);                                                    // пробка
      ctx.fillStyle = '#e8e2c8'; ctx.fillRect(-16, -10, 14, 20);                                                 // этикетка
      ctx.fillStyle = 'rgba(255,255,255,.45)'; ctx.fillRect(-24, -7, 30, 3);                                     // блик
      ctx.restore();
    }

    // ------------------------------------------------------------- HUD -----
    drawHud(ctx) {
      const bw = 470, bh = 30, y = 34, gap = 76;
      for (let i = 0; i < 2; i++) {
        const f = this.fighters[i];
        const x0 = i === 0 ? 40 : W - 40 - bw;
        // рамка
        ctx.save();
        ctx.fillStyle = 'rgba(10,3,6,.85)';
        ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x0 - 6, y - 6, bw + 12, bh + 12, 6) : ctx.rect(x0 - 6, y - 6, bw + 12, bh + 12); ctx.fill();
        ctx.strokeStyle = '#d9a93a'; ctx.lineWidth = 3; ctx.stroke();
        // шкала
        const hp = Math.max(0, f.hp) / C.maxHealth, tr = Math.max(0, this.hpTrail[i]) / C.maxHealth;
        const fillBar = (frac, col) => {
          const w = bw * frac; ctx.fillStyle = col;
          if (i === 0) ctx.fillRect(x0 + bw - w, y, w, bh); else ctx.fillRect(x0, y, w, bh);
        };
        // для P1 шкала убывает слева направо (заполнена к центру)
        ctx.fillStyle = '#2a0b10'; ctx.fillRect(x0, y, bw, bh);
        fillBar(tr, '#ffe8b0');
        const g = ctx.createLinearGradient(0, y, 0, y + bh);
        const low = hp < 0.28;
        g.addColorStop(0, low ? '#ff5a4a' : '#ff3b2f'); g.addColorStop(1, low ? '#a01010' : '#8c0f14');
        ctx.fillStyle = g;
        const w = bw * hp; if (i === 0) ctx.fillRect(x0 + bw - w, y, w, bh); else ctx.fillRect(x0, y, w, bh);
        ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(x0, y, bw, bh / 2);
        // риски
        ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 1;
        for (let k = 1; k < 10; k++) { const xx = x0 + bw * k / 10; ctx.beginPath(); ctx.moveTo(xx, y); ctx.lineTo(xx, y + bh); ctx.stroke(); }
        ctx.restore();
        // имя
        outlineText(ctx, f.name.toUpperCase(), i === 0 ? x0 : x0 + bw, y + bh + 36, 30, '#f3e6d0', '#12040a', i === 0 ? 'left' : 'right');
        // шкала спецудара
        const my = y + bh + 48, mw = 250, mh = 10;
        ctx.fillStyle = 'rgba(10,3,6,.8)'; ctx.fillRect(i === 0 ? x0 : x0 + bw - mw, my, mw, mh);
        const mf = Math.min(1, f.meter / C.meterMax), full = f.meter >= C.specialCost;
        ctx.fillStyle = full ? '#ffd15c' : '#b07a16';
        const mx = i === 0 ? x0 : x0 + bw - mw;
        ctx.fillRect(mx, my, mw * mf, mh);
        ctx.strokeStyle = '#d9a93a'; ctx.lineWidth = 2; ctx.strokeRect(mx, my, mw, mh);
        ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.beginPath(); ctx.moveTo(mx + mw * C.specialCost / C.meterMax, my); ctx.lineTo(mx + mw * C.specialCost / C.meterMax, my + mh); ctx.stroke();
        if (full && Math.floor(this.frame / 10) % 2 === 0) outlineText(ctx, 'СПЕЦУДАР', i === 0 ? mx + mw + 8 : mx - 8, my + 10, 16, '#ffd15c', '#12040a', i === 0 ? 'left' : 'right');
        // победы
        for (let k = 0; k < C.roundsToWin; k++) {
          const cx = i === 0 ? x0 + bw - 14 - k * 26 : x0 + 14 + k * 26, cy = y + bh + 70;
          ctx.beginPath(); ctx.arc(cx, cy, 9, 0, 7);
          ctx.fillStyle = k < this.wins[i] ? '#ff3a2a' : 'rgba(10,3,6,.7)'; ctx.fill();
          ctx.strokeStyle = '#d9a93a'; ctx.lineWidth = 2.5; ctx.stroke();
        }
        // комбо
        if (this.comboT[i] > 0 && this.comboShow[i] >= 2) {
          const a = Math.min(1, this.comboT[i] / 25), cx = i === 0 ? 130 : W - 130;
          ctx.save(); ctx.globalAlpha = a;
          outlineText(ctx, this.comboShow[i] + ' ХИТОВ', cx, 300, 46, '#ffd15c', '#12040a');
          outlineText(ctx, 'КОМБО', cx, 336, 26, '#ff5a3a', '#12040a');
          ctx.restore();
        }
      }
      // таймер
      const t = Math.ceil(this.timer / 60);
      ctx.fillStyle = 'rgba(10,3,6,.9)'; ctx.beginPath(); ctx.arc(W / 2, 54, 40, 0, 7); ctx.fill();
      ctx.strokeStyle = '#d9a93a'; ctx.lineWidth = 4; ctx.stroke();
      outlineText(ctx, String(t), W / 2, 72, 50, t <= 10 ? '#ff4030' : '#f3e6d0', '#12040a');
    }

    drawBanner(ctx) {
      const b = this.banner; if (!b) return;
      const k = b.t / b.max;
      const appear = Math.min(1, b.t / 10), fade = k > 0.8 ? (1 - k) / 0.2 : 1;
      const scale = 1 + (1 - appear) * 1.2 + Math.sin(k * 3) * 0.02;
      ctx.save(); ctx.globalAlpha = fade; ctx.translate(W / 2, H * 0.36); ctx.scale(scale, scale);
      const size = b.text.length > 12 ? 92 : 130;
      ctx.font = '900 ' + size + 'px ' + FONT; ctx.textAlign = 'center'; ctx.lineJoin = 'round';
      ctx.lineWidth = 16; ctx.strokeStyle = '#12040a'; ctx.strokeText(b.text, 0, 0);
      ctx.lineWidth = 4; ctx.strokeStyle = '#6d0c12';
      ctx.fillStyle = b.color ? b.color : goldGrad(ctx, -size * 0.8, size * 0.1);
      if (!b.color) { const g = ctx.createLinearGradient(0, -size * 0.8, 0, size * 0.1); g.addColorStop(0, '#fff2b0'); g.addColorStop(0.5, '#e8b53c'); g.addColorStop(1, '#9a6416'); ctx.fillStyle = g; }
      ctx.fillText(b.text, 0, 0); ctx.strokeText(b.text, 0, 0);
      ctx.restore();
    }

    drawFinishPrompt(ctx) {
      const d = this.finishData; if (!d) return;
      const ctrlW = this.ctrl[d.w];
      if (ctrlW.kind === 'ai') return;
      const key = Input.keyName(C.controls[ctrlW.p].special);
      const remain = Math.max(0, Math.ceil((330 - this.ph) / 60));
      if (Math.floor(this.frame / 14) % 2 === 0) outlineText(ctx, 'ДОБИВАЮЩИЙ УДАР: кнопка СПЕЦ  ·  ' + remain, W / 2, H - 70, 34, '#ffd15c', '#12040a');
    }

    drawResult(ctx) {
      const w = this.fighters[this.matchWinner];
      ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(0, 0, W, H);
      outlineText(ctx, w.name.toUpperCase() + ' ПОБЕДИЛ', W / 2, 250, 84, '#ffd15c', '#12040a');
      const opts = ['РЕВАНШ', 'В ГЛАВНОЕ МЕНЮ'];
      opts.forEach((o, i) => outlineText(ctx, (i === this.resultSel ? '▶ ' : '') + o, W / 2, 360 + i * 70, 44, i === this.resultSel ? '#ff5a3a' : '#e9dcc8', '#12040a'));
    }

    drawPause(ctx) {
      ctx.fillStyle = 'rgba(5,0,3,.82)'; ctx.fillRect(0, 0, W, H);
      outlineText(ctx, 'ПАУЗА', W / 2, 110, 84, '#ffd15c', '#12040a');
      const opts = ['ПРОДОЛЖИТЬ', 'ВЫЙТИ В МЕНЮ'];
      opts.forEach((o, i) => outlineText(ctx, (i === this.pauseSel ? '▶ ' : '') + o, W / 2, 190 + i * 52, 36, i === this.pauseSel ? '#ff5a3a' : '#e9dcc8', '#12040a'));
      outlineText(ctx, 'Управление — кнопками на экране', W / 2, 340, 26, '#e9dcc8', '#12040a');
    }

    /** Виньетка из маленькой кешированной картинки (дешевле, чем градиент каждый кадр). */
    static vignette(ctx, inner, outer, alpha) {
      const key = inner + '_' + outer + '_' + alpha; Match._vg = Match._vg || {};
      let c = Match._vg[key];
      if (!c) {
        c = document.createElement('canvas'); c.width = 256; c.height = 144; const g = c.getContext('2d');
        const gr = g.createRadialGradient(128, 72, 144 * inner, 128, 72, 144 * outer);
        gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,' + alpha + ')'); g.fillStyle = gr; g.fillRect(0, 0, 256, 144);
        Match._vg[key] = c;
      }
      ctx.drawImage(c, 0, 0, W, H);
    }

    /** Таблица управления обоих игроков. */
    static drawControls(ctx, y0) {
      const rows = [['ВЛЕВО', 'left'], ['ВПРАВО', 'right'], ['ПРЫЖОК', 'up'], ['ПРИСЕД', 'down'], ['СЛАБЫЙ УДАР', 'light'], ['СИЛЬНЫЙ УДАР', 'heavy'],
        ['УДАР НОГОЙ', 'kick'], ['БЛОК', 'block'], ['БРОСОК', 'throw'], ['СПЕЦУДАР', 'special']];
      const colX = [W / 2 - 330, W / 2 + 170];
      ctx.save();
      for (let p = 0; p < 2; p++) {
        outlineText(ctx, C.controls[p].name, W / 2 + (p === 0 ? -250 : 250), y0, 28, '#ffd15c', '#12040a');
      }
      rows.forEach((r, i) => {
        const y = y0 + 38 + i * 30;
        ctx.font = '600 20px "Segoe UI",Arial,sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#e9dcc8';
        ctx.fillText(r[0], W / 2, y);
        for (let p = 0; p < 2; p++) {
          const cx = W / 2 + (p === 0 ? -250 : 250);
          const label = Input.keyName(C.controls[p][r[1]]);
          ctx.fillStyle = 'rgba(40,12,18,.9)'; ctx.fillRect(cx - 40, y - 21, 80, 28);
          ctx.strokeStyle = '#d9a93a'; ctx.lineWidth = 1.5; ctx.strokeRect(cx - 40, y - 21, 80, 28);
          ctx.fillStyle = '#ffd15c'; ctx.fillText(label, cx, y);
        }
      });
      ctx.font = '500 16px "Segoe UI",Arial,sans-serif'; ctx.fillStyle = '#a99886'; ctx.textAlign = 'center';
      ctx.fillText('Геймпад: стик/крестовина – движение, ✕ – ногой, □ – слабый, △ – сильный, ○ – блок, L1 – бросок, R1 – спецудар. Раскладка клавиатуры (русская/английская) не важна.', W / 2, y0 + 38 + rows.length * 30 + 14);
      ctx.restore();
    }
  }

  Match.outlineText = outlineText;
  Match.goldGrad = goldGrad;
  window.Match = Match;
})();

// ============================================================================
//  animations.js — позы и ключевые кадры кукольной анимации.
//
//  ПОЗА – это набор углов суставов (в градусах) и смещение корпуса.
//  Угол ПОЛОЖИТЕЛЬНЫЙ = по часовой стрелке на экране для бойца, смотрящего ВПРАВО.
//  Поэтому «рука/нога вперёд» = ОТРИЦАТЕЛЬНЫЙ угол, «наклон корпуса вперёд» = положительный.
//
//   x, y   смещение корпуса, px (y вниз)       rot    поворот всего тела вокруг таза (лёжа = -90)
//   torso  наклон корпуса     head  наклон головы        pelv  поворот таза
//   uN/fN  ближняя рука: плечо / предплечье с кистью (fN = 0 – рука прямая, отрицательный = локоть согнут)
//   uF/fF  дальняя рука
//   tN/sN  ближняя нога: бедро / голень со стопой (sN = 0 – нога прямая, положительный = колено согнуто)
//   tF/sF  дальняя нога
//
//  Анимация – список ключевых кадров {t, p, e}: t – кадр (60 кадров = 1 с), p – поза (недостающие поля
//  берутся из боевой стойки S), e – плавность прихода в этот кадр: lin | in | out | io.
//  Атаки строятся из startup / active / recovery в config.js, поэтому ПИК УДАРА всегда совпадает
//  с первым активным кадром, а хитбокс берётся из реальной позиции кисти/стопы.
// ============================================================================
(function () {
  const C = window.CFG;

  // Боевая стойка
  const S = { x: 0, y: 0, rot: 0, pelv: 0, torso: 6, head: -4,
    uN: -36, fN: -108, uF: -52, fF: -100,
    tN: -12, sN: 17, tF: 10, sF: 19 };
  const KEYS = Object.keys(S);

  const EASE = {
    lin: t => t,
    in: t => t * t * t,
    out: t => 1 - Math.pow(1 - t, 3),
    io: t => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  };

  const full = (p, base) => Object.assign({}, base || S, p || {});
  const K = (t, p, e, base) => ({ t, p: full(p, base), e: e || 'io' });

  // ---- вспомогательные позы ----
  const CROUCH = { torso: 16, head: -8, tN: -78, sN: 102, tF: -52, sF: 96, uN: -30, fN: -110, uF: -48, fF: -100 };
  const GUARD = { torso: -3, head: 2, uN: -62, fN: -118, uF: -70, fF: -112, tN: -20, sN: 24, tF: 18, sF: 24 };
  const TUCK = { torso: 6, head: -4, tN: -92, sN: 100, tF: -62, sF: 104, uN: -58, fN: -62, uF: -78, fF: -52 };
  const LYING = { rot: -90, torso: 2, head: -10, uN: -14, fN: -14, uF: -22, fF: -10, tN: -8, sN: 8, tF: 6, sF: 10 };

  const anims = {};
  function def(name, o) {
    o.name = name;
    o.blend = o.blend === undefined ? C.blendFrames : o.blend;
    o.length = o.frames[o.frames.length - 1].t;
    anims[name] = o;
  }

  // ---- idle: дыхание, лёгкое покачивание в стойке, колени согнуты ----
  def('idle', { loop: true, frames: [
    K(0, {}), K(26, { torso: 8, head: -6, uN: -39, fN: -104, uF: -55, fF: -97, tN: -19, sN: 24, tF: 18, sF: 25 }),
    K(56, {}),
  ] });

  // ---- ходьба вперёд (назад – та же анимация задом наперёд) ----
  const wk = (a, b) => ({ torso: 9, head: -5, tN: a[0], sN: a[1], tF: b[0], sF: b[1] });
  def('walk', { loop: true, blend: 4, frames: [
    K(0,  Object.assign(wk([-30, 8],  [22, 30]),  { uN: -44, uF: -44, fN: -104, fF: -98 })),
    K(9,  Object.assign(wk([-6, 22],  [-6, 62]),  { uN: -38, uF: -50 })),
    K(18, Object.assign(wk([22, 30],  [-30, 8]),  { uN: -30, uF: -58, fN: -112, fF: -94 })),
    K(27, Object.assign(wk([-6, 62],  [-6, 22]),  { uN: -38, uF: -50 })),
    K(36, Object.assign(wk([-30, 8],  [22, 30]),  { uN: -44, uF: -44, fN: -104, fF: -98 })),
  ] });
  def('walkB', { loop: true, blend: 4, reverse: true, frames: anims.walk.frames.map(f => Object.assign({}, f)) });

  // ---- присед ----
  def('crouch', { frames: [K(0, {}), K(6, CROUCH, 'out')] });
  def('crouchIdle', { loop: true, frames: [K(0, CROUCH), K(30, Object.assign({}, CROUCH, { torso: 19, head: -10 }, {})), K(60, CROUCH)] });

  // ---- блок ----
  def('block', { blend: 3, frames: [K(0, {}), K(4, GUARD, 'out'), K(10, Object.assign({}, GUARD, { torso: -5 }))] });
  def('cblock', { blend: 3, frames: [K(0, CROUCH), K(4, Object.assign({}, CROUCH, GUARD, { tN: CROUCH.tN, sN: CROUCH.sN, tF: CROUCH.tF, sF: CROUCH.sF, torso: 10 }), 'out')] });

  // ---- прыжок: подготовка, полёт, приземление ----
  def('jump_prep', { blend: 2, frames: [K(0, {}), K(C.jumpSquat, Object.assign({}, CROUCH, { tN: -52, sN: 78, tF: -36, sF: 70, torso: 22, uN: 12, fN: -34, uF: 6, fF: -30 }), 'out')] });
  def('jump_up', { blend: 3, frames: [
    K(0, { tN: -52, sN: 78, tF: -36, sF: 70, torso: 22, uN: 12, fN: -34, uF: 6, fF: -30 }),
    K(9, TUCK, 'out'), K(18, TUCK),
  ] });
  def('jump_fall', { blend: 4, frames: [K(0, TUCK), K(14, { torso: 8, head: -4, tN: -40, sN: 44, tF: -20, sF: 40, uN: -66, fN: -70, uF: -80, fF: -60 }, 'out')] });
  def('land', { blend: 2, frames: [K(0, CROUCH), K(C.landRecovery + 1, {}, 'out')] });

  // ---- удары: пик совпадает с первым активным кадром ----
  (function buildAttacks() {
    const M = C.moves;
    // джеб (ближняя рука)
    let m = M.light, st = m.startup, ac = m.active, T = st + ac + m.recovery;
    const jabOut = { torso: 15, head: -2, uN: -90, fN: -3, uF: -58, fF: -104, tN: -26, sN: 22, tF: 20, sF: 22 };
    def('light', { blend: 2, frames: [
      K(0, {}), K(Math.max(1, Math.round(st * 0.55)), { torso: -2, uN: -16, fN: -126, uF: -58, fF: -104 }, 'io'),
      K(st, jabOut, 'out'), K(st + ac, jabOut, 'lin'), K(T, {}, 'io'),
    ] });

    // сильный удар: замах всем корпусом, шаг вперёд, дальняя рука
    m = M.heavy; st = m.startup; ac = m.active; T = st + ac + m.recovery;
    const hvOut = { torso: 30, head: 3, uF: -94, fF: -3, uN: -22, fN: -96, tN: -44, sN: 38, tF: 34, sF: 12 };
    def('heavy', { blend: 2, frames: [
      K(0, {}), K(Math.round(st * 0.65), { torso: -12, head: -3, uF: 28, fF: -112, uN: -52, fN: -100, tN: -22, sN: 28, tF: 24, sF: 26 }, 'io'),
      K(st, hvOut, 'out'), K(st + ac, hvOut, 'lin'), K(T, {}, 'io'),
    ] });

    // удар ногой: поворот корпуса, вынос ноги
    m = M.kick; st = m.startup; ac = m.active; T = st + ac + m.recovery;
    const kkOut = { torso: -22, head: 0, tN: -94, sN: -4, tF: 8, sF: 12, uN: -22, fN: -64, uF: -76, fF: -84 };
    def('kick', { blend: 2, frames: [
      K(0, {}), K(Math.round(st * 0.5), { torso: -8, tN: -78, sN: 98, tF: 10, sF: 14, uN: -44, fN: -90, uF: -64, fF: -96 }, 'io'),
      K(st, kkOut, 'out'), K(st + ac, kkOut, 'lin'), K(T, {}, 'io'),
    ] });

    // подсечка (присед + удар ногой)
    m = M.sweep; st = m.startup; ac = m.active; T = st + ac + m.recovery;
    const swOut = Object.assign({}, CROUCH, { torso: 34, head: 6, tN: -88, sN: -2, tF: -66, sF: 100, uN: 18, fN: -40, uF: 28, fF: -30 });
    def('sweep', { blend: 2, frames: [
      K(0, CROUCH), K(Math.round(st * 0.5), Object.assign({}, CROUCH, { torso: 24, tN: -70, sN: 90 })),
      K(st, swOut, 'out'), K(st + ac, swOut, 'lin'), K(T, CROUCH, 'io'),
    ] });

    // удары в прыжке
    m = M.jpunch; st = m.startup; ac = m.active; T = st + ac + m.recovery;
    const jpOut = Object.assign({}, TUCK, { torso: 14, uN: -92, fN: -2, uF: -60, fF: -80, tN: -70, sN: 70, tF: -40, sF: 76 });
    def('jpunch', { blend: 2, frames: [K(0, TUCK), K(st, jpOut, 'out'), K(st + ac, jpOut, 'lin'), K(T, TUCK)] });
    m = M.jkick; st = m.startup; ac = m.active; T = st + ac + m.recovery;
    const jkOut = Object.assign({}, TUCK, { torso: -18, tN: -62, sN: -6, tF: -24, sF: 72, uN: -30, fN: -70, uF: -84, fF: -60 });
    def('jkick', { blend: 2, frames: [K(0, TUCK), K(st, jkOut, 'out'), K(st + ac, jkOut, 'lin'), K(T, TUCK)] });

    // бросок: хват двумя руками, замах, бросок вперёд
    m = M.throw; st = m.startup; ac = m.active; T = st + ac + m.recovery;
    const grab = { torso: 10, uN: -84, fN: -4, uF: -88, fF: -4, tN: -26, sN: 26, tF: 22, sF: 24 };
    def('throw', { blend: 2, frames: [
      K(0, {}), K(st, grab, 'out'), K(st + ac + 6, grab, 'lin'),
      K(st + ac + 12, { torso: -16, uN: -140, fN: -8, uF: -150, fF: -8, tN: -14, sN: 18, tF: 14, sF: 20 }, 'io'),
      K(st + ac + 17, { torso: 32, head: 6, uN: -64, fN: -6, uF: -72, fF: -6, tN: -34, sN: 30, tF: 30, sF: 16 }, 'out'),
      K(T, {}, 'io'),
    ] });

    // ---- спецудары (у каждого своя анимация) ----
    let sp = C.specials.proj; st = sp.startup; ac = sp.active; T = st + ac + sp.recovery;
    const pjOut = { torso: 24, head: 2, uN: -92, fN: -2, uF: -88, fF: -4, tN: -38, sN: 30, tF: 32, sF: 14 };
    def('special_proj', { blend: 3, frames: [
      K(0, {}), K(Math.round(st * 0.55), { torso: -16, head: -6, uN: 14, fN: -92, uF: 18, fF: -98, tN: -26, sN: 34, tF: 24, sF: 30 }, 'io'),
      K(st, pjOut, 'out'), K(st + ac + 6, pjOut, 'lin'), K(T, {}, 'io'),
    ] });

    sp = C.specials.dash; st = sp.startup; ac = sp.active; T = st + ac + sp.recovery;
    const dsOut = { torso: 40, head: 8, uN: -98, fN: -2, uF: -70, fF: -104, tN: -52, sN: 42, tF: 42, sF: 6 };
    def('special_dash', { blend: 3, frames: [
      K(0, {}), K(Math.round(st * 0.6), { torso: -20, head: -6, uN: -40, fN: -124, tN: -22, sN: 24, tF: 24, sF: 28 }, 'io'),
      K(st, dsOut, 'out'), K(st + ac, dsOut, 'lin'), K(T, {}, 'io'),
    ] });

    sp = C.specials.wave; st = sp.startup; ac = sp.active; T = st + ac + sp.recovery;
    const wvUp = { torso: -14, head: -8, tN: -88, sN: 104, uN: -128, fN: -16, uF: -118, fF: -18, tF: 10, sF: 12 };
    const wvDn = { torso: 36, head: 12, tN: -14, sN: 0, uN: -22, fN: -12, uF: -12, fF: -12, tF: 22, sF: 22 };
    def('special_wave', { blend: 3, frames: [
      K(0, {}), K(Math.round(st * 0.6), wvUp, 'io'), K(Math.round(st * 0.85), wvUp, 'lin'),
      K(st, wvDn, 'in'), K(st + ac + 8, wvDn, 'lin'), K(T, {}, 'io'),
    ] });

    sp = C.specials.rise; st = sp.startup; ac = sp.active; T = st + ac + sp.recovery;
    const rsUp = { torso: -16, head: -10, uN: -168, fN: -3, uF: -66, fF: -86, tN: -34, sN: 62, tF: -22, sF: 72 };
    def('special_rise', { blend: 3, frames: [
      K(0, {}), K(Math.max(2, st - 3), Object.assign({}, CROUCH, { torso: 20, uN: 20, fN: -60, uF: 24, fF: -60 }), 'io'),
      K(st + 3, rsUp, 'out'), K(st + ac, rsUp, 'lin'),
      K(st + ac + 10, Object.assign({}, rsUp, { uN: -120, tN: -20, sN: 30, tF: -10, sF: 40 }), 'io'), K(T, {}, 'io'),
    ] });

    // Женя: плевок – откидывается назад и резко подаётся головой вперёд
    sp = C.specials.spit; st = sp.startup; ac = sp.active; T = st + ac + sp.recovery;
    const spOut = { torso: 30, head: 18, uN: -44, fN: -112, uF: -60, fF: -100, tN: -30, sN: 28, tF: 26, sF: 16 };
    def('special_spit', { blend: 3, frames: [
      K(0, {}), K(Math.round(st * 0.65), { torso: -16, head: -22, uN: -30, fN: -110, uF: -50, fF: -102, tN: -22, sN: 30, tF: 20, sF: 26 }, 'io'),
      K(st, spOut, 'out'), K(st + ac + 6, spOut, 'lin'), K(T, {}, 'io'),
    ] });

    // Никита: три броска бутылок подряд (замах – бросок)
    sp = C.specials.bottle; st = sp.startup; ac = sp.active; T = st + ac + sp.recovery;
    const btWind = { torso: -14, head: -8, uN: 40, fN: -96, uF: -52, fF: -100, tN: -24, sN: 30, tF: 22, sF: 24 };
    const btOut = { torso: 22, head: 2, uN: -100, fN: -6, uF: -60, fF: -104, tN: -34, sN: 28, tF: 28, sF: 14 };
    def('special_bottles', { blend: 3, frames: [
      K(0, {}), K(st - 6, btWind, 'io'), K(st, btOut, 'out'),
      K(st + 4, btWind, 'io'), K(st + 9, btOut, 'out'),
      K(st + 13, btWind, 'io'), K(st + 18, btOut, 'out'),
      K(st + ac + 4, btOut, 'lin'), K(T, {}, 'io'),
    ] });

    // Леша: болгарка – обе руки вперёд, водит инструментом вверх-вниз
    sp = C.specials.grind; st = sp.startup; ac = sp.active; T = st + ac + sp.recovery;
    const gr1 = { torso: 24, head: 6, uN: -74, fN: -26, uF: -66, fF: -34, tN: -34, sN: 30, tF: 30, sF: 16 };
    const gr2 = { torso: 28, head: 8, uN: -96, fN: -14, uF: -88, fF: -20, tN: -36, sN: 32, tF: 30, sF: 14 };
    const grFr = [K(0, {}), K(st, gr1, 'out')];
    for (let t = st + 6, i = 0; t <= st + ac; t += 6, i++) grFr.push(K(t, i % 2 ? gr1 : gr2, 'io'));
    grFr.push(K(T, {}, 'io'));
    def('special_grind', { blend: 3, frames: grFr });
  })();

  // ---- Леша спотыкается: падает лицом вперёд и поднимается ----
  const TRIP_DN = { rot: 84, torso: 6, head: 10, x: 0, uN: -150, fN: -8, uF: -140, fF: -10, tN: 18, sN: 6, tF: 24, sF: 4 };
  def('trip', { blend: 3, frames: [
    K(0, {}), K(8, { torso: 28, head: 8, uN: -118, fN: -10, uF: -108, fF: -12, tN: -30, sN: 30, tF: 34, sF: 10, x: 14 }, 'in'),
    K(20, TRIP_DN, 'in'), K(44, TRIP_DN, 'lin'),
    K(56, Object.assign({}, CROUCH, { torso: 44, head: 6, uN: -40, fN: -60, uF: -50, fF: -60 }), 'io'),
    K(68, {}, 'io'),
  ] });

  // ---- получение удара ----
  const HIT = { torso: -16, head: -20, uN: -10, fN: -34, uF: -20, fF: -44, tN: -8, sN: 14, tF: 22, sF: 22, x: -6 };
  def('hit', { blend: 2, frames: [K(0, {}), K(4, HIT, 'out'), K(12, Object.assign({}, HIT, { torso: -12, head: -15 })), K(22, Object.assign({}, HIT, { torso: -14, head: -17 }))] });
  const HIT_H = { torso: -28, head: -28, uN: -4, fN: -22, uF: 6, fF: -30, tN: -2, sN: 10, tF: 30, sF: 30, x: -12 };
  def('hit_h', { blend: 2, frames: [K(0, {}), K(5, HIT_H, 'out'), K(14, Object.assign({}, HIT_H, { torso: -22, head: -22 })), K(26, Object.assign({}, HIT_H, { torso: -24 }))] });
  def('hit_c', { blend: 2, frames: [K(0, CROUCH), K(4, Object.assign({}, CROUCH, { torso: 4, head: -22, uN: -8, fN: -38 }), 'out'), K(14, Object.assign({}, CROUCH, { torso: 6, head: -18, uN: -8, fN: -38 }))] });

  // ---- нокдаун / KO / подъём ----
  def('knockdown', { blend: 2, frames: [
    K(0, HIT_H),
    K(10, { rot: -38, torso: -10, head: -16, uN: -30, fN: -30, uF: -42, fF: -20, tN: -34, sN: 40, tF: -12, sF: 50 }, 'out'),
    K(22, { rot: -78, torso: -4, head: -12, uN: -24, fN: -20, uF: -34, fF: -14, tN: -16, sN: 24, tF: -6, sF: 20 }, 'in'),
    K(28, Object.assign({}, LYING, { rot: -90 }), 'out'),
    K(34, Object.assign({}, LYING, { rot: -86, head: -14 }), 'io'),
    K(42, LYING, 'io'),
    K(60, LYING, 'lin'),
  ] });
  def('ko', { blend: 2, frames: anims.knockdown.frames.map(f => Object.assign({}, f)) });
  def('getup', { blend: 2, frames: [
    K(0, LYING),
    K(12, { rot: -30, torso: 28, head: 4, tN: -74, sN: 96, tF: -20, sF: 86, uN: 10, fN: -40, uF: 20, fF: -50 }, 'io'),
    K(24, CROUCH, 'io'),
    K(34, {}, 'io'),
  ] });

  // ---- оглушённый, на коленях (для «FINISH HIM!») ----
  const KNEEL = { torso: 14, head: 16, tN: -84, sN: 108, tF: 4, sF: 150, uN: 8, fN: -14, uF: 3, fF: -12 };
  def('stun', { loop: true, frames: [K(0, KNEEL), K(30, Object.assign({}, KNEEL, { torso: 19, head: 22, uN: 12 })), K(60, KNEEL)] });

  // ---- стойка перед боем и поза победы ----
  def('intro', { blend: 3, frames: [
    K(0, { torso: 2, head: 0, uN: 2, fN: -8, uF: 4, fF: -6, tN: -6, sN: 6, tF: 6, sF: 6 }),
    K(28, { torso: -8, head: -10, uN: -10, fN: -16, uF: -6, fF: -14, tN: -8, sN: 8, tF: 8, sF: 8 }, 'io'),
    K(52, { torso: 10, head: 2, uN: -70, fN: -110, uF: -80, fF: -108, tN: -22, sN: 26, tF: 20, sF: 26 }, 'out'),
    K(70, {}, 'io'),
  ] });
  const WIN_A = { torso: -8, head: -14, uN: -172, fN: -6, uF: -160, fF: -14, tN: -16, sN: 18, tF: 14, sF: 20 };
  def('win', { loop: true, blend: 4, frames: [
    K(0, WIN_A), K(18, Object.assign({}, WIN_A, { torso: -12, uN: -178, uF: -170, tN: -6, sN: 8, tF: 6, sF: 8 })), K(38, WIN_A),
  ] });

  // ============================ интерфейс модуля ===============================
  const Anim = {
    S, KEYS, anims,
    get(name) { return anims[name] || anims.idle; },

    /** Поза анимации на кадре t (дробное значение ок). */
    sample(name, t) {
      const a = Anim.get(name);
      const L = a.length;
      if (a.loop) { t = ((t % L) + L) % L; if (a.reverse) t = L - t; }
      else { t = Math.max(0, Math.min(L, t)); }
      const f = a.frames;
      let i = 0;
      while (i < f.length - 2 && t > f[i + 1].t) i++;
      const A = f[i], B = f[Math.min(i + 1, f.length - 1)];
      const span = B.t - A.t;
      const k = span > 0 ? EASE[B.e || 'io']((t - A.t) / span) : 1;
      const out = {};
      for (const key of KEYS) out[key] = A.p[key] + (B.p[key] - A.p[key]) * Math.max(0, Math.min(1, k));
      return out;
    },

    /** Линейное смешивание двух поз (для плавных переходов). */
    lerp(a, b, k) {
      const out = {};
      for (const key of KEYS) out[key] = a[key] + (b[key] - a[key]) * k;
      return out;
    },
    ease: EASE,
    list() { return Object.keys(anims); },
    length(name) { return Anim.get(name).length; },
    isLoop(name) { return !!Anim.get(name).loop; },
  };
  window.Anim = Anim;
})();

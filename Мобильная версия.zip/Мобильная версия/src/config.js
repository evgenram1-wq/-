// ============================================================================
//  config.js — все настройки игры в одном месте (урон, скорости, время раунда…)
//  Кадры считаются при 60 FPS: 60 кадров = 1 секунда.
// ============================================================================
window.CFG = {
  mobile: true,               // мобильная версия: сенсорное управление, облегчённая графика
  renderScale: 0.75,          // разрешение отрисовки относительно 1280x720 (авто-снижение при тормозах)
  fxDensity: 0.6,             // доля частиц (искры, пыль) от обычной версии
  // --- экран и мир -----------------------------------------------------------
  W: 1280, H: 720,            // логическое разрешение (канвас масштабируется под окно)
  groundY: 610,               // линия пола на экране
  stageWidth: 1800,           // ширина арены (мир шире экрана, камера едет за бойцами)
  maxDistance: 1000,          // бойцы не могут разойтись дальше этого (чтобы влезть в кадр)
  wallMargin: 70,             // отступ от края арены
  fighterHeight: 340,         // высота бойца на экране, px

  // --- бой -------------------------------------------------------------------
  roundTime: 60,              // секунд на раунд
  roundsToWin: 2,             // «до двух побед»
  maxHealth: 100,
  meterMax: 100,              // шкала спецудара
  specialCost: 50,
  meterOnHit: 1.0,            // множитель: сколько шкалы за нанесённый урон
  meterOnDamaged: 0.6,        // …и за полученный
  comboScaling: 0.88,         // каждый следующий удар комбо слабее (множитель)
  chipDamage: 0.12,           // доля урона, проходящая через блок
  throwRange: 105,            // дальность броска (расстояние между бойцами, px)

  // --- движение --------------------------------------------------------------
  walkSpeed: 3.4,
  backSpeed: 2.7,
  jumpVel: -17.5,
  gravity: 0.85,
  airSpeed: 3.2,
  jumpSquat: 5,               // кадры приседа перед прыжком
  landRecovery: 5,
  pushDist: 62,               // минимальное расстояние между телами
  friction: 0.84,             // затухание отбрасывания

  // --- анимации --------------------------------------------------------------
  blendFrames: 5,             // плавное смешивание поз при смене состояния (4–6 кадров)

  // --- эффекты ---------------------------------------------------------------
  hitstopLight: 4, hitstopHeavy: 7, hitstopKO: 14,
  shakeHeavy: 9, shakeKO: 18, shakeLight: 3,
  koSlowFrames: 90,           // замедление при нокауте
  koSlowFactor: 0.28,

  // --- удары: startup / active / recovery (кадры) ----------------------------
  // limb: какой конец конечности даёт хитбокс (handN/handF – кисти, toeN/toeF – стопы)
  // height: 'mid' (блок и стоя, и сидя), 'low' (блок только сидя), 'air'
  moves: {
    light: { anim: 'light', startup: 5, active: 3, recovery: 9, damage: 4, hitstun: 24, blockstun: 12,
             knock: 3.2, blockKnock: 2.2, hitstop: 4, limb: 'handN', radius: 26, height: 'mid', meter: 4, lunge: 0, sfx: 'punch' },
    heavy: { anim: 'heavy', startup: 12, active: 4, recovery: 17, damage: 9, hitstun: 32, blockstun: 16,
             knock: 7, blockKnock: 4, hitstop: 8, limb: 'handF', radius: 30, height: 'mid', meter: 8, lunge: 3.6, sfx: 'heavy', shake: 8 },
    kick:  { anim: 'kick', startup: 8, active: 4, recovery: 14, damage: 7, hitstun: 27, blockstun: 14,
             knock: 5.5, blockKnock: 3.4, hitstop: 6, limb: 'toeN', radius: 32, height: 'mid', meter: 6, lunge: 1.2, sfx: 'kick', shake: 4 },
    sweep: { anim: 'sweep', startup: 9, active: 5, recovery: 17, damage: 7, hitstun: 30, blockstun: 12,
             knock: 3, blockKnock: 2, hitstop: 6, limb: 'toeN', radius: 30, height: 'low', meter: 6, knockdown: true, sfx: 'kick', shake: 6 },
    jpunch: { anim: 'jpunch', startup: 4, active: 14, recovery: 4, damage: 5, hitstun: 24, blockstun: 11,
              knock: 3, blockKnock: 2, hitstop: 4, limb: 'handN', radius: 28, height: 'air', meter: 4, sfx: 'punch' },
    jkick:  { anim: 'jkick', startup: 5, active: 16, recovery: 4, damage: 7, hitstun: 26, blockstun: 13,
              knock: 4.5, blockKnock: 3, hitstop: 5, limb: 'toeN', radius: 32, height: 'air', meter: 5, sfx: 'kick' },
    throw: { anim: 'throw', startup: 6, active: 2, recovery: 24, damage: 11, hitstun: 40, knock: 6,
             hitstop: 8, limb: 'handN', radius: 30, height: 'throw', meter: 10, knockdown: true, sfx: 'heavy', shake: 10 },
  },

  // --- спецудары (один общий код, у каждого бойца свой тип) ------------------
  // type: proj (волна энергии), dash (рывок), wave (удар по земле), rise (апперкот-прыжок)
  specials: {
    proj: { anim: 'special_proj', startup: 20, active: 3, recovery: 26, damage: 11, hitstun: 26, blockstun: 16,
            knock: 8, blockKnock: 5, hitstop: 8, speed: 10, radius: 34, meter: 0, color: '#ffb02e', shake: 10, name: 'ВОЛНА' },
    hammer: { anim: 'special_proj', startup: 20, active: 3, recovery: 26, damage: 12, hitstun: 28, blockstun: 16,
            knock: 8.5, blockKnock: 5, hitstop: 9, speed: 9.5, radius: 32, meter: 0, kind: 'hammer', shake: 11, name: 'МОЛОТОК' },
    spit: { anim: 'special_spit', startup: 16, active: 3, recovery: 24, damage: 7, hitstun: 24, blockstun: 14,
            knock: 4, blockKnock: 3, hitstop: 6, speed: 11, radius: 30, meter: 0, kind: 'spit', shake: 6, name: 'ЯД',
            dot: { n: 4, per: 1, every: 16 } },
    grind: { anim: 'special_grind', startup: 12, active: 36, recovery: 24, damage: 4, hitstun: 22, blockstun: 12,
            knock: 2.2, blockKnock: 1.5, hitstop: 3, range: 150, every: 6, meter: 0, shake: 5, name: 'БОЛГАРКА' },
    bottle: { anim: 'special_bottles', startup: 14, active: 20, recovery: 22, damage: 5, hitstun: 24, blockstun: 12,
            knock: 4, blockKnock: 3, hitstop: 5, radius: 26, meter: 0, kind: 'bottle', shake: 5, name: 'БУТЫЛКИ' },
    dash: { anim: 'special_dash', startup: 12, active: 16, recovery: 26, damage: 13, hitstun: 26, blockstun: 16,
            knock: 8, blockKnock: 5, hitstop: 8, speed: 9.5, radius: 34, limb: 'handN', meter: 0, color: '#ff4a2e', shake: 10, name: 'РЫВОК' },
    wave: { anim: 'special_wave', startup: 24, active: 4, recovery: 28, damage: 12, hitstun: 30, blockstun: 16,
            knock: 8, blockKnock: 5, hitstop: 9, range: 230, meter: 0, color: '#ffd15c', shake: 16, knockdown: true, name: 'УДАР ЗЕМЛИ' },
    rise: { anim: 'special_rise', startup: 8, active: 14, recovery: 28, damage: 13, hitstun: 36, blockstun: 16,
            knock: 4, blockKnock: 4, hitstop: 9, limb: 'handN', radius: 36, meter: 0, color: '#ff6a3a', shake: 14, knockdown: true, name: 'АППЕРКОТ' },
  },
  // Особые спецудары бойцов (кроме общих выше):
  //  proj + kind 'hammer' – Денис кидается молотком;   spit – Женя плюётся зелёной жидкостью (+ яд);
  //  grind – Леша сражается болгаркой (серия ударов вплотную);   bottle – Никита кидается бутылками (3 штуки по дуге)
  // Для нового бойца тип выбирается по имени автоматически (specialOrder).
  specialByName: { 'Денис': 'hammer', 'Женя': 'spit', 'Леша': 'grind', 'Никита': 'bottle' },
  specialOrder: ['proj', 'dash', 'wave', 'rise', 'hammer', 'spit', 'grind', 'bottle'],

  // --- особенности бойцов (по имени) -------------------------------------------
  //  speed – множитель скорости ходьбы/прыжка;  dmg – множитель всего урона;
  //  punch / kick – множители урона рук / ног;
  //  stumble – шанс споткнуться на каждый кадр ходьбы (0.0012 ≈ раз в 14 секунд пути);
  //  double – шанс, что удар окажется «сдвоенным» (бьёт ещё раз сразу же)
  traits: {
    'Денис': { speed: 0.84, dmg: 1.14 },
    'Женя':  { speed: 1.2,  dmg: 0.86 },
    'Леша':  { stumble: 0.0012, double: 0.28 },
    'Никита': { punch: 1.22, kick: 0.78 },
  },

  // --- случайные события (собаки), папка «случайные события» -------------------------
  //  type lick – лижет и лечит (heal – всего HP за время одного проигрыша звука × plays);
  //  type bite – лает и кусает (dmg – всего урона; собака не добивает, оставляет минимум 1 HP)
  eventChance: 0.9,           // шанс, что в раунде появится собака
  eventMinSec: 6, eventMaxSec: 42,   // в какой момент раунда (секунды от FIGHT)
  events: {
    'булка': { type: 'lick', heal: 20, plays: 1 },
    'малыш': { type: 'bite', dmg: 12, plays: 2 },
  },
  dogHeight: 150,             // высота собаки на экране, px
  // --- ИИ ---------------------------------------------------------------------
  // reaction: задержка реакции (кадры), block: шанс заблокировать, aggression: частота атак,
  // think: как часто принимает решения (кадры)
  ai: {
    easy:   { reaction: 26, block: 0.12, aggression: 0.35, think: 22, special: 0.10, jump: 0.04 },
    normal: { reaction: 13, block: 0.45, aggression: 0.60, think: 14, special: 0.30, jump: 0.06 },
    hard:   { reaction: 5,  block: 0.80, aggression: 0.85, think: 8,  special: 0.55, jump: 0.08 },
  },
  aiLabels: { easy: 'ЛЁГКИЙ', normal: 'СРЕДНИЙ', hard: 'ТЯЖЁЛЫЙ' },

  // --- управление (e.code – не зависит от раскладки: русская и английская одинаково) ----
  controls: [
    { name: 'ИГРОК 1', left: 'KeyA', right: 'KeyD', up: 'KeyW', down: 'KeyS',
      light: 'KeyF', heavy: 'KeyG', kick: 'KeyH', block: 'KeyR', throw: 'KeyT', special: 'KeyY' },
    { name: 'ИГРОК 2', left: 'ArrowLeft', right: 'ArrowRight', up: 'ArrowUp', down: 'ArrowDown',
      light: 'KeyJ', heavy: 'KeyK', kick: 'KeyL', block: 'KeyU', throw: 'KeyI', special: 'KeyO' },
  ],
  // Геймпад (стандартная раскладка): кнопки по номерам
  pad: { light: 2, heavy: 3, kick: 0, block: 1, throw: 4, special: 5, jump: 12, pause: 9, deadzone: 0.45 },

  // --- голоса ----------------------------------------------------------------
  voiceHitChance: 0.35,       // шанс крикнуть при сильном ударе
  voiceCooldown: 90,          // кадров между репликами одного бойца
  masterVolume: 0.8, musicVolume: 0.2,   // музыка не громче 20% и тише голосов
  musicMax: 0.2,
  sfxVolume: 0.8, voiceVolume: 1.0,
};

// ============================================================================
//  effects.js — искры, вспышки попадания, ударные волны, пыль, следы ударов,
//  тряска экрана и вспышка на весь экран.
// ============================================================================
(function () {
  const C = window.CFG;
  const rnd = (a, b) => a + Math.random() * (b - a);

  const Fx = {
    parts: [], rings: [], texts: [], shakeAmt: 0, shakeX: 0, shakeY: 0, flashA: 0, flashColor: '255,255,255',
  };

  Fx.reset = function () { Fx.parts.length = 0; Fx.rings.length = 0; Fx.texts.length = 0; Fx.shakeAmt = 0; Fx.flashA = 0; };

  /** Искры попадания, летят в сторону dir (1/-1). */
  Fx.sparks = function (x, y, dir, n, color, speed) {
    n = Math.max(1, Math.round(n * (C.fxDensity || 1)));
    for (let i = 0; i < n; i++) {
      const a = rnd(-1.1, 1.1) + (dir > 0 ? 0 : Math.PI), sp = rnd(3, 11) * (speed || 1);
      Fx.parts.push({ t: 'spark', x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 1.5, life: rnd(10, 22), max: 22, g: 0.35,
        c: color || (Math.random() < 0.5 ? '#ffd15c' : '#ff5a3a'), w: rnd(1.5, 3) });
    }
  };
  /** Вспышка попадания: кольцо + звезда. power 1..3 */
  Fx.hit = function (x, y, dir, power, blocked) {
    power = power || 1;
    Fx.rings.push({ x, y, r: 6, vr: 5 + power * 2.5, life: 10 + power * 2, max: 10 + power * 2, c: blocked ? '170,200,255' : '255,214,120', w: 4, kind: 'ring' });
    Fx.rings.push({ x, y, r: 2, vr: 0, life: 7, max: 7, c: blocked ? '200,220,255' : '255,255,255', w: 0, kind: 'star', size: 26 + power * 12, rot: rnd(0, 3) });
    Fx.sparks(x, y, dir, blocked ? 6 : 8 + power * 5, blocked ? '#bcd4ff' : null, 0.8 + power * 0.25);
  };
  Fx.dust = function (x, y, n, spread) {
    n = Math.max(1, Math.round(n * (C.fxDensity || 1)));
    for (let i = 0; i < n; i++) {
      Fx.parts.push({ t: 'dust', x: x + rnd(-1, 1) * (spread || 20), y: y - rnd(0, 4), vx: rnd(-1.3, 1.3), vy: rnd(-1.4, -0.3), life: rnd(16, 30), max: 30, r: rnd(4, 9), c: '160,130,115' });
    }
  };
  Fx.shockwave = function (x, y, size, color) {
    Fx.rings.push({ x, y, r: 10, vr: size / 14, life: 18, max: 18, c: color || '255,200,90', w: 7, kind: 'ground' });
  };
  Fx.burstFlash = function (x, y, size, color) {
    Fx.rings.push({ x, y, r: 10, vr: size / 12, life: 14, max: 14, c: color || '255,230,170', w: 10, kind: 'ring' });
    Fx.rings.push({ x, y, r: 2, vr: 0, life: 12, max: 12, c: '255,255,255', w: 0, kind: 'star', size: size * 0.8, rot: 0 });
  };
  Fx.text = function (x, y, s, color, size, life) {
    Fx.texts.push({ x, y, s, c: color || '#ffd15c', size: size || 36, life: life || 50, max: life || 50 });
  };
  Fx.shake = function (power) { Fx.shakeAmt = Math.max(Fx.shakeAmt, power); };
  Fx.flash = function (a, color) { Fx.flashA = a; Fx.flashColor = color || '255,255,255'; };

  Fx.update = function () {
    for (const p of Fx.parts) {
      p.x += p.vx; p.y += p.vy; p.life--;
      if (p.t === 'spark') { p.vy += p.g; p.vx *= 0.96; }
      else { p.vx *= 0.96; p.vy *= 0.97; p.r += 0.25; }
    }
    Fx.parts = Fx.parts.filter(p => p.life > 0);
    for (const r of Fx.rings) { r.r += r.vr; r.vr *= 0.9; r.life--; }
    Fx.rings = Fx.rings.filter(r => r.life > 0);
    for (const t of Fx.texts) { t.life--; t.y -= 0.4; }
    Fx.texts = Fx.texts.filter(t => t.life > 0);
    if (Fx.shakeAmt > 0.2) {
      Fx.shakeX = (Math.random() * 2 - 1) * Fx.shakeAmt; Fx.shakeY = (Math.random() * 2 - 1) * Fx.shakeAmt * 0.7; Fx.shakeAmt *= 0.86;
    } else { Fx.shakeAmt = 0; Fx.shakeX = Fx.shakeY = 0; }
    if (Fx.flashA > 0) Fx.flashA = Math.max(0, Fx.flashA - 0.05);
  };

  /** Рисуется в мировых координатах поверх бойцов. */
  Fx.draw = function (ctx) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const p of Fx.parts) {
      const a = Math.max(0, p.life / p.max);
      if (p.t === 'spark') {
        ctx.strokeStyle = p.c; ctx.globalAlpha = a; ctx.lineWidth = p.w;
        ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * 1.8, p.y - p.vy * 1.8); ctx.stroke();
      }
    }
    for (const r of Fx.rings) {
      const a = r.life / r.max;
      if (r.kind === 'ring') {
        ctx.strokeStyle = 'rgba(' + r.c + ',' + a.toFixed(2) + ')'; ctx.lineWidth = r.w * a + 1;
        ctx.beginPath(); ctx.arc(r.x, r.y, r.r, 0, 7); ctx.stroke();
      } else if (r.kind === 'ground') {
        ctx.strokeStyle = 'rgba(' + r.c + ',' + a.toFixed(2) + ')'; ctx.lineWidth = r.w * a + 1;
        ctx.beginPath(); ctx.ellipse(r.x, r.y, r.r * 2.2, r.r * 0.35, 0, 0, 7); ctx.stroke();
      } else if (r.kind === 'star') {
        ctx.save(); ctx.translate(r.x, r.y); ctx.rotate(r.rot);
        ctx.fillStyle = 'rgba(' + r.c + ',' + (a * 0.9).toFixed(2) + ')';
        const s = r.size * (0.6 + 0.4 * a);
        ctx.beginPath();
        for (let i = 0; i < 8; i++) { const ang = i * Math.PI / 4, rr = i % 2 ? s * 0.28 : s; ctx.lineTo(Math.cos(ang) * rr, Math.sin(ang) * rr); }
        ctx.closePath(); ctx.fill(); ctx.restore();
      }
    }
    ctx.restore();
    // пыль (обычное наложение)
    for (const p of Fx.parts) {
      if (p.t !== 'dust') continue;
      const a = Math.max(0, p.life / p.max) * 0.45;
      ctx.fillStyle = 'rgba(' + p.c + ',' + a.toFixed(2) + ')';
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
    }
  };

  /** След удара по траектории кисти/стопы: points – массив {x,y}. */
  Fx.drawTrail = function (ctx, pts, color, width) {
    if (pts.length < 2) return;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    for (let i = 1; i < pts.length; i++) {
      const a = i / pts.length;
      ctx.strokeStyle = 'rgba(' + color + ',' + (a * 0.75).toFixed(2) + ')';
      ctx.lineWidth = width * a;
      ctx.beginPath(); ctx.moveTo(pts[i - 1].x, pts[i - 1].y); ctx.lineTo(pts[i].x, pts[i].y); ctx.stroke();
    }
    ctx.restore();
  };

  Fx.drawTexts = function (ctx) {
    for (const t of Fx.texts) {
      const a = Math.min(1, t.life / (t.max * 0.5));
      ctx.save(); ctx.globalAlpha = a; ctx.font = '900 ' + t.size + 'px Impact, "Arial Black", sans-serif'; ctx.textAlign = 'center';
      ctx.lineWidth = 6; ctx.strokeStyle = '#1a0508'; ctx.strokeText(t.s, t.x, t.y);
      ctx.fillStyle = t.c; ctx.fillText(t.s, t.x, t.y); ctx.restore();
    }
  };

  window.Fx = Fx;
})();

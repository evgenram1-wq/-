// ============================================================================
//  touch.js — сенсорное управление для телефона (мобильная версия).
//  Слева – плавающий джойстик (влево/вправо, вверх = прыжок, вниз = присед),
//  справа – шесть кнопок (рука, сила, нога, блок, бросок, спец). Всё рисуется прямо на канвасе.
//  Кнопки включают те же «клавиши» первого игрока, поэтому боевой код не меняется.
//  Меню управляются касаниями: тап по пункту / бойцу / арене, кнопка «НАЗАД».
// ============================================================================
(function () {
  const C = window.CFG, W = C.W, H = C.H;
  const canvas = document.getElementById('game');
  const K = C.controls[0];
  const BTN = [
    { a: 'light', t: 'РУКА', x: 985, y: 598, r: 50 }, { a: 'heavy', t: 'СИЛА', x: 1100, y: 598, r: 50 }, { a: 'kick', t: 'НОГА', x: 1215, y: 598, r: 50 },
    { a: 'block', t: 'БЛОК', x: 985, y: 478, r: 46 }, { a: 'throw', t: 'БРОСОК', x: 1100, y: 478, r: 46 }, { a: 'special', t: 'СПЕЦ', x: 1215, y: 478, r: 46 },
  ];
  const PAUSE = { x: 640, y: 122, r: 26 };
  const Touch = { ptrs: new Map(), stick: null, fsTried: false };
  const dirs = { left: false, right: false, up: false, down: false };
  const down = {};

  function pos(e) { const r = canvas.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * W, (e.clientY - r.top) / r.height * H]; }
  function inMatch() { const s = window.App && App.scene; return s === Scenes.match && s.m && !s.m.paused && s.m.phase !== 'matchEnd'; }
  function setKey(a, v) { Input.keys[K[a]] = !!v; }
  function btnAt(x, y) { for (const b of BTN) if ((x - b.x) ** 2 + (y - b.y) ** 2 <= (b.r + 12) ** 2) return b; return null; }

  function refresh() {                                  // пересчитать «нажатые клавиши»
    const held = { left: false, right: false, up: false, down: false };
    for (const a of ['light', 'heavy', 'kick', 'block', 'throw', 'special']) down[a] = false;
    for (const p of Touch.ptrs.values()) {
      if (p.kind === 'stick') {
        const dx = p.x - p.ox, dy = p.y - p.oy;
        if (dx < -26) held.left = true; if (dx > 26) held.right = true;
        if (dy < -48) held.up = true; if (dy > 40) held.down = true;
      } else if (p.kind === 'btn' && p.btn) down[p.btn.a] = true;
    }
    for (const a of Object.keys(held)) setKey(a, held[a]);
    for (const a of ['light', 'heavy', 'kick', 'block', 'throw', 'special']) setKey(a, down[a]);
    Object.assign(dirs, held);
  }
  function releaseAll() { Touch.ptrs.clear(); refresh(); }

  function fullscreen() {
    if (Touch.fsTried) return; Touch.fsTried = true;
    try {
      const el = document.documentElement;
      const r = el.requestFullscreen ? el.requestFullscreen() : (el.webkitRequestFullscreen && el.webkitRequestFullscreen());
      Promise.resolve(r).then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) {} }).catch(() => {});
    } catch (e) { /* не страшно – игра работает и без полного экрана */ }
  }

  // ---- касания в меню: те же события, что и с клавиатуры ----
  function menuTap(x, y) {
    const sc = App.scene, push = (a) => Input.push(-1, a);
    const back = { x: 90, y: 52, w: 130, h: 44 };
    const hasBack = [Scenes.diff, Scenes.select, Scenes.arena].includes(sc);
    if (hasBack && x < back.x + back.w && y < back.y + back.h && x > 10 && y > 20) { push('back'); return; }
    if (sc === Scenes.title) { push('ok'); return; }
    if (sc === Scenes.menu) {
      const i = Math.floor((y - 300 + 50) / 78), n = sc.items().length;
      if (i >= 0 && i < n) { sc.sel = i; push('ok'); }
    } else if (sc === Scenes.diff) {
      const i = Math.floor((y - 320 + 60) / 90);
      if (i >= 0 && i < 3) { sc.sel = i; push('ok'); }
    } else if (sc === Scenes.select) {
      const n = App.chars.length, cols = sc.cols, cw = 190, ch = 215, gap = 22, x0 = (W - (cols * cw + (cols - 1) * gap)) / 2, y0 = 150;
      for (let i = 0; i < n; i++) {
        const cx = x0 + (i % cols) * (cw + gap), cy = y0 + Math.floor(i / cols) * (ch + gap);
        if (x >= cx && x <= cx + cw && y >= cy && y <= cy + ch) { if (!sc.done) sc.cur[sc.stage] = i; push('ok'); break; }
      }
    } else if (sc === Scenes.arena) {
      const n = Arenas.list.length, cw = 360, ch = 202, gap = 36, x0 = (W - (n * cw + (n - 1) * gap)) / 2, y0 = 190;
      for (let i = 0; i < n; i++) {
        const cx = x0 + i * (cw + gap);
        if (x >= cx && x <= cx + cw && y >= y0 && y <= y0 + ch + 60) { sc.sel = i; push('ok'); break; }
      }
    }
  }
  function matchMenuTap(x, y) {
    const m = App.scene.m;
    if (m.paused) {
      if (Math.abs(y - 190) < 34) { m.pauseSel = 0; Input.push(-1, 'ok'); }
      else if (Math.abs(y - 242) < 34) { m.pauseSel = 1; Input.push(-1, 'ok'); }
      else Input.push(-1, 'pause');
    } else if (m.phase === 'matchEnd' && m.endReady) {
      if (Math.abs(y - 360) < 40) { m.resultSel = 0; Input.push(-1, 'ok'); }
      else if (Math.abs(y - 430) < 40) { m.resultSel = 1; Input.push(-1, 'ok'); }
    }
  }

  function down_(e) {
    e.preventDefault();
    GameAudio.unlock(); fullscreen();
    const [x, y] = pos(e);
    if (App.scene !== Scenes.match) { menuTap(x, y); return; }
    const m = App.scene.m;
    if (m.paused || m.phase === 'matchEnd') { matchMenuTap(x, y); return; }
    if ((x - PAUSE.x) ** 2 + (y - PAUSE.y) ** 2 <= (PAUSE.r + 14) ** 2) { Input.push(-1, 'pause'); return; }
    try { canvas.setPointerCapture(e.pointerId); } catch (er) {}
    const b = btnAt(x, y);
    if (b) Touch.ptrs.set(e.pointerId, { kind: 'btn', btn: b, x, y });
    else if (x < W * 0.55 && !Array.from(Touch.ptrs.values()).some(p => p.kind === 'stick')) Touch.ptrs.set(e.pointerId, { kind: 'stick', ox: x, oy: Math.max(y, 300), x, y });
    refresh();
  }
  function move_(e) {
    const p = Touch.ptrs.get(e.pointerId); if (!p) return;
    e.preventDefault();
    const [x, y] = pos(e); p.x = x; p.y = y;
    if (p.kind === 'btn') p.btn = btnAt(x, y) || p.btn;               // можно «перетащить» палец на соседнюю кнопку
    else {                                                            // «подтягиваем» центр джойстика за пальцем
      const dx = x - p.ox, lim = 70; if (Math.abs(dx) > lim) p.ox = x - Math.sign(dx) * lim;
    }
    refresh();
  }
  function up_(e) { if (Touch.ptrs.delete(e.pointerId)) refresh(); }

  canvas.addEventListener('pointerdown', down_);
  canvas.addEventListener('pointermove', move_);
  canvas.addEventListener('pointerup', up_);
  canvas.addEventListener('pointercancel', up_);
  canvas.addEventListener('contextmenu', e => e.preventDefault());
  document.addEventListener('visibilitychange', releaseAll);

  // ---- отрисовка поверх игры ----
  function pill(ctx, x, y, r, label, on, hot) {
    ctx.beginPath(); ctx.arc(x, y, r, 0, 7);
    ctx.fillStyle = on ? 'rgba(255,90,50,.55)' : (hot ? 'rgba(255,200,60,.38)' : 'rgba(20,8,12,.5)'); ctx.fill();
    ctx.lineWidth = 3; ctx.strokeStyle = on ? '#ffd15c' : (hot ? '#ffd15c' : 'rgba(233,220,200,.75)'); ctx.stroke();
    ctx.fillStyle = '#f3e6d0'; ctx.font = '700 ' + (r > 47 ? 19 : 17) + 'px "Segoe UI",Arial,sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(label, x, y + 1);
  }
  Touch.draw = function (ctx) {
    const sc = App.scene;
    ctx.save();
    if (sc === Scenes.diff || sc === Scenes.select || sc === Scenes.arena) {
      ctx.fillStyle = 'rgba(20,8,12,.75)'; ctx.fillRect(10, 20, 210, 52);
      ctx.strokeStyle = '#d9a93a'; ctx.lineWidth = 2; ctx.strokeRect(10, 20, 210, 52);
      ctx.fillStyle = '#f3e6d0'; ctx.font = '700 24px "Segoe UI",Arial,sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('‹  НАЗАД', 115, 47);
    }
    if (sc === Scenes.match && sc.m && !sc.m.paused && sc.m.phase !== 'matchEnd') {
      const m = sc.m, human = m.fighters.find((f, i) => m.ctrl[i].kind === 'human');
      pill(ctx, PAUSE.x, PAUSE.y, PAUSE.r, 'II', false);
      // джойстик
      const st = Array.from(Touch.ptrs.values()).find(p => p.kind === 'stick');
      const bx = st ? st.ox : 170, by = st ? st.oy : 560;
      ctx.globalAlpha = st ? 0.9 : 0.5;
      ctx.beginPath(); ctx.arc(bx, by, 78, 0, 7); ctx.fillStyle = 'rgba(20,8,12,.35)'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(233,220,200,.7)'; ctx.stroke();
      const kx = st ? Math.max(-60, Math.min(60, st.x - st.ox)) : 0, ky = st ? Math.max(-60, Math.min(60, st.y - st.oy)) : 0;
      ctx.beginPath(); ctx.arc(bx + kx, by + ky, 34, 0, 7); ctx.fillStyle = 'rgba(255,200,120,.55)'; ctx.fill(); ctx.strokeStyle = '#ffd15c'; ctx.stroke();
      if (!st) { ctx.fillStyle = 'rgba(243,230,208,.8)'; ctx.font = '600 16px "Segoe UI",Arial,sans-serif'; ctx.textAlign = 'center'; ctx.fillText('↑ прыжок', bx, by - 92); ctx.fillText('← →', bx, by + 110); }
      ctx.globalAlpha = 1;
      for (const b of BTN) pill(ctx, b.x, b.y, b.r, b.t, !!down[b.a], b.a === 'special' && human && human.meter >= C.specialCost);
    }
    ctx.restore();
  };
  Touch.reset = releaseAll;
  window.Touch = Touch;
})();

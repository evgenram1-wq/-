// ============================================================================
//  arenas.js — арены с параллаксом: «Мрачный храм» и «Ночной город» нарисованы кодом,
//  «Заброшенный цех» – из вашего фото «Локация/цех.jpg» (любые фото из папки «Локация»
//  автоматически становятся аренами). Слои заранее рисуются в буферы, камера двигает их с разной скоростью.
// ============================================================================
(function () {
  const C = window.CFG;
  const W = C.W, H = C.H, SW = C.stageWidth, GY = C.groundY;
  const PAN = SW - W;

  // детерминированный генератор случайных чисел (чтобы арена выглядела одинаково при каждом запуске)
  function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }

  function layerCanvas(factor, fn, extra) {
    const w = Math.ceil(W + PAN * factor + (extra || 0));
    const c = document.createElement('canvas'); c.width = w; c.height = H;
    fn(c.getContext('2d'), w, H);
    return { canvas: c, factor };
  }
  function drawLayers(ctx, layers, camX) {
    for (const l of layers) ctx.drawImage(l.canvas, Math.round(-camX * l.factor), 0);
  }
  function glow(ctx, x, y, r, color, a) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, color.replace('A', a)); g.addColorStop(1, color.replace('A', 0));
    ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }

  // =========================== МРАЧНЫЙ ХРАМ ==================================
  function makeTemple() {
    const far = layerCanvas(0.08, (g, w, h) => {
      const sky = g.createLinearGradient(0, 0, 0, 540);
      sky.addColorStop(0, '#0b0306'); sky.addColorStop(0.55, '#2a0a12'); sky.addColorStop(1, '#6a1a1c');
      g.fillStyle = sky; g.fillRect(0, 0, w, h);
      glow(g, w * 0.55, 210, 330, 'rgba(255,70,40,A)', 0.55);
      g.fillStyle = '#c4301f'; g.beginPath(); g.arc(w * 0.55, 210, 95, 0, 7); g.fill();       // багровая луна
      g.fillStyle = 'rgba(255,190,120,.25)'; g.beginPath(); g.arc(w * 0.55 - 20, 190, 70, 0, 7); g.fill();
      const r = rng(7);
      g.fillStyle = '#16060b';                                                                  // горы
      g.beginPath(); g.moveTo(0, 540);
      for (let x = 0; x <= w; x += 40) g.lineTo(x, 380 + Math.sin(x * 0.01) * 60 + r() * 50);
      g.lineTo(w, 540); g.fill();
    });
    const mid = layerCanvas(0.32, (g, w, h) => {
      const r = rng(11);
      for (let x = -40; x < w + 80; x += 250) {                                                 // колоннада с арками
        const grad = g.createLinearGradient(x, 0, x + 70, 0);
        grad.addColorStop(0, '#1b0b10'); grad.addColorStop(0.5, '#33161c'); grad.addColorStop(1, '#14080c');
        g.fillStyle = grad; g.fillRect(x, 70, 70, 480);
        g.fillStyle = '#3d1c22'; g.fillRect(x - 10, 60, 90, 22); g.fillRect(x - 10, 540, 90, 18);
        g.strokeStyle = 'rgba(217,169,58,.35)'; g.lineWidth = 2; g.strokeRect(x - 10, 60, 90, 22);
        g.fillStyle = '#10060a';                                                                // арка
        g.beginPath(); g.moveTo(x + 70, 82); g.quadraticCurveTo(x + 125, -20, x + 250 - 0, 82); g.lineTo(x + 250, 60); g.lineTo(x + 70, 60); g.fill();
        // свечение в проёмах
        glow(g, x + 160, 300, 130, 'rgba(255,80,40,A)', 0.16);
        if (r() < 0.6) {                                                                         // статуи
          g.fillStyle = '#0d0508'; g.fillRect(x + 140, 330, 40, 210); g.beginPath(); g.arc(x + 160, 320, 22, 0, 7); g.fill();
        }
      }
      g.fillStyle = 'rgba(10,2,5,.45)'; g.fillRect(0, 0, w, h);
    });
    const near = layerCanvas(0.7, (g, w, h) => {
      for (let x = 40; x < w; x += 820) {
        const grad = g.createLinearGradient(x, 0, x + 130, 0);
        grad.addColorStop(0, '#0a0407'); grad.addColorStop(0.5, '#241014'); grad.addColorStop(1, '#080305');
        g.fillStyle = grad; g.fillRect(x, 0, 130, 560);
        g.fillStyle = '#1b0b0f'; g.fillRect(x - 14, 0, 158, 40); g.fillRect(x - 14, 540, 158, 30);
        g.strokeStyle = 'rgba(217,169,58,.5)'; g.lineWidth = 3; g.strokeRect(x - 14, 540, 158, 30);
        // знамя (свой знак: кольцо и три полосы)
        g.fillStyle = '#7d1017'; g.fillRect(x + 150, 40, 70, 210);
        g.beginPath(); g.moveTo(x + 150, 250); g.lineTo(x + 185, 285); g.lineTo(x + 220, 250); g.fill();
        g.strokeStyle = '#d9a93a'; g.lineWidth = 4; g.beginPath(); g.arc(x + 185, 120, 20, 0, 7); g.stroke();
        for (let i = 0; i < 3; i++) g.fillRect(x + 170 + i * 12, 155, 6, 50);
        // кронштейн факела
        g.fillStyle = '#2b1a10'; g.fillRect(x - 40, 300, 40, 10); g.fillRect(x - 52, 280, 24, 22);
      }
    });
    const floor = layerCanvas(1, (g, w, h) => {
      const fl = g.createLinearGradient(0, 520, 0, h);
      fl.addColorStop(0, '#26121a'); fl.addColorStop(0.5, '#190b11'); fl.addColorStop(1, '#0b0408');
      g.fillStyle = fl; g.fillRect(0, 520, w, h - 520);
      g.strokeStyle = 'rgba(217,169,58,.45)'; g.lineWidth = 3; g.beginPath(); g.moveTo(0, 521); g.lineTo(w, 521); g.stroke();
      g.strokeStyle = 'rgba(0,0,0,.55)'; g.lineWidth = 2;
      const rows = [520, 540, 568, 604, 650, 710];
      for (const y of rows) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
      for (let x = -w; x < w * 2; x += 120) { g.beginPath(); g.moveTo(w / 2 + (x - w / 2) * 0.25, 520); g.lineTo(w / 2 + (x - w / 2) * 1.5, h); g.stroke(); }
      // руническое кольцо
      g.save(); g.translate(w / 2, 640); g.scale(1, 0.18);
      g.strokeStyle = 'rgba(255,60,40,.35)'; g.lineWidth = 14; g.beginPath(); g.arc(0, 0, 330, 0, 7); g.stroke();
      g.strokeStyle = 'rgba(217,169,58,.5)'; g.lineWidth = 5; g.beginPath(); g.arc(0, 0, 360, 0, 7); g.stroke();
      g.beginPath(); g.arc(0, 0, 300, 0, 7); g.stroke();
      for (let a = 0; a < 12; a++) { g.beginPath(); g.moveTo(Math.cos(a / 12 * 6.283) * 300, Math.sin(a / 12 * 6.283) * 300); g.lineTo(Math.cos(a / 12 * 6.283) * 360, Math.sin(a / 12 * 6.283) * 360); g.stroke(); }
      g.restore();
    });
    const layers = [far, mid, near];
    return {
      id: 'temple', name: 'МРАЧНЫЙ ХРАМ', shade: 'rgba(40,5,10,0.22)',
      draw(ctx, camX) { drawLayers(ctx, layers, camX); drawLayers(ctx, [floor], camX); },
      over(ctx, camX, t) {
        // факелы на ближних колоннах: мерцающее пламя + свечение
        for (let x = 40; x < SW + 820; x += 820) {
          const sx = Math.round(x - 46 - camX * 0.7);
          if (sx < -100 || sx > W + 100) continue;
          const fl = 1 + Math.sin(t * 0.31 + x) * 0.12 + Math.sin(t * 0.77 + x * 2) * 0.08;
          glow(ctx, sx, 275, 190 * fl, 'rgba(255,120,40,A)', 0.35);
          ctx.fillStyle = '#ff8a2a'; ctx.beginPath(); ctx.ellipse(sx, 272, 9 * fl, 22 * fl, 0, 0, 7); ctx.fill();
          ctx.fillStyle = '#ffe08a'; ctx.beginPath(); ctx.ellipse(sx, 278, 4.5 * fl, 12 * fl, 0, 0, 7); ctx.fill();
        }
        // дымка у пола
        const g = ctx.createLinearGradient(0, 480, 0, 640);
        g.addColorStop(0, 'rgba(120,30,40,0)'); g.addColorStop(1, 'rgba(120,30,40,.18)');
        ctx.fillStyle = g; ctx.fillRect(0, 480, W, 160);
      },
    };
  }

  // =========================== НОЧНОЙ ГОРОД ===================================
  function makeCity() {
    const far = layerCanvas(0.06, (g, w, h) => {
      const sky = g.createLinearGradient(0, 0, 0, 520);
      sky.addColorStop(0, '#04050d'); sky.addColorStop(0.6, '#1a0f2c'); sky.addColorStop(1, '#4a1636');
      g.fillStyle = sky; g.fillRect(0, 0, w, h);
      const r = rng(5);
      g.fillStyle = '#fff';
      for (let i = 0; i < 120; i++) { g.globalAlpha = 0.3 + r() * 0.7; g.fillRect(r() * w, r() * 300, 1.5, 1.5); }
      g.globalAlpha = 1;
      glow(g, w * 0.78, 130, 140, 'rgba(255,200,160,A)', 0.35);
      g.fillStyle = '#f2e4cf'; g.beginPath(); g.arc(w * 0.78, 130, 38, 0, 7); g.fill();
      g.fillStyle = '#c9b79c'; g.beginPath(); g.arc(w * 0.78 - 12, 120, 32, 0, 7); g.fill();
      // дальний горизонт
      g.fillStyle = '#150a22';
      let x = 0; while (x < w) { const bw = 40 + r() * 70, bh = 110 + r() * 200; g.fillRect(x, 520 - bh, bw, bh); x += bw + 4; }
    });
    const mid = layerCanvas(0.3, (g, w, h) => {
      const r = rng(21);
      let x = -20;
      while (x < w) {
        const bw = 120 + r() * 120, bh = 220 + r() * 220;
        const grad = g.createLinearGradient(0, 520 - bh, 0, 520);
        grad.addColorStop(0, '#120a1d'); grad.addColorStop(1, '#241028');
        g.fillStyle = grad; g.fillRect(x, 520 - bh, bw, bh);
        for (let wy = 520 - bh + 16; wy < 500; wy += 26) for (let wx = x + 12; wx < x + bw - 16; wx += 22) {
          if (r() < 0.38) { g.fillStyle = r() < 0.7 ? 'rgba(255,200,90,.75)' : 'rgba(255,70,60,.7)'; g.fillRect(wx, wy, 10, 14); }
        }
        if (r() < 0.45) {                                                                       // неоновая вывеска (абстрактные фигуры)
          const col = r() < 0.5 ? '#ff2d4d' : '#ffb02e';
          glow(g, x + bw / 2, 520 - bh + 60, 90, col === '#ff2d4d' ? 'rgba(255,45,77,A)' : 'rgba(255,176,46,A)', 0.4);
          g.strokeStyle = col; g.lineWidth = 4; g.strokeRect(x + bw / 2 - 28, 520 - bh + 40, 56, 40);
          g.beginPath(); g.moveTo(x + bw / 2 - 28, 520 - bh + 60); g.lineTo(x + bw / 2 + 28, 520 - bh + 60); g.stroke();
        }
        x += bw + 10;
      }
      g.fillStyle = 'rgba(30,8,30,.35)'; g.fillRect(0, 0, w, h);
    });
    const near = layerCanvas(0.62, (g, w, h) => {
      for (let x = 200; x < w; x += 560) {                                                      // фонари
        g.fillStyle = '#0c0810'; g.fillRect(x, 220, 10, 330); g.fillRect(x - 40, 214, 60, 8);
        const gl = g.createRadialGradient(x - 36, 230, 4, x - 36, 330, 190);
        gl.addColorStop(0, 'rgba(255,214,140,.55)'); gl.addColorStop(1, 'rgba(255,214,140,0)');
        g.fillStyle = gl; g.beginPath(); g.moveTo(x - 46, 226); g.lineTo(x - 180, 560); g.lineTo(x + 110, 560); g.lineTo(x - 26, 226); g.fill();
        g.fillStyle = '#ffe3a1'; g.fillRect(x - 46, 222, 20, 8);
      }
      for (let x = 60; x < w; x += 900) {                                                       // контейнеры
        g.fillStyle = '#1d0f1a'; g.fillRect(x, 470, 150, 90); g.fillStyle = '#2d1626'; g.fillRect(x, 470, 150, 12);
        g.strokeStyle = 'rgba(0,0,0,.5)'; for (let i = 1; i < 6; i++) { g.beginPath(); g.moveTo(x + i * 25, 482); g.lineTo(x + i * 25, 560); g.stroke(); }
      }
    });
    const floor = layerCanvas(1, (g, w, h) => {
      const fl = g.createLinearGradient(0, 520, 0, h);
      fl.addColorStop(0, '#201526'); fl.addColorStop(1, '#0a050d');
      g.fillStyle = fl; g.fillRect(0, 520, w, h - 520);
      g.fillStyle = '#383040'; g.fillRect(0, 516, w, 8);                                         // бордюр
      g.strokeStyle = 'rgba(230,200,120,.4)'; g.lineWidth = 6; g.setLineDash([60, 50]); g.beginPath(); g.moveTo(0, 690); g.lineTo(w, 690); g.stroke(); g.setLineDash([]);
      const r = rng(3);
      for (let i = 0; i < 40; i++) {                                                            // отражения неона в лужах
        const x = r() * w, y = 540 + r() * 150, len = 30 + r() * 120;
        g.fillStyle = r() < 0.5 ? 'rgba(255,45,77,.14)' : 'rgba(255,176,46,.13)';
        g.fillRect(x, y, len, 3);
      }
    });
    const layers = [far, mid, near];
    return {
      id: 'city', name: 'НОЧНОЙ ГОРОД', shade: 'rgba(20,10,50,0.28)',
      draw(ctx, camX) { drawLayers(ctx, layers, camX); drawLayers(ctx, [floor], camX); },
      over(ctx, camX, t) {
        // дождь
        ctx.strokeStyle = 'rgba(180,190,230,.28)'; ctx.lineWidth = 1.2; ctx.beginPath();
        for (let i = 0; i < 90; i++) {
          const x = ((i * 137 + t * 9) % (W + 200)) - 100, y = ((i * 71 + t * 22) % (H + 60)) - 30;
          ctx.moveTo(x, y); ctx.lineTo(x - 6, y + 22);
        }
        ctx.stroke();
      },
    };
  }

  // =========================== ЦЕХ (фото) =====================================
  // Фото растягивается так, чтобы низ стены лежал примерно на 470 px, а асфальт – под ногами бойцов.
  function makePhotoArena(item, idx) {
    const img = new Image();
    img.src = encodeURI(item.file);
    let layer = null;
    const build = () => {
      const factor = 0.12;
      const s = (W + PAN * factor + 20) / img.width;
      const groundFrac = item.groundFrac || 0.62;               // где на фото начинается пол
      const offY = 470 - groundFrac * img.height * s;
      layer = layerCanvas(factor, (g, w, h) => {
        g.fillStyle = '#000'; g.fillRect(0, 0, w, h);
        g.drawImage(img, 0, offY, img.width * s, img.height * s);
        // «тёмный красный» грейд, как у остальных арен
        g.globalCompositeOperation = 'multiply';
        g.fillStyle = 'rgb(215,175,178)'; g.fillRect(0, 0, w, h);
        g.globalCompositeOperation = 'source-over';
        const sky = g.createLinearGradient(0, 0, 0, 480);
        sky.addColorStop(0, 'rgba(25,0,10,.38)'); sky.addColorStop(1, 'rgba(25,0,10,0.02)'); g.fillStyle = sky; g.fillRect(0, 0, w, 480);
        const fl = g.createLinearGradient(0, 470, 0, h);
        fl.addColorStop(0, 'rgba(15,0,8,.02)'); fl.addColorStop(1, 'rgba(15,0,8,.4)'); g.fillStyle = fl; g.fillRect(0, 470, w, h - 470);
        const vg = g.createRadialGradient(w / 2, 330, 200, w / 2, 330, w * 0.7);
        vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.38)'); g.fillStyle = vg; g.fillRect(0, 0, w, h);
      }, 20);
    };
    if (img.complete && img.naturalWidth) build(); else img.onload = build;
    const stem = item.name.replace(/[_\-]+/g, ' ');
    return {
      id: 'photo' + idx, name: ('ЗАБРОШЕННЫЙ ' + stem).toUpperCase() === 'ЗАБРОШЕННЫЙ ЦЕХ' ? 'ЗАБРОШЕННЫЙ ЦЕХ' : stem.toUpperCase(),
      shade: 'rgba(40,10,20,0.20)',
      draw(ctx, camX) {
        if (layer) drawLayers(ctx, [layer], camX); else { ctx.fillStyle = '#1b0e12'; ctx.fillRect(0, 0, W, H); }
      },
      over(ctx, camX, t) {
        // лёгкая дымка и пыль
        const g = ctx.createLinearGradient(0, 500, 0, 660);
        g.addColorStop(0, 'rgba(110,40,40,0)'); g.addColorStop(1, 'rgba(110,40,40,.12)');
        ctx.fillStyle = g; ctx.fillRect(0, 500, W, 160);
        ctx.fillStyle = 'rgba(255,220,180,.18)';
        for (let i = 0; i < 24; i++) {
          const x = ((i * 211 + t * (0.25 + (i % 5) * 0.08)) % (W + 40)) - 20, y = ((i * 97 + Math.sin(t * 0.01 + i) * 40) % 460) + 40;
          ctx.fillRect(x, y, 2, 2);
        }
      },
    };
  }

  // запасной «цех», если фото нет
  function makeWorkshopCode() {
    const far = layerCanvas(0.1, (g, w, h) => {
      const sky = g.createLinearGradient(0, 0, 0, 520); sky.addColorStop(0, '#120a0b'); sky.addColorStop(1, '#3a1a14');
      g.fillStyle = sky; g.fillRect(0, 0, w, h);
      g.fillStyle = '#26130f';
      for (let x = 0; x < w; x += 140) { g.fillRect(x, 120, 130, 400); g.fillStyle = x % 280 ? '#2e1812' : '#241210'; }
      g.strokeStyle = '#0d0605'; g.lineWidth = 6; g.strokeRect(80, 150, 200, 120); g.strokeRect(w - 300, 150, 200, 120);
      glow(g, 180, 210, 120, 'rgba(255,140,60,A)', 0.35);
    });
    const floor = layerCanvas(1, (g, w, h) => {
      const fl = g.createLinearGradient(0, 520, 0, h); fl.addColorStop(0, '#2a1a14'); fl.addColorStop(1, '#0d0706');
      g.fillStyle = fl; g.fillRect(0, 520, w, h - 520);
    });
    return { id: 'workshop', name: 'ЗАБРОШЕННЫЙ ЦЕХ', shade: 'rgba(40,10,10,0.2)',
      draw(ctx, camX) { drawLayers(ctx, [far, floor], camX); }, over() {} };
  }

  const Arenas = {
    list: [],
    init(extra) {
      Arenas.list = [makeTemple()];
      const photos = (extra || []);
      if (photos.length) photos.forEach((p, i) => Arenas.list.push(makePhotoArena(p, i)));
      else Arenas.list.push(makeWorkshopCode());
      Arenas.list.push(makeCity());
    },
  };
  window.Arenas = Arenas;
})();

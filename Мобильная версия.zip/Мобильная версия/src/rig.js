// ============================================================================
//  rig.js — «кукольный риг»: собирает бойца из частей фото по позе (углам суставов).
//  Загружает картинки частей, считает позиции суставов, рисует бойца, отдаёт точки
//  (кисти, стопы, голова) для хитбоксов и эффектов.
// ============================================================================
(function () {
  const C = window.CFG;
  const DEG = Math.PI / 180;

  // ---- 2D-матрицы [a b c d e f] как у canvas ----
  const mul = (m, n) => [
    m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1],
    m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3],
    m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]];
  const T = (x, y) => [1, 0, 0, 1, x, y];
  const R = d => { const c = Math.cos(d * DEG), s = Math.sin(d * DEG); return [c, s, -s, c, 0, 0]; };
  const SC = (sx, sy) => [sx, 0, 0, sy, 0, 0];
  const ap = (m, x, y) => [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]];

  const Rig = { rigs: {}, imgs: {}, shaded: {}, shadeKey: null, portraits: {}, fronts: {}, frames: {}, ready: false };

  // Порядок рисования (сзади → вперёд): дальняя рука и нога сзади, ближние спереди
  const ORDER = ['uarmF', 'farmF', 'thighF', 'shinF', 'thighN', 'shinN', 'pelvis', 'torso', 'head', 'uarmN', 'farmN'];
  const IMGKEY = { uarmF: 'uarm_f', farmF: 'farm_f', thighF: 'thigh_f', shinF: 'shin_f',
    thighN: 'thigh', shinN: 'shin', pelvis: 'pelvis', torso: 'torso', head: 'head', uarmN: 'uarm', farmN: 'farm' };

  function loadImage(src) {
    return new Promise(res => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => res(null);
      im.src = encodeURI(src);
    });
  }

  const ang = (dx, dy) => Math.atan2(-dx, dy) / DEG;   // угол «по часовой от направления вниз»

  /** Загрузка ригов и картинок. chars – список из characters.json (может быть пустым для просмотрщика). */
  Rig.load = async function (chars) {
    const rigs = window.RIGS || {};
    const jobs = [];
    for (const name of Object.keys(rigs)) {
      const r = rigs[name];
      Rig.rigs[name] = r;
      Rig.imgs[name] = {};
      for (const [pk, p] of Object.entries(r.parts)) {
        jobs.push(loadImage(p.img).then(im => { Rig.imgs[name][pk] = im; }));
      }
      jobs.push(loadImage(r.portrait).then(im => { Rig.portraits[name] = im; }));
      jobs.push(loadImage(r.front).then(im => { Rig.fronts[name] = im; }));
      // поправки на «прямую» руку/ногу: 0 = рука/нога вытянута вдоль родителя
      const J = r.joints;
      r.bias = {
        aU: ang(J.elbow[0] - J.shoulder[0], J.elbow[1] - J.shoulder[1]),
        aF: ang(J.hand[0] - J.elbow[0], J.hand[1] - J.elbow[1]),
        aT: ang(J.knee[0] - J.hip[0], J.knee[1] - J.hip[1]),
        aS: ang(J.ankle[0] - J.knee[0], J.ankle[1] - J.knee[1]),
      };
      const sh = r.parts.shin;
      r.sole = { bottom: sh.oy + sh.h };
    }
    // готовые кадры анимаций (запасной вариант «Имя_punch_01.png»)
    for (const ch of chars || []) {
      if (!ch.frames) continue;
      Rig.frames[ch.name] = {};
      for (const [anim, list] of Object.entries(ch.frames)) {
        Rig.frames[ch.name][anim] = [];
        list.forEach((src, i) => jobs.push(loadImage(src).then(im => { if (im) Rig.frames[ch.name][anim][i] = im; })));
      }
    }
    await Promise.all(jobs);
    Rig.ready = true;
  };

  // Ключевые точки для привязки к полу и хурт-боксов: [часть, x, y, радиус] в координатах текстуры
  function keypoints(r) {
    const J = r.joints, P = r.parts;
    const headC = [P.head.ox + P.head.w * 0.55, P.head.oy + P.head.h * 0.45];
    return {
      headC, headTop: [P.head.ox + P.head.w * 0.5, P.head.oy],
      shoulder: J.shoulder, hip: J.hip,
      sole: [J.ankle[0] - 4, r.sole.bottom], toeTip: [J.toe[0], r.sole.bottom - 6], heel: [J.ankle[0] - 24, r.sole.bottom - 6],
    };
  }

  /**
   * Считает положение всех частей.
   * pose – набор углов; opt: {x, y (линия пола под бойцом), facing (1/-1), scale, lock}
   * Возвращает {mats, pts, rootY}.
   */
  Rig.solve = function (name, pose, opt) {
    const r = Rig.rigs[name];
    if (!r) return null;
    const J = r.joints, b = r.bias;
    const s = opt.scale || (C.fighterHeight / r.size[1]);
    const facing = opt.facing || 1;
    const hip = J.hip;
    const rel = (p, q) => [p[0] - q[0], p[1] - q[1]];
    const farA = r.far_arm_offset || [0, 0], farL = r.far_leg_offset || [0, 0];
    const sh = rel(J.shoulder, hip), neck = rel(J.neck, hip);
    const el = rel(J.elbow, J.shoulder), kn = rel(J.knee, hip);

    const chain = root => {
      const m = {};
      m.root = root;
      m.pelvis = mul(root, R(pose.pelv));
      m.torso = mul(root, R(pose.torso));
      m.head = mul(mul(m.torso, T(neck[0], neck[1])), R(pose.head));
      const uN = pose.uN - b.aU, fN = pose.fN + (b.aU - b.aF);
      const uF = pose.uF - b.aU, fF = pose.fF + (b.aU - b.aF);
      m.uarmN = mul(mul(m.torso, T(sh[0], sh[1])), R(uN));
      m.farmN = mul(mul(m.uarmN, T(el[0], el[1])), R(fN));
      m.uarmF = mul(mul(m.torso, T(sh[0] + farA[0], sh[1] + farA[1])), R(uF));
      m.farmF = mul(mul(m.uarmF, T(el[0], el[1])), R(fF));
      const tN = pose.tN - b.aT, sN = pose.sN + (b.aT - b.aS);
      const tF = pose.tF - b.aT, sF = pose.sF + (b.aT - b.aS);
      m.thighN = mul(m.pelvis, R(tN));
      m.shinN = mul(mul(m.thighN, T(kn[0], kn[1])), R(sN));
      m.thighF = mul(mul(m.pelvis, T(farL[0], farL[1])), R(tF));
      m.shinF = mul(mul(m.thighF, T(kn[0], kn[1])), R(sF));
      return m;
    };

    const kp = keypoints(r);
    const pointsOf = m => {
      const q = {};
      const loc = (mat, pivot, p) => ap(mat, p[0] - pivot[0], p[1] - pivot[1]);
      q.head = loc(m.head, J.neck, kp.headC);
      q.headTop = loc(m.head, J.neck, kp.headTop);
      q.neck = ap(m.torso, neck[0], neck[1]);
      q.shoulder = ap(m.torso, sh[0], sh[1]);
      q.hip = ap(m.root, 0, 0);
      q.elbowN = ap(m.uarmN, el[0], el[1]);
      q.elbowF = ap(m.uarmF, el[0], el[1]);
      const hd = rel(J.hand, J.elbow);
      q.handN = ap(m.farmN, hd[0], hd[1]);
      q.handF = ap(m.farmF, hd[0], hd[1]);
      for (const side of ['N', 'F']) {
        const sm = m['shin' + side];
        q['knee' + side] = ap(m['thigh' + side], kn[0], kn[1]);
        q['ankle' + side] = ap(sm, J.ankle[0] - J.knee[0], J.ankle[1] - J.knee[1]);
        q['sole' + side] = ap(sm, kp.sole[0] - J.knee[0], kp.sole[1] - J.knee[1]);
        q['toe' + side] = ap(sm, kp.toeTip[0] - J.knee[0], kp.toeTip[1] - J.knee[1]);
        q['heel' + side] = ap(sm, kp.heel[0] - J.knee[0], kp.heel[1] - J.knee[1]);
      }
      return q;
    };

    // 1) считаем в нулевом положении, чтобы найти самую низкую точку (привязка к полу)
    const base = mul(R(pose.rot), SC(s, s));
    const m0 = chain(base);
    const p0 = pointsOf(m0);
    const rad = { head: 34, hip: 38, shoulder: 40, kneeN: 22, kneeF: 22, elbowN: 14, elbowF: 14, headTop: 0 };
    let low = -1e9;
    for (const k of ['soleN', 'soleF', 'toeN', 'toeF', 'heelN', 'heelF']) low = Math.max(low, p0[k][1]);
    for (const k of Object.keys(rad)) low = Math.max(low, p0[k][1] + rad[k] * s);
    low = Math.max(low, p0.handN[1] + 8 * s, p0.handF[1] + 8 * s);
    const groundY = opt.y;
    const rootY = opt.lock === false ? groundY : groundY - low + (pose.y || 0);
    // 2) итоговая матрица корня
    const root = mul(mul(T(opt.x + facing * (pose.x || 0), rootY), SC(facing, 1)), base);
    const mats = chain(root);
    const pts = pointsOf(mats);
    return { mats, pts, rootY, scale: s, facing, name };
  };

  /** Рисует решённого бойца. opt: {flash 0..1, shade 'rgba(..)', alpha} */
  let off = null, offCtx = null;
  Rig.draw = function (ctx, sol, opt) {
    opt = opt || {};
    const r = Rig.rigs[sol.name], imgs = (Rig.shadeKey && Rig.shaded[sol.name]) || Rig.imgs[sol.name];
    if (!r) return;
    const needOff = opt.flash > 0;
    let g = ctx, ox = 0, oy = 0;
    const OW = 720, OH = 620, AX = 360, AY = 520;
    if (needOff) {
      if (!off) { off = document.createElement('canvas'); off.width = OW; off.height = OH; offCtx = off.getContext('2d'); }
      offCtx.setTransform(1, 0, 0, 1, 0, 0);
      offCtx.clearRect(0, 0, OW, OH);
      g = offCtx;
      ox = sol.mats.root[4] - AX; oy = sol.pts.soleN[1] > sol.pts.soleF[1] ? 0 : 0;
      oy = (opt.groundY || sol.pts.hip[1]) - AY;
    }
    for (const key of ORDER) {
      const pk = IMGKEY[key], p = r.parts[pk], im = imgs[pk];
      if (!im) continue;
      const m = sol.mats[key];
      g.save();
      g.transform(m[0], m[1], m[2], m[3], m[4] - ox, m[5] - oy);
      g.drawImage(im, p.ox - p.pivot[0], p.oy - p.pivot[1]);
      g.restore();
    }
    if (needOff) {
      offCtx.globalCompositeOperation = 'source-atop';
      if (opt.flash > 0) { offCtx.fillStyle = 'rgba(255,40,30,' + (0.62 * opt.flash).toFixed(3) + ')'; offCtx.fillRect(0, 0, OW, OH); }
      offCtx.globalCompositeOperation = 'source-over';
      ctx.save();
      if (opt.alpha !== undefined) ctx.globalAlpha = opt.alpha;
      ctx.drawImage(off, ox, oy);
      ctx.restore();
    }
  };

  /** Рисует готовый кадр (запасной вариант без рига): стопами на землю по центру. */
  Rig.drawFrame = function (ctx, img, x, groundY, facing, height) {
    const k = height / img.height;
    ctx.save();
    ctx.translate(x, groundY);
    ctx.scale(facing * k, k);
    ctx.drawImage(img, -img.width / 2, -img.height);
    ctx.restore();
  };

  /** Запекает тонировку арены в картинки частей (один раз при старте боя – дешевле, чем тонировать каждый кадр). */
  Rig.setShade = function (shade) {
    if (Rig.shadeKey === shade) return;
    Rig.shadeKey = shade || null; Rig.shaded = {};
    if (!shade) return;
    for (const name of Object.keys(Rig.imgs)) {
      Rig.shaded[name] = {};
      for (const [pk, im] of Object.entries(Rig.imgs[name])) {
        if (!im) continue;
        const c = document.createElement('canvas'); c.width = im.width; c.height = im.height;
        const g = c.getContext('2d'); g.drawImage(im, 0, 0);
        g.globalCompositeOperation = 'source-atop'; g.fillStyle = shade; g.fillRect(0, 0, c.width, c.height);
        Rig.shaded[name][pk] = c;
      }
    }
  };

  Rig.names = () => Object.keys(Rig.rigs);
  window.Rig = Rig;
})();

// ============================================================================
//  audio.js — звук: синтез через Web Audio (звуки ударов, музыка), голос диктора,
//  голоса бойцов из папки «Персонажи». Любой звук можно заменить файлом:
//    assets/sfx/<имя>.mp3|ogg|wav   – звуки (punch, heavy, kick, block, whoosh, fall, special, ko, …)
//    assets/sfx/announce_<ключ>.mp3 – реплики диктора (round1, round2, round3, fight, finish, flawless, victory)
//    assets/music/menu.mp3, assets/music/fight.mp3 – музыка (зациклится)
//  Нет файла – играет синтезированный вариант. Нет озвучки у бойца – звук просто пропускается.
// ============================================================================
(function () {
  const C = window.CFG;
  const Audio_ = {
    ctx: null, master: null, sfxGain: null, musicGain: null,
    files: {}, music: null, musicTimer: null, musicFile: null, muted: false,
    voiceEls: {},
  };
  const SFX_NAMES = ['punch', 'heavy', 'kick', 'block', 'whoosh', 'fall', 'special', 'ko', 'ui_move', 'ui_ok', 'gong', 'flash', 'throw',
    'announce_round1', 'announce_round2', 'announce_round3', 'announce_fight', 'announce_finish', 'announce_flawless', 'announce_victory'];

  /** Запускается по первому нажатию (требование браузеров). */
  Audio_.unlock = function () {
    if (!Audio_.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      Audio_.ctx = new AC();
      Audio_.master = Audio_.ctx.createGain(); Audio_.master.gain.value = C.masterVolume;
      Audio_.master.connect(Audio_.ctx.destination);
      Audio_.sfxGain = Audio_.ctx.createGain(); Audio_.sfxGain.gain.value = C.sfxVolume; Audio_.sfxGain.connect(Audio_.master);
      Audio_.musicGain = Audio_.ctx.createGain(); Audio_.musicGain.gain.value = Math.min(C.musicMax || 0.2, C.musicVolume); Audio_.musicGain.connect(Audio_.master);
      const n = Audio_.ctx.sampleRate * 1.2;
      const b = Audio_.ctx.createBuffer(1, n, Audio_.ctx.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
      Audio_.noise = b;
    }
    if (Audio_.ctx.state === 'suspended') Audio_.ctx.resume();
  };

  /** Ищем необязательные файлы-замены (на file:// ошибка загрузки просто означает «файла нет»). */
  Audio_.probe = function () {
    for (const n of SFX_NAMES) {
      for (const ext of ['mp3', 'ogg', 'wav']) {
        if (Audio_.files[n]) break;
        const a = new Audio();
        a.preload = 'auto';
        a.addEventListener('canplaythrough', () => { if (!Audio_.files[n]) Audio_.files[n] = a.src; }, { once: true });
        a.addEventListener('error', () => {}, { once: true });
        a.src = 'assets/sfx/' + n + '.' + ext;
      }
    }
  };

  const T = () => Audio_.ctx.currentTime;
  function tone(type, f0, f1, dur, vol, delay, dest) {
    const c = Audio_.ctx, t = T() + (delay || 0);
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.01, dur / 4));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(dest || Audio_.sfxGain);
    o.start(t); o.stop(t + dur + 0.05);
  }
  function noise(dur, vol, type, f0, f1, delay, dest) {
    const c = Audio_.ctx, t = T() + (delay || 0);
    const s = c.createBufferSource(); s.buffer = Audio_.noise;
    const f = c.createBiquadFilter(); f.type = type || 'lowpass';
    f.frequency.setValueAtTime(f0, t); if (f1) f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(dest || Audio_.sfxGain);
    s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05);
  }

  const SYN = {
    punch() { noise(0.12, 0.8, 'lowpass', 2600, 400); tone('sine', 170, 60, 0.12, 0.9); },
    heavy() { noise(0.22, 1.0, 'lowpass', 2200, 200); tone('sine', 130, 38, 0.28, 1.1); tone('square', 90, 40, 0.1, 0.25); },
    kick() { noise(0.15, 0.9, 'bandpass', 1800, 300); tone('sine', 150, 50, 0.16, 1.0); },
    block() { tone('square', 620, 520, 0.09, 0.25); tone('square', 940, 700, 0.07, 0.18, 0.01); noise(0.08, 0.5, 'highpass', 3000, 3000); },
    whoosh() { noise(0.18, 0.35, 'bandpass', 500, 2200); },
    fall() { tone('sine', 80, 28, 0.5, 1.1); noise(0.3, 0.7, 'lowpass', 900, 120); },
    throw() { noise(0.25, 0.5, 'bandpass', 300, 1500); tone('sine', 120, 50, 0.2, 0.8, 0.15); },
    special() { tone('sawtooth', 160, 1400, 0.45, 0.25); noise(0.45, 0.4, 'bandpass', 400, 3000); tone('sine', 70, 40, 0.5, 0.7, 0.05); },
    grind() { noise(0.35, 0.8, 'highpass', 2500, 6000); tone('sawtooth', 900, 1400, 0.3, 0.25); tone('square', 120, 160, 0.3, 0.2); },
    spit() { noise(0.18, 0.5, 'bandpass', 1500, 600); tone('sine', 300, 140, 0.15, 0.4); },
    glass() { noise(0.3, 0.7, 'highpass', 4000, 7000); tone('triangle', 2400, 1200, 0.18, 0.3); tone('triangle', 3100, 1800, 0.12, 0.2, 0.03); },
    ko() { tone('sine', 110, 30, 1.0, 1.3); noise(0.8, 0.9, 'lowpass', 2500, 80); tone('sawtooth', 300, 40, 0.9, 0.3); },
    ui_move() { tone('square', 520, 520, 0.05, 0.12); },
    ui_ok() { tone('square', 520, 520, 0.07, 0.15); tone('square', 780, 780, 0.09, 0.15, 0.06); },
    flash() { tone('triangle', 1400, 700, 0.25, 0.3); noise(0.25, 0.5, 'highpass', 3000, 6000); },
    gong() { [110, 164.8, 220, 331].forEach((f, i) => tone('sine', f, f * 0.99, 1.8, 0.35 / (i + 1))); noise(0.3, 0.3, 'bandpass', 800, 200); },
    finish() { tone('sawtooth', 55, 41, 1.8, 0.45); tone('sawtooth', 58, 43, 1.8, 0.35); noise(0.5, 0.35, 'lowpass', 600, 80); },
  };

  /** Проиграть звук: файл-замена или синтез. */
  Audio_.sfx = function (name, vol) {
    if (!Audio_.ctx || Audio_.muted) return;
    const url = Audio_.files[name];
    if (url) {
      const a = new Audio(url); a.volume = Math.min(1, (vol || 1) * C.sfxVolume * C.masterVolume);
      a.play().catch(() => {}); return;
    }
    const fn = SYN[name];
    if (fn) { try { fn(); } catch (e) { /* звук не критичен */ } }
  };

  // ---------------- диктор ----------------
  const SAY = { round1: 'Round one', round2: 'Round two', round3: 'Final round', fight: 'Fight!', finish: 'Finish him!',
    flawless: 'Flawless victory', victory: 'Victory', ko: 'K O' };
  Audio_.say = function (key) {
    if (Audio_.muted) return;
    const url = Audio_.files['announce_' + key];
    if (url) { const a = new Audio(url); a.volume = C.masterVolume; a.play().catch(() => {}); return; }
    try {
      if (!('speechSynthesis' in window)) return;
      const u = new SpeechSynthesisUtterance(SAY[key] || key);
      const vs = speechSynthesis.getVoices();
      const v = vs.find(x => /^en/i.test(x.lang) && /male|david|mark|daniel|alex/i.test(x.name)) || vs.find(x => /^en/i.test(x.lang));
      if (v) u.voice = v;
      u.lang = 'en-US'; u.pitch = 0.1; u.rate = key === 'fight' ? 0.85 : 0.7; u.volume = 1;
      speechSynthesis.cancel(); speechSynthesis.speak(u);
    } catch (e) { /* нет синтеза речи – остаётся текст на экране */ }
  };

  // ---------------- голоса бойцов ----------------
  const lastVoiceFrame = {};
  /**
   * ch – запись персонажа из characters.json, event – select/fight/hit/win/ko/special.
   * Подходят файлы события, иначе общий пул «generic». Нет голосов – молча пропускаем.
   */
  Audio_.voice = function (ch, event, force) {
    if (!ch || Audio_.muted) return;
    const v = ch.voices || {};
    let pool = (v[event] && v[event].length) ? v[event] : (v.generic || []);
    if (!pool.length) return;
    const src = pool[Math.floor(Math.random() * pool.length)];
    const prev = Audio_.voiceEls[ch.name];
    if (prev) { try { prev.pause(); } catch (e) {} }
    try {
      const a = new Audio(encodeURI(src));
      a.volume = Math.min(1, C.voiceVolume * C.masterVolume);
      a.play().catch(() => {});
      Audio_.voiceEls[ch.name] = a;
    } catch (e) { /* пропускаем */ }
  };
  /** Проиграть файл (звук события, например лай). Возвращает элемент Audio. */
  Audio_.play = function (url, vol) {
    if (Audio_.muted) return null;
    try { const a = new Audio(url); a.volume = Math.min(1, (vol || 1) * C.voiceVolume * C.masterVolume); a.play().catch(() => {}); Audio_.extra = a; return a; }
    catch (e) { return null; }
  };
  Audio_.stopVoices = function () {
    for (const k of Object.keys(Audio_.voiceEls)) { try { Audio_.voiceEls[k].pause(); } catch (e) {} }
  };

  // ---------------- музыка ----------------
  const BASS_F = [55, 0, 55, 0, 65.4, 0, 55, 0, 82.4, 0, 73.4, 0, 65.4, 0, 49, 0];
  const BASS_M = [55, 0, 0, 0, 0, 0, 0, 0, 58.3, 0, 0, 0, 0, 0, 0, 0];
  const ARP = [220, 261.6, 329.6, 261.6, 220, 261.6, 392, 329.6, 220, 293.7, 349.2, 293.7, 233, 277, 329.6, 277];
  function musicStep(mode, step, t0) {
    const c = Audio_.ctx;
    const dest = Audio_.musicGain;
    const b = (mode === 'fight' ? BASS_F : BASS_M)[step % 16];
    const at = (type, f, dur, vol, delay) => {
      const o = c.createOscillator(), g = c.createGain();
      o.type = type; o.frequency.value = f; const t = t0 + (delay || 0);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + 0.05);
    };
    const nz = (dur, vol, ft, f0) => {
      const s = c.createBufferSource(); s.buffer = Audio_.noise;
      const f = c.createBiquadFilter(); f.type = ft; f.frequency.value = f0;
      const g = c.createGain(); g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      s.connect(f); f.connect(g); g.connect(dest); s.start(t0, Math.random() * 0.5); s.stop(t0 + dur + 0.05);
    };
    if (mode === 'fight') {
      if (b) { at('sawtooth', b, 0.22, 0.30); at('square', b * 2, 0.12, 0.08); }
      if (step % 4 === 0 || step % 16 === 10) at('sine', 120, 0.16, 0.9);          // «бочка»
      if (step % 8 === 4) nz(0.14, 0.5, 'bandpass', 1800);                          // «малый»
      if (step % 2 === 0) nz(0.04, 0.12, 'highpass', 7000);                         // хэт
      if (Math.floor(step / 16) % 2 === 1 && step % 2 === 0) at('square', ARP[step % 16], 0.10, 0.045);
    } else {
      if (b) at('sine', b, 1.8, 0.5);
      if (step % 8 === 0) { at('sine', 70, 0.5, 0.9); nz(0.25, 0.25, 'lowpass', 400); }
      if (step % 16 === 0) { at('triangle', 220, 3.2, 0.06); at('triangle', 261.6, 3.2, 0.05); at('triangle', 329.6, 3.2, 0.04); }
      if (step % 16 === 8) at('triangle', 207.6, 2.5, 0.05);
    }
  }
  Audio_.playMusic = function (mode) {
    if (!Audio_.ctx) return;
    if (Audio_.musicMode === mode) return;
    Audio_.stopMusic();
    Audio_.musicMode = mode;
    // файл-замена
    // для боя берём трек из папки «Музыка» (если их несколько – случайный), иначе assets/music/<режим>.mp3
    const gd = window.GAME_DATA || {}, tracks = (mode === 'fight' && gd.music) ? gd.music : [];
    const url = tracks.length ? encodeURI(tracks[Math.floor(Math.random() * tracks.length)]) : 'assets/music/' + mode + '.mp3';
    const a = new Audio(); a.loop = true;
    a.volume = Math.min(C.musicMax || 0.2, C.musicVolume * C.masterVolume);      // музыка не громче 20% и тише голосов
    let useFile = false;
    a.addEventListener('canplaythrough', () => { if (Audio_.musicMode === mode && !useFile) { useFile = true; Audio_.stopSynth(); a.play().catch(() => {}); Audio_.musicFile = a; } }, { once: true });
    a.src = url;
    // синтезированная музыка
    const bpm = mode === 'fight' ? 128 : 76, stepDur = 60 / bpm / 4;
    let step = 0, next = T() + 0.1;
    Audio_.musicTimer = setInterval(() => {
      if (!Audio_.ctx || Audio_.muted) { next = T() + 0.1; return; }
      while (next < T() + 0.25) { musicStep(mode, step++, next); next += stepDur; }
    }, 40);
  };
  Audio_.stopSynth = function () { if (Audio_.musicTimer) { clearInterval(Audio_.musicTimer); Audio_.musicTimer = null; } };
  Audio_.stopMusic = function () {
    Audio_.stopSynth();
    if (Audio_.musicFile) { try { Audio_.musicFile.pause(); } catch (e) {} Audio_.musicFile = null; }
    Audio_.musicMode = null;
  };
  Audio_.toggleMute = function () {
    Audio_.muted = !Audio_.muted;
    if (Audio_.master) Audio_.master.gain.value = Audio_.muted ? 0 : C.masterVolume;
    if (Audio_.musicFile) Audio_.musicFile.muted = Audio_.muted;
    if (Audio_.muted) { Audio_.stopVoices(); try { speechSynthesis.cancel(); } catch (e) {} }
  };
  window.GameAudio = Audio_;
})();

// ============================================================================
//  ui.js — экраны: заставка, меню, сложность, выбор бойца, выбор арены, управление.
// ============================================================================
(function () {
  const C = window.CFG;
  const W = C.W, H = C.H;
  const FONT = '"Impact","Arial Black","Segoe UI Black",sans-serif';
  const T = (ctx, s, x, y, size, fill, align, stroke) => Match.outlineText(ctx, s, x, y, size, fill, stroke || '#12040a', align);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  // --- общий фон меню: тёмная арена с медленным параллаксом и искрами ---
  const embers = [];
  for (let i = 0; i < 60; i++) embers.push({ x: Math.random() * W, y: Math.random() * H, v: 0.3 + Math.random() * 1.2, s: 1 + Math.random() * 2.5, p: Math.random() * 6 });
  let bgT = 0;
  function drawBackground(ctx, dim) {
    bgT++;
    const arena = Arenas.list[0];
    const cam = (SW_PAN() / 2) + Math.sin(bgT * 0.004) * SW_PAN() / 2;
    arena.draw(ctx, cam);
    arena.over(ctx, cam, bgT);
    ctx.fillStyle = 'rgba(8,0,4,' + (dim === undefined ? 0.55 : dim) + ')'; ctx.fillRect(0, 0, W, H);
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (const e of embers) {
      e.y -= e.v; e.x += Math.sin(bgT * 0.02 + e.p) * 0.4; if (e.y < -5) { e.y = H + 5; e.x = Math.random() * W; }
      ctx.fillStyle = 'rgba(255,' + (110 + (e.s * 30) | 0) + ',40,' + (0.35 + 0.3 * Math.sin(bgT * 0.1 + e.p)).toFixed(2) + ')';
      ctx.beginPath(); ctx.arc(e.x, e.y, e.s, 0, 7); ctx.fill();
    }
    ctx.restore();
    Match.vignette(ctx, 0.35, 1, 0.7);
  }
  function SW_PAN() { return C.stageWidth - W; }

  function titleText(ctx, s, x, y, size) {
    ctx.save(); ctx.font = '900 ' + size + 'px ' + FONT; ctx.textAlign = 'center'; ctx.lineJoin = 'round';
    ctx.shadowColor = 'rgba(255,40,20,.8)'; ctx.shadowBlur = 40;
    ctx.lineWidth = size / 5; ctx.strokeStyle = '#12040a'; ctx.strokeText(s, x, y);
    ctx.shadowBlur = 0;
    const g = ctx.createLinearGradient(0, y - size * 0.85, 0, y + size * 0.1);
    g.addColorStop(0, '#fff6c4'); g.addColorStop(0.45, '#e9b43a'); g.addColorStop(0.55, '#c07a16'); g.addColorStop(1, '#7a3a0c');
    ctx.fillStyle = g; ctx.fillText(s, x, y);
    ctx.lineWidth = 2.5; ctx.strokeStyle = '#7d0f16'; ctx.strokeText(s, x, y);
    ctx.restore();
  }

  const scenes = {};

  // ============================== ЗАСТАВКА ==================================
  scenes.title = {
    enter() { this.t = 0; GameAudio.playMusic('menu'); },
    update(app) {
      this.t++;
      for (const e of Input.menuEvents()) { if (e.a === 'any' || e.a === 'ok') { GameAudio.unlock(); GameAudio.playMusic('menu'); GameAudio.sfx('ui_ok'); app.go('menu'); } }
    },
    draw(ctx, app) {
      drawBackground(ctx, 0.35);
      // бойцы силуэтами по краям
      const names = Rig.names();
      names.forEach((n, i) => {
        const im = Rig.fronts[n]; if (!im) return;
        const left = i % 2 === 0, k = 560 / im.height;
        const x = left ? 40 + Math.floor(i / 2) * 150 : W - 40 - Math.floor(i / 2) * 150 - im.width * k;
        ctx.save(); ctx.globalAlpha = 0.5;
        ctx.drawImage(im, x, H - 560 + 30, im.width * k, 560);
        ctx.restore();
      });
      const g = ctx.createLinearGradient(0, H * 0.4, 0, H); g.addColorStop(0, 'rgba(8,0,4,0)'); g.addColorStop(1, 'rgba(8,0,4,.85)'); ctx.fillStyle = g; ctx.fillRect(0, H * 0.4, W, H * 0.6);
      const bob = Math.sin(this.t * 0.04) * 4;
      titleText(ctx, 'ЖЕЛЕЗНЫЙ', W / 2, 220 + bob, 150);
      titleText(ctx, 'КУЛАК', W / 2, 360 + bob, 150);
      T(ctx, 'ТУРНИР В ЦЕХУ', W / 2, 420, 40, '#e9dcc8');
      ctx.strokeStyle = '#d9a93a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(W / 2 - 260, 440); ctx.lineTo(W / 2 + 260, 440); ctx.stroke();
      if (Math.floor(this.t / 30) % 2 === 0) T(ctx, 'КОСНИТЕСЬ ЭКРАНА', W / 2, 600, 40, '#ffd15c');
      ctx.font = '500 16px "Segoe UI",Arial,sans-serif'; ctx.fillStyle = '#8d7a6e'; ctx.textAlign = 'center';
      ctx.fillText('Лучше играть в горизонтальном положении', W / 2, H - 20);
    },
  };

  // ============================== ГЛАВНОЕ МЕНЮ ===============================
  function menuList(ctx, items, sel, y0, step, size) {
    items.forEach((it, i) => {
      const s = i === sel;
      T(ctx, (s ? '▶ ' : '') + it + (s ? ' ◀' : ''), W / 2, y0 + i * step, size || 46, s ? '#ff5a3a' : '#e9dcc8');
    });
  }
  scenes.menu = {
    enter() { this.sel = 0; },
    items() { return ['ИГРАТЬ ПРОТИВ КОМПЬЮТЕРА', 'ЗВУК: ' + (GameAudio.muted ? 'ВЫКЛ' : 'ВКЛ')]; },
    update(app) {
      for (const e of Input.menuEvents()) {
        const n = this.items().length;
        if (e.a === 'up') { this.sel = (this.sel + n - 1) % n; GameAudio.sfx('ui_move'); }
        else if (e.a === 'down') { this.sel = (this.sel + 1) % n; GameAudio.sfx('ui_move'); }
        else if (e.a === 'mute') GameAudio.toggleMute();
        else if (e.a === 'ok') {
          GameAudio.sfx('ui_ok');
          if (this.sel === 0) app.go('diff');
          else if (this.sel === 1) GameAudio.toggleMute();
        } else if (e.a === 'back') app.go('title');
      }
    },
    draw(ctx) {
      drawBackground(ctx);
      titleText(ctx, 'ЖЕЛЕЗНЫЙ КУЛАК', W / 2, 150, 96);
      menuList(ctx, this.items(), this.sel, 300, 78, 46);
      ctx.font = '500 17px "Segoe UI",Arial,sans-serif'; ctx.fillStyle = '#a99886'; ctx.textAlign = 'center';
      
    },
  };

  // ============================== СЛОЖНОСТЬ ==================================
  scenes.diff = {
    enter() { this.sel = 1; },
    update(app) {
      const keys = ['easy', 'normal', 'hard'];
      for (const e of Input.menuEvents()) {
        if (e.a === 'up') { this.sel = (this.sel + 2) % 3; GameAudio.sfx('ui_move'); }
        else if (e.a === 'down') { this.sel = (this.sel + 1) % 3; GameAudio.sfx('ui_move'); }
        else if (e.a === 'ok') { GameAudio.sfx('ui_ok'); app.cfg.mode = 'cpu'; app.cfg.level = keys[this.sel]; app.go('select'); }
        else if (e.a === 'back') app.go('menu');
      }
    },
    draw(ctx) {
      drawBackground(ctx);
      T(ctx, 'СЛОЖНОСТЬ ПРОТИВНИКА', W / 2, 160, 70, '#ffd15c');
      menuList(ctx, ['ЛЁГКИЙ', 'СРЕДНИЙ', 'ТЯЖЁЛЫЙ'], this.sel, 320, 90, 60);
    },
  };

  // ============================== ВЫБОР БОЙЦА ================================
  scenes.select = {
    enter(app) {
      const n = app.chars.length;
      this.cur = [0, Math.min(1, n - 1)]; this.locked = [false, false]; this.stage = 0; this.t = 0; this.done = 0;
      this.cols = Math.min(4, n); this.rows = Math.ceil(n / this.cols);
      this.mode = app.cfg.mode;
      GameAudio.playMusic('menu'); Input.clear();
    },
    move(i, a, n) {
      let c = this.cur[i];
      const cols = this.cols;
      if (a === 'left') c = (c % cols === 0) ? Math.min(n - 1, c + cols - 1) : c - 1;
      if (a === 'right') c = (c % cols === cols - 1 || c === n - 1) ? c - (c % cols) : c + 1;
      if (a === 'up') c = c - cols >= 0 ? c - cols : c;
      if (a === 'down') c = c + cols < n ? c + cols : c;
      if (c !== this.cur[i]) { this.cur[i] = c; GameAudio.sfx('ui_move'); }
    },
    update(app) {
      this.t++;
      const n = app.chars.length;
      if (this.done) { this.done--; if (this.done === 0) app.go('arena'); return; }
      for (const e of Input.menuEvents()) {
        if (this.mode === '2p') {
          // у каждого игрока своя рамка
          if (e.a === 'back') { if (this.locked[0] || this.locked[1]) { this.locked = [false, false]; } else app.go('menu'); continue; }
          let who = e.src === 0 || e.src === 1 ? e.src : -1;
          if (['left', 'right', 'up', 'down'].includes(e.a) && who >= 0 && !this.locked[who]) this.move(who, e.a, n);
          if (e.a === 'ok') {
            if (who < 0) who = this.locked[0] ? 1 : 0;
            if (!this.locked[who]) { this.locked[who] = true; GameAudio.sfx('ui_ok'); GameAudio.voice(app.chars[this.cur[who]], 'select'); }
          }
        } else {
          // против ИИ: сначала выбираем себя, потом противника; управление – с любой раскладки
          const i = this.stage;
          if (e.a === 'back') { if (this.stage === 1) { this.stage = 0; this.locked[0] = false; } else app.go('diff'); continue; }
          if (['left', 'right', 'up', 'down'].includes(e.a)) this.move(i, e.a, n);
          if (e.a === 'ok') {
            this.locked[i] = true; GameAudio.sfx('ui_ok'); GameAudio.voice(app.chars[this.cur[i]], 'select');
            if (this.stage === 0) { this.stage = 1; }
          }
        }
        if (this.locked[0] && this.locked[1]) { this.done = 70; }
      }
      if (this.done && this.locked[0] && this.locked[1]) { app.cfg.picks = [this.cur[0], this.cur[1]]; }
    },
    draw(ctx, app) {
      drawBackground(ctx, 0.62);
      const n = app.chars.length, cw = 190, chh = 215, gap = 22, cols = this.cols;
      T(ctx, 'ВЫБЕРИ БОЙЦА', W / 2, 78, 58, '#ffd15c');
      const sub = (this.stage === 0 ? 'ТВОЙ БОЕЦ' : 'ВЫБЕРИ ПРОТИВНИКА');
      T(ctx, sub, W / 2, 114, 22, '#e9dcc8');
      const totalW = cols * cw + (cols - 1) * gap, x0 = (W - totalW) / 2, y0 = 150;
      for (let i = 0; i < n; i++) {
        const c = i % cols, r = Math.floor(i / cols), x = x0 + c * (cw + gap), y = y0 + r * (chh + gap);
        const ch = app.chars[i];
        ctx.fillStyle = 'rgba(20,6,10,.9)'; ctx.fillRect(x, y, cw, chh);
        const im = Rig.portraits[ch.name];
        if (im) {
          const k = Math.max((cw - 8) / im.width, (chh - 50) / im.height);
          ctx.save(); ctx.beginPath(); ctx.rect(x + 4, y + 4, cw - 8, chh - 50); ctx.clip();
          ctx.drawImage(im, x + 4 + (cw - 8 - im.width * k) / 2, y + 4, im.width * k, im.height * k);
          ctx.restore();
        }
        const g = ctx.createLinearGradient(0, y + chh - 80, 0, y + chh); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.7)');
        ctx.fillStyle = g; ctx.fillRect(x, y + chh - 80, cw, 80);
        ctx.fillStyle = 'rgba(10,3,6,.9)'; ctx.fillRect(x, y + chh - 46, cw, 46);
        T(ctx, ch.name.toUpperCase(), x + cw / 2, y + chh - 14, 32, '#f3e6d0');
        ctx.strokeStyle = '#4a2a30'; ctx.lineWidth = 2; ctx.strokeRect(x, y, cw, chh);
        // рамки выбора игроков
        for (let p = 0; p < 2; p++) {
          if (this.cur[p] !== i) continue;
          if (this.mode === 'cpu' && p === 1 && this.stage === 0) continue;
          const col = p === 0 ? '#ff3a2a' : '#4aa8ff';
          const pulse = this.locked[p] ? 1 : 0.6 + 0.4 * Math.sin(this.t * 0.2);
          ctx.strokeStyle = col; ctx.globalAlpha = pulse; ctx.lineWidth = 6;
          const off = p * 7; ctx.strokeRect(x - 4 + off, y - 4 + off, cw + 8 - off * 2, chh + 8 - off * 2); ctx.globalAlpha = 1;
          T(ctx, this.mode === 'cpu' ? (p === 0 ? 'ТЫ' : 'ИИ') : 'P' + (p + 1), x + 24 + p * (cw - 48), y + 28, 26, col);
          if (this.locked[p]) T(ctx, 'ГОТОВ', x + cw / 2, y + 100, 34, col);
        }
      }
      // большие превью выбранных бойцов по бокам
      for (let p = 0; p < 2; p++) {
        if (this.mode === 'cpu' && p === 1 && this.stage === 0 && !this.locked[1]) continue;
        const ch = app.chars[this.cur[p]], im = Rig.fronts[ch.name];
        if (!im) continue;
        const k = 440 / im.height, w = im.width * k;
        const x = p === 0 ? 24 : W - w - 24;
        ctx.save(); ctx.globalAlpha = 0.9;
        if (p === 1) { ctx.translate(x + w, 0); ctx.scale(-1, 1); ctx.drawImage(im, 0, H - 440 - 12, w, 440); }
        else ctx.drawImage(im, x, H - 440 - 12, w, 440);
        ctx.restore();
        const sp = C.specials[C.specialByName[ch.name] || C.specialOrder[(ch.name.length) % 4]];
        T(ctx, 'СПЕЦ: ' + (sp ? sp.name : ''), p === 0 ? 24 + w / 2 : W - 24 - w / 2, H - 14, 20, '#ffd15c');
      }
    },
  };

  // ============================== ВЫБОР АРЕНЫ ================================
  scenes.arena = {
    enter(app) {
      this.sel = Math.floor(Math.random() * Arenas.list.length); this.t = 0; this.thumbs = null;
      Input.clear();
    },
    makeThumbs() {
      this.thumbs = Arenas.list.map(a => {
        const c = document.createElement('canvas'); c.width = 400; c.height = 225;
        const g = c.getContext('2d'); g.scale(400 / W, 225 / H);
        a.draw(g, (C.stageWidth - W) / 2);
        const vg = g.createLinearGradient(0, 0, 0, H); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.35)'); g.fillStyle = vg; g.fillRect(0, 0, W, H);
        return c;
      });
    },
    update(app) {
      this.t++;
      const n = Arenas.list.length;
      if (!this.thumbs && this.t > 2) this.makeThumbs();
      for (const e of Input.menuEvents()) {
        if (e.a === 'left' || e.a === 'up') { this.sel = (this.sel + n - 1) % n; GameAudio.sfx('ui_move'); }
        else if (e.a === 'right' || e.a === 'down') { this.sel = (this.sel + 1) % n; GameAudio.sfx('ui_move'); }
        else if (e.a === 'ok') { GameAudio.sfx('ui_ok'); app.cfg.arena = this.sel; app.startMatch(); }
        else if (e.a === 'back') app.go('select');
      }
    },
    draw(ctx) {
      drawBackground(ctx, 0.65);
      T(ctx, 'ВЫБЕРИ АРЕНУ', W / 2, 100, 62, '#ffd15c');
      const n = Arenas.list.length, cw = 360, ch = 202, gap = 36, x0 = (W - (n * cw + (n - 1) * gap)) / 2, y = 190;
      Arenas.list.forEach((a, i) => {
        const x = x0 + i * (cw + gap), s = i === this.sel;
        ctx.save();
        if (s) { ctx.shadowColor = 'rgba(255,60,40,.9)'; ctx.shadowBlur = 28; }
        ctx.fillStyle = '#12040a'; ctx.fillRect(x - 6, y - 6, cw + 12, ch + 12);
        ctx.restore();
        if (this.thumbs) ctx.drawImage(this.thumbs[i], x, y, cw, ch);
        ctx.strokeStyle = s ? '#ff3a2a' : '#4a2a30'; ctx.lineWidth = s ? 6 : 3; ctx.strokeRect(x - 3, y - 3, cw + 6, ch + 6);
        T(ctx, a.name, x + cw / 2, y + ch + 52, 34, s ? '#ffd15c' : '#c9bba8');
      });
      ctx.font = '500 17px "Segoe UI",Arial,sans-serif'; ctx.fillStyle = '#a99886'; ctx.textAlign = 'center';
      ctx.fillText('Коснитесь арены, чтобы начать бой', W / 2, H - 26);
    },
  };

  // ============================== УПРАВЛЕНИЕ =================================
  scenes.controls = {
    enter() { Input.clear(); },
    update(app) { for (const e of Input.menuEvents()) if (e.a === 'back' || e.a === 'ok') { GameAudio.sfx('ui_ok'); app.go('menu'); } },
    draw(ctx) {
      drawBackground(ctx, 0.78);
      T(ctx, 'УПРАВЛЕНИЕ', W / 2, 90, 64, '#ffd15c');
      Match.drawControls(ctx, 150);
      ctx.font = '500 17px "Segoe UI",Arial,sans-serif'; ctx.fillStyle = '#a99886'; ctx.textAlign = 'center';
      ctx.fillText('Раскладку меняют в config.js → controls (коды клавиш не зависят от языка).  Esc – назад', W / 2, H - 22);
    },
  };

  // ============================== БОЙ (обёртка) ==============================
  scenes.match = {
    enter(app) { this.m = new Match(app.matchOpts); this.t = 0; },
    update(app) {
      const r = this.m.update();
      if (r === 'rematch') app.startMatch();
      else if (r === 'quit') { GameAudio.stopVoices(); GameAudio.playMusic('menu'); app.go('menu'); }
    },
    draw(ctx) { this.m.draw(ctx); },
  };

  window.Scenes = scenes;
  window.UI = { drawBackground, titleText };
})();

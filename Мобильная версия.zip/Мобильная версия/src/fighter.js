// ============================================================================
//  fighter.js — боец: состояния, движение, удары (startup/active/recovery), блок, бросок,
//  спецудар, получение урона. Анимация берётся из animations.js, поза считается в rig.js.
//  Хитбокс удара – реальная позиция кисти/стопы в текущем кадре; хёртбокс – по ключевым точкам тела.
// ============================================================================
(function () {
  const C = window.CFG;
  const sign = v => (v > 0 ? 1 : v < 0 ? -1 : 0);

  // состояния, в которых боец управляется игроком
  const ACTIONABLE = ['idle', 'walk', 'walkB', 'crouch', 'block', 'cblock'];

  // соответствие состояния «готовым кадрам» (запасной вариант без рига)
  const FRAME_KEY = { idle: 'idle', walk: 'walk', walkB: 'walk', jump: 'jump', crouch: 'crouch', block: 'block', cblock: 'block',
    light: 'punch', jpunch: 'punch', heavy: 'heavy', kick: 'kick', sweep: 'kick', jkick: 'kick', hit: 'hit', hit_h: 'hit', hit_c: 'hit',
    knockdown: 'ko', ko: 'ko', getup: 'idle', intro: 'intro', win: 'win', throw: 'throw', stun: 'hit',
    special_proj: 'special', special_dash: 'special', special_wave: 'special', special_rise: 'special',
    special_spit: 'special', special_bottles: 'special', special_grind: 'special', trip: 'ko' };

  function hashName(s) { let h = 0; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) | 0; return Math.abs(h); }

  class Fighter {
    constructor(idx, ch) {
      this.idx = idx; this.ch = ch; this.name = ch.name;
      this.trait = C.traits[ch.name] || {};
      this.specialType = C.specialByName[ch.name] || C.specialOrder[hashName(ch.name) % C.specialOrder.length];
      this.reset(0, 1);
    }

    reset(x, facing) {
      this.x = x; this.h = 0; this.vx = 0; this.vy = 0; this.kb = 0;
      this.facing = facing; this.hp = C.maxHealth; this.meter = 0; this.combo = 0; this.comboDmg = 0;
      this.damageTaken = 0;
      this.state = 'idle'; this.st = 0; this.move = null; this.moveKey = null; this.hitDone = false;
      this.anim = 'idle'; this.animT = 0; this.animSpeed = 1; this.blendFrom = null; this.blendT = 99;
      this.pose = Object.assign({}, Anim.S);
      this.flash = 0; this.invuln = 0; this.trail = []; this.lastVoice = -999; this.frameCount = 0;
      this.crouching = false; this.stateLen = 0; this.held = null; this.airAttacked = false;
      this.sol = null; this.walkDust = 0; this.holding = null; this.doubled = false; this.dot = null;
      this.update_solve();
    }

    // ------------------------------------------------------------ анимация --
    setAnim(name, speed) {
      if (this.anim === name) { if (speed !== undefined) this.animSpeed = speed; return; }
      this.blendFrom = Object.assign({}, this.pose);
      this.blendT = 0; this.anim = name; this.animT = 0; this.animSpeed = speed === undefined ? 1 : speed;
    }
    stepPose() {
      const a = Anim.get(this.anim);
      this.animT += this.animSpeed;
      const target = Anim.sample(this.anim, this.animT);
      const bl = a.blend === undefined ? C.blendFrames : a.blend;
      if (this.blendFrom && this.blendT < bl) {
        this.blendT++;
        const k = Anim.ease.io(Math.min(1, this.blendT / bl));
        this.pose = Anim.lerp(this.blendFrom, target, k);
      } else this.pose = target;
    }

    setState(s, anim, speed) {
      this.state = s; this.st = 0;
      if (anim) this.setAnim(anim, speed);
    }

    // ------------------------------------------------------------ хёртбокс --
    update_solve() {
      this.sol = Rig.rigs[this.name] ? Rig.solve(this.name, this.pose, { x: this.x, y: C.groundY - this.h, facing: this.facing }) : null;
    }
    hurtbox() {
      const s = this.sol;
      if (!s) return { x: this.x - 35, y: C.groundY - this.h - 300, w: 70, h: 300 };
      const P = s.pts;
      const pts = ['head', 'headTop', 'neck', 'hip', 'shoulder', 'kneeF', 'soleF', 'soleN'].map(k => P[k]);
      let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
      for (const [x, y] of pts) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
      const cx = (x0 + x1) / 2, w = Math.max(64, x1 - x0 + 36);
      return { x: cx - w / 2, y: y0 - 4, w, h: y1 - y0 + 8 };
    }
    /** Положение конца конечности (кисть/стопа) в мире. */
    limbPoint(limb) {
      if (!this.sol) return [this.x + this.facing * 90, C.groundY - this.h - 180];
      return this.sol.pts[limb];
    }
    get airborne() { return this.h > 0.5; }
    get blocking() { return this.state === 'block' || this.state === 'cblock' || this.state === 'blockstun'; }
    get vulnerable() { return this.invuln <= 0 && !['knockdown', 'getup', 'ko', 'win', 'intro', 'held'].includes(this.state); }
    get alive() { return this.hp > 0; }

    say(game, ev) {
      if (game.frame - this.lastVoice < C.voiceCooldown && ev !== 'fight' && ev !== 'win' && ev !== 'select') return;
      this.lastVoice = game.frame;
      GameAudio.voice(this.ch, ev);
    }

    /** Споткнуться и упасть лицом вперёд (особенность Леши). */
    startTrip(game) {
      this.setState('trip', 'trip'); this.crouching = false; this.kb = this.facing * 3.2;
      Fx.text(this.x, C.groundY - 330, 'ОЙ!', '#ffd15c', 36, 45);
      Fx.dust(this.x, C.groundY, 6, 26); GameAudio.sfx('fall', 0.6);
    }

    // -------------------------------------------------------------- атаки ---
    startMove(key, game) {
      const m = C.moves[key];
      this.move = m; this.moveKey = key; this.hitDone = false; this.doubled = false;
      this.setState('attack', m.anim, 1);
      this.crouching = key === 'sweep';
      GameAudio.sfx('whoosh');
    }
    startSpecial(game) {
      const sp = C.specials[this.specialType];
      this.meter -= C.specialCost;
      this.move = sp; this.moveKey = 'special'; this.hitDone = false;
      this.setState('attack', sp.anim, 1);
      GameAudio.sfx('special');
      Fx.text(this.x, C.groundY - this.h - 330, sp.name, '#ffd15c', 34, 40);
      this.say(game, 'special');
      this.vy = 0;
    }

    // ------------------------------------------------------------- апдейт ---
    /** inp = {held:{}, pressed:{}} ; opp – соперник ; game – контекст боя. */
    update(inp, opp, game) {
      this.frameCount++;
      if (this.dot && game.canFight) {                 // яд: небольшой урон каждые N кадров
        const d = this.dot;
        if (--d.t <= 0) {
          d.t = d.every; d.n--;
          if (this.hp > 1) { this.hp = Math.max(1, this.hp - d.per); this.flash = Math.max(this.flash, 0.35); Fx.text(this.x + (Math.random() * 30 - 15), C.groundY - this.h - 300, '-' + d.per, '#7dff4a', 24, 28); }
        }
        if (d.n <= 0) this.dot = null;
      }
      if (this.invuln > 0) this.invuln--;
      if (this.flash > 0) this.flash -= 0.12;
      const held = inp.held, pr = inp.pressed;
      const consume = a => { if (inp.consume) inp.consume(a); pr[a] = false; };
      this.st++;
      const fwdKey = this.facing > 0 ? 'right' : 'left', backKey = this.facing > 0 ? 'left' : 'right';
      const dirX = (held.right ? 1 : 0) - (held.left ? 1 : 0);

      // повернуться лицом к сопернику, пока стоим на земле и не атакуем
      if (!this.airborne && ['idle', 'walk', 'walkB', 'crouch', 'block', 'cblock', 'land', 'jumpsquat', 'hit', 'blockstun'].includes(this.state) && opp) {
        const f = sign(opp.x - this.x);
        if (f && f !== this.facing && this.state !== 'hit') { this.facing = f; }
      }

      const canAct = ACTIONABLE.includes(this.state) && game.canFight;
      if (canAct) {
        // ---- действия ----
        const down = held.down;
        if (pr.throw && opp && Math.abs(opp.x - this.x) <= C.throwRange && opp.vulnerable && !opp.airborne && opp.state !== 'held') {
          consume('throw'); this.startMove('throw', game);
        } else if (pr.special && this.meter >= C.specialCost) {
          consume('special'); this.startSpecial(game);
        } else if (pr.kick) {
          consume('kick'); this.startMove(down ? 'sweep' : 'kick', game);
        } else if (pr.heavy) {
          consume('heavy'); this.startMove('heavy', game);
        } else if (pr.light) {
          consume('light'); this.startMove('light', game);
        } else if (held.block) {
          this.crouching = down;
          const s = down ? 'cblock' : 'block';
          if (this.state !== s) this.setState(s, s);
        } else if (pr.up) {
          consume('up');
          this.setState('jumpsquat', 'jump_prep'); this.jumpDir = dirX; this.crouching = false;
        } else if (down) {
          this.crouching = true;
          if (this.state !== 'crouch') this.setState('crouch', 'crouch');
          else if (this.animT > Anim.length('crouch')) this.setAnim('crouchIdle');
        } else {
          this.crouching = false;
          if (dirX === 0) { if (this.state !== 'idle') this.setState('idle', 'idle'); }
          else {
            const fwd = dirX === (this.facing > 0 ? 1 : -1);
            const s = fwd ? 'walk' : 'walkB';
            if (this.state !== s) this.setState(s, s);
            const spd = this.trait.speed || 1;
            this.x += this.facing * (fwd ? C.walkSpeed : -C.backSpeed) * spd;
            this.animSpeed = (fwd ? 1 : 0.9) * spd;
            // Леша иногда спотыкается и падает
            if (this.trait.stumble && Math.random() < this.trait.stumble && !this.airborne) this.startTrip(game);
            // пыль от шагов
            if (this.frameCount % 12 === 0) Fx.dust(this.x - this.facing * 10, C.groundY, 2, 12);
          }
        }
      }

      // ---- состояния ----
      switch (this.state) {
        case 'jumpsquat':
          if (this.st >= C.jumpSquat) {
            this.vy = C.jumpVel; this.vx = (this.jumpDir || 0) * C.airSpeed * (this.trait.speed || 1); this.h = 0.1;
            this.setState('air', 'jump_up'); this.airAttacked = false;
            Fx.dust(this.x, C.groundY, 5, 24); GameAudio.sfx('whoosh', 0.5);
          }
          break;
        case 'air':
          if (this.vy > -2 && this.anim === 'jump_up') this.setAnim('jump_fall');
          if (game.canFight && !this.airAttacked) {
            if (pr.kick) { consume('kick'); this.airAttacked = true; this.startMove('jkick', game); }
            else if (pr.light || pr.heavy) { consume(pr.light ? 'light' : 'heavy'); this.airAttacked = true; this.startMove('jpunch', game); }
          }
          break;
        case 'land':
          if (this.st >= C.landRecovery) this.setState('idle', 'idle');
          break;
        case 'attack': this.updateAttack(opp, game, held, pr, consume); break;
        case 'blockstun':
          if (this.st >= this.stateLen) this.setState(held.block ? (this.crouching ? 'cblock' : 'block') : 'idle', held.block ? (this.crouching ? 'cblock' : 'block') : 'idle');
          break;
        case 'hit':
          if (this.st >= this.stateLen) { this.setState('idle', this.crouching ? 'crouchIdle' : 'idle'); if (this.crouching && !held.down) this.crouching = false; }
          break;
        case 'knockdown': case 'ko':
          // лежим на земле; после паузы – подъём (у KO – нет)
          if (this.state === 'knockdown' && !this.airborne && this.st >= 52 && this.alive) { this.setState('getup', 'getup'); this.invuln = 40; }
          break;
        case 'getup':
          if (this.st >= Anim.length('getup')) { this.setState('idle', 'idle'); this.invuln = Math.max(this.invuln, 6); }
          break;
        case 'trip':
          if (this.st >= Anim.length('trip')) this.setState('idle', 'idle');
          break;
        case 'held':
          // удерживается соперником при броске – позицию задаёт нападающий
          break;
        default: break;
      }

      // ---- физика ----
      if (this.airborne || this.vy !== 0) {
        this.vy += C.gravity; this.h -= this.vy;
        this.x += this.vx;
        if (this.h <= 0) {
          this.h = 0;
          const wasAir = this.vy > 0;
          this.vy = 0; this.vx = 0;
          if (wasAir) this.onLand(game);
        }
      }
      // отбрасывание по земле
      if (Math.abs(this.kb) > 0.05) { this.x += this.kb; this.kb *= C.friction; if (!this.airborne && this.frameCount % 5 === 0 && Math.abs(this.kb) > 2) Fx.dust(this.x, C.groundY, 1, 10); }
      else this.kb = 0;

      this.stepPose();
      this.update_solve();

      // след удара по траектории кисти/стопы
      if (this.state === 'attack' && this.move && this.move.limb && this.st >= this.move.startup - 4 && this.st <= this.move.startup + this.move.active + 4) {
        const p = this.limbPoint(this.move.limb); this.trail.push({ x: p[0], y: p[1] });
        if (this.trail.length > 9) this.trail.shift();
      } else if (this.trail.length) this.trail.shift();
    }

    onLand(game) {
      Fx.dust(this.x, C.groundY, 7, 30);
      if (this.state === 'knockdown' || this.state === 'ko') {
        GameAudio.sfx('fall'); Fx.shake(this.state === 'ko' ? C.shakeKO * 0.6 : 7);
        Fx.shockwave(this.x, C.groundY - 2, 90, '200,160,120');
        this.st = Math.min(this.st, 30);
        return;
      }
      if (this.state === 'attack') { this.move = null; this.setState('land', 'land'); return; }
      if (this.state === 'air' || this.state === 'hit') { this.setState('land', 'land'); }
    }

    updateAttack(opp, game, held, pr, consume) {
      const m = this.move, f = this.st;
      const total = m.startup + m.active + m.recovery;
      // шаг вперёд при тяжёлых ударах
      if (m.lunge && f < m.startup && !this.airborne) this.x += this.facing * m.lunge * (f / m.startup + 0.4);
      const key = this.moveKey;
      if (key === 'special') this.updateSpecial(opp, game);
      // отмена удара спецударом при попадании
      if (this.hitDone && pr.special && this.meter >= C.specialCost && key !== 'special' && game.canFight) {
        consume('special'); this.startSpecial(game); return;
      }
      if (key === 'throw') this.updateThrow(opp, game);
      if (f >= total) {
        this.move = null; this.crouching = (key === 'sweep') && held.down;
        if (this.airborne) { this.setState('air', 'jump_fall'); }
        else this.setState(this.crouching ? 'crouch' : 'idle', this.crouching ? 'crouchIdle' : 'idle');
        this.holding = null;
      }
    }

    updateSpecial(opp, game) {
      const m = this.move, f = this.st, t = this.specialType;
      const act = f >= m.startup && f < m.startup + m.active;
      if (t === 'proj' && f === m.startup) {
        const p = this.limbPoint('handN');
        game.spawnProjectile(this, p[0], p[1], m);
        GameAudio.sfx('special'); Fx.burstFlash(p[0], p[1], 70, '255,200,100');
      } else if (t === 'dash' && act) {
        this.x += this.facing * m.speed;
        if (f === m.startup) { GameAudio.sfx('heavy'); Fx.dust(this.x, C.groundY, 6, 20); }
        if (opp && Math.abs(opp.x - this.x) < C.pushDist - 8 && this.hitDone) this.x -= this.facing * m.speed;
      } else if (t === 'wave' && f === m.startup) {
        game.shockwaveHit(this, m);
      } else if (t === 'rise' && f === m.startup) {
        this.vy = -14.5; this.h = 0.1; this.vx = this.facing * 1.8;
        Fx.dust(this.x, C.groundY, 6, 20);
      } else if (t === 'hammer' && f === m.startup) {
        const p = this.limbPoint('handN');
        game.spawnProjectile(this, p[0], p[1] - 10, m, { kind: 'hammer', vy: -1.2, g: 0.05 });
        GameAudio.sfx('whoosh'); GameAudio.sfx('special'); Fx.burstFlash(p[0], p[1], 60, '255,220,160');
      } else if (t === 'spit' && f === m.startup) {
        const p = this.sol.pts.head;
        game.spawnProjectile(this, p[0] + this.facing * 30, p[1] + 14, m, { kind: 'spit', vy: -0.6, g: 0.03 });
        GameAudio.sfx('whoosh'); GameAudio.sfx('spit');
      } else if (t === 'bottle') {
        const k = [0, 9, 18].indexOf(f - m.startup);
        if (k >= 0) {
          const p = this.limbPoint('handN'), V = [[7.4, -7.0], [8.6, -8.4], [6.2, -5.0]][k];
          game.spawnProjectile(this, p[0], p[1] - 14, m, { kind: 'bottle', vx: this.facing * V[0], vy: V[1], g: 0.32, rot: 0 });
          GameAudio.sfx('whoosh');
        }
      } else if (t === 'grind') {
        // болгарка: серия коротких ударов вплотную, боец понемногу наступает
        if (f >= m.startup && f < m.startup + m.active) {
          this.x += this.facing * 1.4;
          if (f === m.startup) GameAudio.sfx('grind');
          if ((f - m.startup) % m.every === 0) {
            if ((f - m.startup) % 12 === 0) GameAudio.sfx('grind');
            game.grinderHit(this, m, f - m.startup >= m.active - m.every);
          }
          const hp = this.grinderPos();
          if (hp && this.frameCount % 2 === 0) Fx.sparks(hp[0], hp[1], this.facing, 3, '#ffcf5a', 1.1);
        }
      }
    }

    updateThrow(opp, game) {
      const m = this.move, f = this.st;
      if (f === m.startup) {
        if (opp && Math.abs(opp.x - this.x) <= C.throwRange + 10 && opp.vulnerable && !opp.airborne && opp.state !== 'held' && !opp.blockingThrowImmune) {
          this.hitDone = true; this.holding = opp;
          opp.setState('held', 'hit_h'); opp.crouching = false; opp.kb = 0; opp.vx = 0;
          GameAudio.sfx('block'); Fx.hit(opp.x, C.groundY - 190, this.facing, 1.5);
          Fx.shake(5);
        }
      }
      const tossF = m.startup + m.active + 17;
      if (this.holding) {
        // держим противника перед собой, приподнимая на замахе
        const o = this.holding;
        o.x = this.x + this.facing * 62; o.facing = -this.facing;
        if (f >= m.startup + m.active + 6 && f < tossF) o.h = Math.min(60, (f - (m.startup + m.active + 6)) * 5);
        if (f >= tossF) {
          this.holding = null; o.h = Math.max(o.h, 1);
          game.applyDamage(this, o, m, { throw: true });
        }
      }
    }

    /** Точка диска болгарки (перед руками). */
    grinderPos() {
      if (!this.sol) return null;
      const a = this.sol.pts.handN, b = this.sol.pts.handF;
      return [(a[0] + b[0]) / 2 + this.facing * 34, (a[1] + b[1]) / 2 + 4];
    }
    drawGrinder(ctx) {
      const hp = this.grinderPos(); if (!hp) return;
      const a = this.sol.pts.handN, b = this.sol.pts.handF, f = this.facing, t = this.frameCount;
      ctx.save();
      // корпус инструмента: от рук до диска
      const bx = (a[0] + b[0]) / 2, by = (a[1] + b[1]) / 2;
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#1e5f9a'; ctx.lineWidth = 17; ctx.beginPath(); ctx.moveTo(bx - f * 20, by + 2); ctx.lineTo(bx + f * 22, by + 3); ctx.stroke();
      ctx.strokeStyle = '#2c2c2e'; ctx.lineWidth = 11; ctx.beginPath(); ctx.moveTo(bx - f * 28, by + 2); ctx.lineTo(bx - f * 8, by + 2); ctx.stroke();
      ctx.fillStyle = '#c9c9cf'; ctx.fillRect(hp[0] - f * 12 - 6, hp[1] - 12, 12, 26);
      // диск (вид с ребра → тонкий эллипс, быстро мерцает)
      ctx.fillStyle = (t % 2) ? '#d9d9e0' : '#9a9aa4';
      ctx.beginPath(); ctx.ellipse(hp[0], hp[1], 5, 30, 0, 0, 7); ctx.fill();
      ctx.globalCompositeOperation = 'lighter';
      const g = ctx.createRadialGradient(hp[0], hp[1], 0, hp[0], hp[1], 46);
      g.addColorStop(0, 'rgba(255,230,140,.55)'); g.addColorStop(1, 'rgba(255,120,20,0)');
      ctx.fillStyle = g; ctx.fillRect(hp[0] - 46, hp[1] - 46, 92, 92);
      ctx.restore();
    }

    // ------------------------------------------------------------ рисование --
    draw(ctx, arena) {
      const gy = C.groundY;
      // тень на полу
      const sh = Math.max(0.35, 1 - this.h / 380);
      ctx.save();
      ctx.fillStyle = 'rgba(0,0,0,' + (0.42 * sh).toFixed(2) + ')';
      ctx.beginPath(); ctx.ellipse(this.x, gy + 4, 78 * sh + (this.state === 'knockdown' || this.state === 'ko' ? 40 : 0), 15 * sh, 0, 0, 7); ctx.fill();
      ctx.restore();
      // готовые кадры вместо рига (запасной вариант)
      const fr = Rig.frames[this.name], key = FRAME_KEY[this.anim] || FRAME_KEY[this.state];
      const list = fr && fr[key];
      if (list && list.some(Boolean)) {
        const valid = list.filter(Boolean), a = Anim.get(this.anim);
        const idx = a.loop ? Math.floor(this.animT / 6) % valid.length : Math.min(valid.length - 1, Math.floor(this.animT / Math.max(1, a.length / valid.length)));
        Rig.drawFrame(ctx, valid[idx], this.x, gy - this.h, this.facing, C.fighterHeight);
        return;
      }
      if (!this.sol) return;
      Rig.draw(ctx, this.sol, { flash: Math.max(0, this.flash), groundY: gy });
      if (this.state === 'attack' && this.moveKey === 'special' && this.specialType === 'grind') this.drawGrinder(ctx);
    }
    drawTrail(ctx) {
      if (this.trail.length > 1 && this.move) {
        const col = this.moveKey === 'special' ? '255,170,60' : (this.move.limb && this.move.limb.startsWith('toe') ? '255,120,70' : '255,225,150');
        Fx.drawTrail(ctx, this.trail, col, 20);
      }
    }
  }

  window.Fighter = Fighter;
})();

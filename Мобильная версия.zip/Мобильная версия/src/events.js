// ============================================================================
//  events.js — случайные события боя: собаки «Булка» (лижет и лечит) и «Малыш» (лает и кусает).
//  Данные берутся из папки «случайные события/<имя>/» (картинка + звук), см. tools/events.py.
//  Параметры (шанс, время, лечение, урон) – в config.js: eventChance, events…
// ============================================================================
(function () {
  const C = window.CFG;
  const sign = v => (v > 0 ? 1 : v < 0 ? -1 : 0);
  const Events = { defs: [], ready: false };

  /** Загружает картинки собак. list – GAME_DATA.events. */
  Events.load = async function (list) {
    Events.defs = [];
    for (const e of list || []) {
      const cfg = C.events[e.key];
      if (!cfg) continue;                           // нет настроек поведения – событие пропускаем
      const img = new Image();
      const ok = await new Promise(res => { img.onload = () => res(true); img.onerror = () => res(false); img.src = encodeURI(e.image); });
      if (!ok) continue;
      // длительность звука: собака «работает» столько, сколько звучит файл
      let dur = cfg.sec || 4;
      if (e.sounds && e.sounds[0]) {
        dur = await new Promise(res => {
          const a = new Audio(); const t = setTimeout(() => res(dur), 1200);
          a.preload = 'metadata'; a.onloadedmetadata = () => { clearTimeout(t); res(isFinite(a.duration) && a.duration > 0.5 ? a.duration : dur); };
          a.onerror = () => { clearTimeout(t); res(dur); }; a.src = encodeURI(e.sounds[0]);
        });
      }
      Events.defs.push(Object.assign({ img, cfg, dur }, e));
    }
    Events.ready = true;
  };

  /** Собака на арене: прибегает, действует, убегает. */
  class Dog {
    constructor(def, target, game) {
      this.def = def; this.target = target; this.game = game;
      this.side = Math.random() < 0.5 ? -1 : 1;                    // откуда прибегает
      const cx = game.cam.x + 640;
      this.x = cx + this.side * 760; this.state = 'in'; this.st = 0; this.facing = -this.side;
      this.snd = (def.sounds && def.sounds.length) ? encodeURI(def.sounds[Math.floor(Math.random() * def.sounds.length)]) : null;
      this.actLen = Math.round((def.dur || 4.5) * 60 * (def.cfg.plays || 1)) + 10;
      this.hpDone = 0; this.runPhase = 0; this.dead = false;
      this.audio = null;
    }
    get goalX() {
      const t = this.target, opp = this.game.fighters[1 - t.idx];
      const behind = -(sign(opp.x - t.x) || t.facing);               // встаёт сбоку «за спиной» бойца, чтобы не мешать ударам
      return t.x + behind * 74;
    }
    stop() { if (this.audio) { try { this.audio.pause(); } catch (e) {} } }
    update() {
      const g = this.game, t = this.target, cfg = this.def.cfg;
      this.st++; this.runPhase += 0.5;
      if (this.state === 'in') {
        const gx = this.goalX, d = gx - this.x;
        this.facing = sign(d) || this.facing;
        this.x += sign(d) * Math.min(Math.abs(d), 10);
        if (this.st % 8 === 0) Fx.dust(this.x, C.groundY, 1, 12);
        if (Math.abs(d) < 6) {
          this.state = 'act'; this.st = 0; this.facing = sign(t.x - this.x) || this.facing;
          Fx.text(this.x, C.groundY - 260, this.def.name.toUpperCase() + '!', cfg.type === 'lick' ? '#8dffa8' : '#ff8a6a', 42, 70);
          this.playSound();
        }
      } else if (this.state === 'act') {
        // следует за бойцом
        const gx = this.goalX, d = gx - this.x;
        this.x += sign(d) * Math.min(Math.abs(d), 6);
        this.facing = sign(t.x - this.x) || this.facing;
        if (cfg.type === 'lick' && this.st % 6 === 0 && t.hp > 0) {
          t.hp = Math.min(C.maxHealth, t.hp + cfg.heal / (this.actLen / 6));
          if (this.st % 24 === 0) Fx.text(t.x + (Math.random() * 40 - 20), C.groundY - t.h - 250 - Math.random() * 40, '+', '#8dffa8', 34, 40);
        }
        if (cfg.type === 'bite') {
          if (this.st % 14 === 0 && t.hp > 1) {
            const dmg = cfg.dmg / (this.actLen / 14);
            t.hp = Math.max(1, t.hp - dmg); t.damageTaken += dmg; t.flash = Math.max(t.flash, 0.6);
            Fx.hit(t.x + this.facing * 10, C.groundY - t.h - 60 - Math.random() * 40, this.facing, 0, false);
            if (this.st % 28 === 0) GameAudio.sfx('punch', 0.5);
          }
          if (this.st % 24 === 0) Fx.text(this.x + this.facing * 40, C.groundY - 190, 'ГАВ!', '#ffb07a', 32, 30);
        }
        if (this.st >= this.actLen || t.hp <= 0 && cfg.type === 'lick') { this.state = 'out'; this.st = 0; }
      } else {                                                       // убегает
        this.facing = this.side; this.x += this.side * 11;
        if (Math.abs(this.x - (g.cam.x + 640)) > 900) { this.dead = true; this.stop(); }
      }
    }
    playSound() {
      if (!this.snd || GameAudio.muted) return;
      this.audio = GameAudio.play(this.snd, 1.0);
      // звук повторяется, пока собака занята (plays раз)
      const n = this.def.cfg.plays || 1;
      if (n > 1 && this.audio) {
        let left = n - 1; const a = this.audio;
        a.addEventListener('ended', () => { if (left-- > 0 && this.state === 'act') { try { a.currentTime = 0; a.play(); } catch (e) {} } });
      }
    }
    draw(ctx) {
      const img = this.def.img, h = C.dogHeight, w = img.width * h / img.height;
      const running = this.state !== 'act';
      let bob = 0, lean = 0, lunge = 0, sq = 1;
      if (running) { bob = -Math.abs(Math.sin(this.runPhase)) * 14; lean = Math.sin(this.runPhase) * 0.06; sq = 1 + Math.sin(this.runPhase) * 0.05; }
      else if (this.def.cfg.type === 'lick') { const k = Math.sin(this.st * 0.5); lunge = 8 + k * 7; lean = 0.05 + k * 0.05; bob = Math.abs(k) * 3; }
      else { const k = Math.sin(this.st * 0.7); lunge = (k > 0 ? 14 : 2) * 1; lean = k * 0.1; bob = -Math.abs(k) * 6; }
      const gy = C.groundY + 6;
      ctx.save();
      ctx.fillStyle = 'rgba(0,0,0,.38)'; ctx.beginPath(); ctx.ellipse(this.x, gy, w * 0.42, 9, 0, 0, 7); ctx.fill();
      ctx.translate(this.x + this.facing * lunge, gy + bob);
      ctx.rotate(lean * this.facing);
      // картинка нарисована мордой влево
      ctx.scale(this.facing > 0 ? -sq : sq, 1 / sq);
      ctx.drawImage(img, -w / 2, -h, w, h);
      ctx.restore();
      // язык при облизывании
      if (this.state === 'act' && this.def.cfg.type === 'lick' && Math.floor(this.st / 6) % 2 === 0) {
        ctx.save(); ctx.fillStyle = '#ff7f9a';
        ctx.beginPath(); ctx.ellipse(this.x + this.facing * (w * 0.5 + lunge - 8), gy - h * 0.7 + bob, 9, 5, 0.5 * this.facing, 0, 7); ctx.fill(); ctx.restore();
      }
    }
  }
  Events.Dog = Dog;

  /** Планирует собаку на раунд (вызывается в начале раунда). Возвращает {at, def} или null. */
  Events.plan = function () {
    if (!Events.defs.length || Math.random() > C.eventChance) return null;
    const def = Events.defs[Math.floor(Math.random() * Events.defs.length)];
    const sec = C.eventMinSec + Math.random() * (C.eventMaxSec - C.eventMinSec);
    return { at: Math.round(sec * 60), def };
  };
  window.Events = Events;
})();

// ============================================================================
//  ai.js — простой ИИ противника. Подходит, атакует, блокирует, иногда отступает.
//  Сложность (config.js → ai) меняет скорость реакции, шанс блока, агрессивность и частоту спецударов.
//  ИИ выдаёт тот же «ввод» (held/pressed), что и игрок.
// ============================================================================
(function () {
  const C = window.CFG;
  const sign = v => (v > 0 ? 1 : v < 0 ? -1 : 0);

  class AI {
    constructor(level) {
      this.level = level; this.cfg = C.ai[level] || C.ai.normal;
      this.think = 0; this.mode = 'approach'; this.modeT = 0; this.seenAttack = -1; this.blockRoll = false; this.holdBlock = 0;
      this.pending = null;
    }

    /** Возвращает {held, pressed}. me/opp – бойцы, game – контекст. */
    decide(me, opp, game) {
      const held = { left: false, right: false, up: false, down: false, light: false, heavy: false, kick: false, block: false, throw: false, special: false };
      const pressed = Object.assign({}, held);
      const out = { held, pressed, consume() {} };
      if (!game.canFight || !opp) return out;
      const cfg = this.cfg;
      const dx = opp.x - me.x, dist = Math.abs(dx);
      const dir = sign(dx) || me.facing;
      const goFwd = () => { if (dir > 0) held.right = true; else held.left = true; };
      const goBack = () => { if (dir > 0) held.left = true; else held.right = true; };

      // --- реакция на атаку соперника (с задержкой реакции) ---
      if (opp.state === 'attack' && opp.move) {
        if (this.seenAttack !== opp.frameCount - opp.st) {            // новая атака
          this.seenAttack = opp.frameCount - opp.st;
          this.blockRoll = Math.random() < cfg.block && dist < 330;
          this.lowRoll = opp.moveKey === 'sweep';
        }
        const inWindow = opp.st >= Math.min(cfg.reaction, opp.move.startup - 1) && opp.st <= opp.move.startup + opp.move.active + 6;
        if (this.blockRoll && inWindow && !me.airborne) {
          this.holdBlock = 10;
        }
      }
      if (this.holdBlock > 0) {
        this.holdBlock--;
        held.block = true;
        if (this.lowRoll) held.down = true;
        return out;
      }

      // защитное поведение: после пропущенного удара не стоим как столб
      if (me.state === 'blockstun' || me.state === 'hit') { if (me.state === 'blockstun' && opp.state === 'attack') held.block = true; return out; }
      if (me.state === 'attack' || me.state === 'jumpsquat' || me.state === 'land' || me.state === 'air') return out;
      if (!['idle', 'walk', 'walkB', 'crouch', 'block', 'cblock'].includes(me.state)) return out;

      // --- решения принимаются раз в N кадров ---
      this.think--;
      this.modeT--;
      if (this.think <= 0) {
        this.think = cfg.think + Math.floor(Math.random() * cfg.think * 0.6);
        const r = Math.random();
        // спецудар
        if (me.meter >= C.specialCost && Math.random() < cfg.special) {
          const t = me.specialType;
          const ranged = ['proj', 'hammer', 'spit', 'bottle'];
          const ok = (ranged.includes(t) && dist > (t === 'bottle' ? 200 : 240) && dist < 700) || (t === 'grind' && dist < 150) || (t === 'dash' && dist > 200 && dist < 380) || (t === 'wave' && dist < 220) || (t === 'rise' && (dist < 170 || opp.airborne));
          if (ok) { pressed.special = true; held.special = true; return out; }
        }
        if (dist > 190) {
          this.mode = 'approach'; this.modeT = 14 + Math.floor(Math.random() * 20);
          if (Math.random() < cfg.jump && dist < 420) { pressed.up = true; held.up = true; if (Math.random() < 0.7) goFwd(); return out; }
        } else if (dist <= 190) {
          if (Math.random() < cfg.aggression) {
            if (dist < C.throwRange - 10 && (opp.blocking || r < 0.15)) { pressed.throw = true; held.throw = true; return out; }
            const a = Math.random();
            if (dist > 150) {                                  // дальняя дистанция – удар ногой / сильный
              if (a < 0.5) { pressed.kick = true; held.kick = true; } else { pressed.heavy = true; held.heavy = true; }
            } else {
              if (a < 0.42) { pressed.light = true; held.light = true; }
              else if (a < 0.62) { pressed.heavy = true; held.heavy = true; }
              else if (a < 0.84) { pressed.kick = true; held.kick = true; }
              else { held.down = true; pressed.kick = true; held.kick = true; }   // подсечка
            }
            return out;
          } else {
            this.mode = Math.random() < 0.5 ? 'retreat' : 'wait'; this.modeT = 12 + Math.floor(Math.random() * 22);
          }
        }
      }
      // --- движение по текущему режиму ---
      if (this.mode === 'approach' && dist > 150) goFwd();
      else if (this.mode === 'retreat') goBack();
      else if (this.mode === 'wait') { if (opp.airborne && dist < 200) held.block = true; }
      else if (dist > 150) goFwd();
      if (this.modeT <= 0 && this.mode !== 'approach') this.mode = 'approach';
      return out;
    }
  }

  window.AI = AI;
})();

// ============================================================================
//  main.js — запуск: загрузка данных, цикл 60 FPS с фиксированным шагом, масштаб под окно.
// ============================================================================
(function () {
  const C = window.CFG;
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  // разрешение отрисовки ниже логического 1280x720: на телефоне это заметно быстрее (авто-снижение при тормозах)
  let RS = C.renderScale || 1;
  function applyScale() { canvas.width = Math.round(C.W * RS); canvas.height = Math.round(C.H * RS); ctx.imageSmoothingQuality = 'low'; }
  applyScale();

  const App = {
    ctx, chars: [], cfg: { mode: 'cpu', level: 'normal', picks: [0, 1], arena: 0 }, scene: null, ready: false,
    go(name) {
      Input.clear();
      this.scene = Scenes[name];
      if (this.scene.enter) this.scene.enter(this);
    },
    startMatch() {
      const p = this.cfg.picks;
      this.matchOpts = {
        chars: [this.chars[p[0]], this.chars[p[1]]],
        modes: this.cfg.mode === 'cpu' ? ['human', 'ai'] : ['human', 'human'],
        level: this.cfg.level, arena: Arenas.list[this.cfg.arena],
      };
      GameAudio.stopVoices();
      this.go('match');
    },
  };
  window.App = App;

  // ---- масштаб под окно (с сохранением пропорций) ----
  function pauseMatch() {
    if (App.scene === Scenes.match && Scenes.match.m && !Scenes.match.m.paused && Scenes.match.m.phase !== 'matchEnd') { Scenes.match.m.paused = true; Scenes.match.m.pauseSel = 0; }
    if (window.Touch) Touch.reset();
  }
  function fit() {
    const vw = window.innerWidth, vh = window.innerHeight, k = Math.min(vw / C.W, vh / C.H);
    canvas.style.width = Math.floor(C.W * k) + 'px';
    canvas.style.height = Math.floor(C.H * k) + 'px';
    const portrait = vh > vw * 1.05;
    document.body.classList.toggle('portrait', portrait);
    if (portrait) pauseMatch();
  }
  window.addEventListener('resize', fit); window.addEventListener('orientationchange', fit); fit();
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseMatch(); });
  canvas.addEventListener('dblclick', () => {
    if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
  });

  function message(lines, color) {
    ctx.setTransform(RS, 0, 0, RS, 0, 0);
    ctx.fillStyle = '#0b0407'; ctx.fillRect(0, 0, C.W, C.H);
    ctx.textAlign = 'center'; ctx.fillStyle = color || '#e9dcc8';
    lines.forEach((l, i) => { ctx.font = (i === 0 ? '700 34px' : '500 22px') + ' "Segoe UI",Arial,sans-serif'; ctx.fillText(l, C.W / 2, 250 + i * 40); });
  }

  async function boot() {
    message(['ЖЕЛЕЗНЫЙ КУЛАК', 'Загрузка бойцов…']);
    const data = window.GAME_DATA;
    if (!data || !data.characters || !data.characters.length) {
      message(['Не найден список бойцов', 'Запустите tools/build.bat (или python tools/build.py), затем обновите страницу.'], '#ff6a5a');
      return;
    }
    await Rig.load(data.characters);
    App.chars = data.characters.filter(c => Rig.rigs[c.name]);
    if (!App.chars.length) {
      message(['У бойцов нет рига', 'Запустите tools/build.bat, чтобы нарезать фото на части.'], '#ff6a5a');
      return;
    }
    Arenas.init(data.arenas);
    await Events.load(data.events);          // собаки «случайные события» (нет папки – просто без них)
    GameAudio.probe();
    App.ready = true;

    // параметры для автотестов: ?test=cpu&c1=0&c2=1&arena=1&level=hard  /  ?test=aivai
    const q = new URLSearchParams(location.search);
    if (q.get('test')) {
      App.cfg.mode = q.get('test') === '2p' ? '2p' : 'cpu';
      App.cfg.level = q.get('level') || 'normal';
      App.cfg.picks = [+(q.get('c1') || 0) % App.chars.length, +(q.get('c2') || 1) % App.chars.length];
      App.cfg.arena = +(q.get('arena') || 0) % Arenas.list.length;
      App.startMatch();
      if (q.get('test') === 'aivai') {
        App.matchOpts.modes = ['ai', 'ai']; App.matchOpts.level = App.cfg.level; App.go('match');
      }
    } else App.go('title');
    requestAnimationFrame(loop);
  }

  // ---- цикл с фиксированным шагом 60 FPS ----
  const STEP = 1000 / 60;
  let last = performance.now(), acc = 0, slow = 0, fcount = 0;
  function loop(now) {
    const dt = now - last;
    // авто-качество: если кадры дольше ~22 мс, снижаем разрешение и количество частиц
    if (dt > 22) slow++; fcount++;
    if (fcount >= 90) {
      if (slow > 40) { if (RS > 0.5) { RS = Math.max(0.5, RS - 0.125); applyScale(); } else if (C.fxDensity > 0.3) C.fxDensity = 0.3; }
      slow = 0; fcount = 0;
    }
    acc += Math.min(250, now - last); last = now;
    let n = 0;
    while (acc >= STEP && n < 6) {
      Input.update();
      App.scene.update(App);
      acc -= STEP; n++;
    }
    ctx.setTransform(RS, 0, 0, RS, 0, 0);
    App.scene.draw(ctx, App);
    if (window.Touch) Touch.draw(ctx);
    requestAnimationFrame(loop);
  }

  // пауза при потере фокуса
  window.addEventListener('blur', () => {
    if (App.scene === Scenes.match && Scenes.match.m && !Scenes.match.m.paused && Scenes.match.m.phase !== 'matchEnd') { Scenes.match.m.paused = true; Scenes.match.m.pauseSel = 0; }
  });

  boot();
})();
